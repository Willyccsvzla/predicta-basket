import { o as Portada } from "./ops-pages-DtgvNp5Y.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BeW6SfcG.js
var SplitComponent = Portada;
//#endregion
export { SplitComponent as component };
