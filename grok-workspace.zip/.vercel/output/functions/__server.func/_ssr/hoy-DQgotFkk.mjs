import { r as Hoy } from "./ops-pages-DtgvNp5Y.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/hoy-DQgotFkk.js
var SplitComponent = Hoy;
//#endregion
export { SplitComponent as component };
