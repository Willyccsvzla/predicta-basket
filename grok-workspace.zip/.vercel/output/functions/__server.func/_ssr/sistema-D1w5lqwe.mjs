import { l as Sistema } from "./ops-pages-DtgvNp5Y.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sistema-D1w5lqwe.js
var SplitComponent = Sistema;
//#endregion
export { SplitComponent as component };
