import { c as Scheduler } from "./ops-pages-DtgvNp5Y.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/scheduler-BuT4WPrH.js
var SplitComponent = Scheduler;
//#endregion
export { SplitComponent as component };
