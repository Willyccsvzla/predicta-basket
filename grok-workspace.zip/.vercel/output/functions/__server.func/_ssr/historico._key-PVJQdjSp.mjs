import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as Route$1 } from "./router-CdYe2R6g.mjs";
import { n as Historico } from "./ledger-pages-CH-SfaYW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/historico._key-PVJQdjSp.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = function HistoricoRoute() {
	const { key } = Route$1.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Historico, { id: key });
};
//#endregion
export { SplitComponent as component };
