import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { C as td, S as statusTone, T as cn, _ as Foot, a as checkCompletedGames, b as Stat, c as FROZEN_V11, f as SEASON, g as Banner, h as addDays, i as useOps, l as SCHEDULE_CONTRACT, m as teamName, o as overlayOf, p as gamesOnDate, s as productionCounts, u as METRICS_BUNDLE, v as Pager, w as th, x as TableWrap, y as Pill } from "./router-CdYe2R6g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ops-pages-DtgvNp5Y.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var buttonStyles = cva("inline-flex h-11 items-center justify-center gap-2 rounded-lg px-4 text-sm font-medium transition-colors duration-200 disabled:cursor-not-allowed disabled:opacity-40", {
	variants: { tone: {
		solid: "bg-bone text-ink hover:bg-accent",
		ghost: "border border-line bg-transparent text-bone hover:border-accent",
		quiet: "bg-transparent text-muted hover:text-bone"
	} },
	defaultVariants: { tone: "ghost" }
});
function Button({ className, tone, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: cn(buttonStyles({ tone }), className),
		...props
	});
}
function niceDate(iso) {
	const [y, m, d] = iso.split("-").map(Number);
	if (!y || !m || !d) return iso;
	return new Intl.DateTimeFormat("es-PE", {
		weekday: "long",
		day: "numeric",
		month: "long",
		year: "numeric",
		timeZone: "UTC"
	}).format(new Date(Date.UTC(y, m - 1, d)));
}
function monthLabel(ym) {
	const [y, m] = ym.split("-").map(Number);
	return new Intl.DateTimeFormat("es-PE", {
		month: "long",
		year: "numeric",
		timeZone: "UTC"
	}).format(new Date(Date.UTC(y, m - 1, 1)));
}
function Portada() {
	const state = useOps();
	const counts = productionCounts(state);
	const next = SEASON.find((g) => !overlayOf(state, g.id).frozen) ?? SEASON[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-lg border border-line bg-card p-5 lg:col-span-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
							tone: "accent",
							children: "MOTOR v1.1 VALIDADO"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-3 text-4xl",
							children: "PREDICTA NBA"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-xl text-sm leading-relaxed text-muted",
							children: state.realPredictionsEnabled ? `Producción abierta. 2025-26 sigue congelada. 2026-27 se predice partido por partido, solo el día operativo (hora Este). Scheduler ${state.schedulerEnabled ? "encendido: avanza ese día solo" : "apagado"}.` : "Producción cerrada. Ningún partido 2026-27 recibe predicción."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-lg border border-line bg-card p-5 lg:col-span-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs tracking-widest text-muted uppercase",
							children: "Estado 2026-27"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 font-display text-4xl",
							children: counts.predictions
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "predicciones reales"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-sm text-muted",
							children: [
								"Congeladas ",
								counts.frozen,
								" · finalizados ",
								counts.finals,
								" · actualizados ",
								counts.updates
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-bone",
							children: state.realPredictionsEnabled ? "PRODUCCIÓN ABIERTA" : "PRODUCCIÓN CERRADA"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Histórica",
						v: "2025-26",
						sub: `${FROZEN_V11.n} partidos`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Accuracy",
						v: `${FROZEN_V11.acc}%`,
						sub: `Brier ${FROZEN_V11.brier}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Log loss",
						v: FROZEN_V11.logloss,
						sub: `MAE pts ${FROZEN_V11.maePts}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Calendario",
						v: SCHEDULE_CONTRACT.defined,
						sub: `${SCHEDULE_CONTRACT.pendingOfficial} pendientes · no inventados`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Banner, { children: [
				"Próximo partido sin predicción congelada: ",
				next.date,
				" ",
				next.time,
				" ",
				next.timezone,
				" · ",
				teamName(next.aa),
				" @ ",
				teamName(next.ha),
				" · ",
				next.id,
				". No es una predicción."
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Foot, {})
		]
	});
}
function Hoy() {
	const viewDate = useOps((s) => s.viewDate);
	const setViewDate = useOps((s) => s.setViewDate);
	const processSelectedDay = useOps((s) => s.processSelectedDay);
	const overlays = useOps((s) => s.overlays);
	const live = useOps((s) => s.realPredictionsEnabled);
	const games = gamesOnDate(viewDate);
	const bucket = (status) => games.filter((g) => (overlays[g.id]?.status ?? "PROGRAMADO") === status).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl",
					children: "Hoy"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted capitalize",
					children: [niceDate(viewDate), " · hora de calendario Este"]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "date",
							value: viewDate,
							onChange: (e) => e.target.value && setViewDate(e.target.value),
							className: "h-11 rounded-lg border border-line bg-card px-3 text-sm"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							onClick: () => setViewDate(addDays(viewDate, -1)),
							children: "Ayer"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							tone: "solid",
							onClick: () => setViewDate("2026-10-20"),
							children: "Apertura"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							onClick: () => setViewDate(addDays(viewDate, 1)),
							children: "Mañana"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Programados",
						v: games.length,
						sub: "en esta fecha"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Pendientes de predicción",
						v: bucket("PROGRAMADO") + bucket("DATOS_ACTUALIZADOS") + bucket("PREDICCIÓN_PENDIENTE")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Generadas",
						v: bucket("PREDICCIÓN_GENERADA")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Congeladas",
						v: bucket("PREDICCIÓN_CONGELADA")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "En espera",
						v: bucket("EN_ESPERA_RESULTADO")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Finalizados",
						v: bucket("FINALIZADO")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Actualizados",
						v: bucket("ACTUALIZADO")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Auditados",
						v: bucket("AUDITADO")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					tone: "solid",
					onClick: processSelectedDay,
					children: "Procesar este día"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-xl text-sm leading-relaxed text-muted",
					children: live ? "Cada partido avanza un solo estado. No se crea una predicción diaria única." : "Producción cerrada: el proceso queda en seco. Ningún partido 2026-27 recibe predicción."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto",
				children: Array.from({ length: 7 }, (_, i) => addDays(viewDate, i)).map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setViewDate(d),
					className: "h-11 shrink-0 rounded-full border border-line px-3 text-sm",
					children: [
						d.slice(5),
						" · ",
						gamesOnDate(d).length
					]
				}, d))
			}),
			games.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banner, { children: "No hay partidos en el calendario oficial para esta fecha. La apertura registrada es el 20 de octubre de 2026." }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3",
				children: games.map((g) => {
					const ov = overlays[g.id];
					const status = ov?.status ?? "PROGRAMADO";
					const pred = ov?.frozen ?? ov?.prediction;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/partido/$gameId",
						params: { gameId: g.id },
						className: "rounded-lg border border-line bg-card p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-display text-2xl",
									children: [
										g.aa,
										" @ ",
										g.ha
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
									tone: statusTone(status),
									children: status
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm text-muted",
								children: [
									g.time,
									" ",
									g.timezone,
									" · ",
									g.arena,
									" · ",
									g.id
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-bone",
								children: pred ? `Pick ${pred.pick} · ${pred.p_pick}% · margen ${pred.projected_margin} · ${ov?.frozen ? "congelada" : "no congelada"}` : "Sin predicción"
							})
						]
					}, g.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Foot, {})
		]
	});
}
function Calendario() {
	const setViewDate = useOps((s) => s.setViewDate);
	const months = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		for (const g of SEASON) {
			const ym = g.date.slice(0, 7);
			if (!map.has(ym)) map.set(ym, /* @__PURE__ */ new Map());
			const days = map.get(ym);
			days.set(g.date, (days.get(g.date) ?? 0) + 1);
		}
		return [...map.entries()];
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl",
				children: "Calendario"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Banner, { children: [
				"Temporada regular ",
				SCHEDULE_CONTRACT.coverage,
				". ",
				SCHEDULE_CONTRACT.defined,
				" partidos definidos, ",
				SCHEDULE_CONTRACT.pendingOfficial,
				" pendientes de definición oficial (NBA Cup). No se inventaron. Pretemporada: no."
			] }),
			months.map(([ym, days]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl capitalize",
					children: monthLabel(ym)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-7",
					children: [...days.entries()].map(([date, n]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/hoy",
						onClick: () => setViewDate(date),
						className: "rounded-lg border border-line bg-card px-3 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm text-bone",
							children: date.slice(8)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs text-muted",
							children: [n, " partidos"]
						})]
					}, date))
				})]
			}, ym)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Foot, {})
		]
	});
}
function Predicciones() {
	const overlays = useOps((s) => s.overlays);
	const live = useOps((s) => s.realPredictionsEnabled);
	const rows = SEASON.filter((g) => overlays[g.id]?.prediction || overlays[g.id]?.frozen);
	const next = SEASON.find((g) => !overlays[g.id]?.frozen);
	const opener = SEASON[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl",
				children: "Predicciones"
			}),
			rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg border border-line bg-card p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs tracking-widest text-muted uppercase",
						children: "2026-27"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-display text-3xl",
						children: live ? "Producción abierta. 0 predicciones oficiales." : "0 predicciones generadas."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted",
						children: live ? `No se adelantan. Cada partido se escribe el día del tip, hora Este, y se congela solo en los últimos 90 minutos. La apertura es ${opener.date}: ${opener.aa} @ ${opener.ha}.` : `Un partido sin predicción no se muestra aquí.${next ? ` El próximo pendiente es ${next.date} ${next.aa} @ ${next.ha}.` : ""}`
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableWrap, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full border-collapse",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Partido"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Pick"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Prob"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Margen"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Total"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Estado"
					})
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((g) => {
					const ov = overlays[g.id];
					const p = ov.frozen ?? ov.prediction;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/partido/$gameId",
								params: { gameId: g.id },
								className: "underline",
								children: [
									g.date,
									" ",
									g.aa,
									"@",
									g.ha
								]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: p.pick
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: td,
							children: [p.p_pick, "%"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: p.projected_margin
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: p.projected_total
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: ov.frozen ? "CONGELADA" : ov.status
						})
					] }, g.id);
				}) })]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Foot, {})
		]
	});
}
function Partidos() {
	const overlays = useOps((s) => s.overlays);
	const [q, setQ] = (0, import_react.useState)("");
	const [st, setSt] = (0, import_react.useState)("");
	const [page, setPage] = (0, import_react.useState)(0);
	const rows = SEASON.filter((g) => {
		const blob = `${g.date} ${g.aa} ${g.ha} ${g.arena}`.toLowerCase();
		if (q && !blob.includes(q.trim().toLowerCase())) return false;
		const status = overlays[g.id]?.status ?? "PROGRAMADO";
		if (st && status !== st) return false;
		return true;
	});
	const pages = Math.max(1, Math.ceil(rows.length / 40));
	const safe = Math.min(page, pages - 1);
	const slice = rows.slice(safe * 40, safe * 40 + 40);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl",
				children: "Partidos"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Temporada operativa 2026-27. Cada fila es un expediente. El histórico 2025-26 está en Números."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: q,
					onChange: (e) => {
						setPage(0);
						setQ(e.target.value);
					},
					placeholder: "Equipo, fecha o arena",
					className: "h-11 rounded-lg border border-line bg-card px-3 text-sm"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: st,
					onChange: (e) => {
						setPage(0);
						setSt(e.target.value);
					},
					className: "h-11 rounded-lg border border-line bg-card px-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Estado"
					}), [
						"PROGRAMADO",
						"DATOS_ACTUALIZADOS",
						"PREDICCIÓN_PENDIENTE",
						"PREDICCIÓN_GENERADA",
						"PREDICCIÓN_CONGELADA",
						"EN_ESPERA_RESULTADO",
						"FINALIZADO",
						"ACTUALIZADO",
						"AUDITADO",
						"ERROR"
					].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: s }, s))]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pager, {
				page: safe,
				pages,
				total: rows.length,
				onPrev: () => setPage((p) => Math.max(0, p - 1)),
				onNext: () => setPage((p) => p + 1)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableWrap, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full border-collapse",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Fecha"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Hora"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Visitante"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Local"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Estado"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Predicción"
					})
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: slice.map((g) => {
					const ov = overlays[g.id];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: g.date
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: td,
							children: [
								g.time,
								" ",
								g.timezone
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: g.aa
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: g.ha
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: ov?.status ?? "PROGRAMADO"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/partido/$gameId",
								params: { gameId: g.id },
								className: "underline",
								children: ov?.frozen ? "Congelada" : ov?.prediction ? "Generada" : "Abrir expediente"
							})
						})
					] }, g.id);
				}) })]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Foot, {})
		]
	});
}
function Partido({ gameId }) {
	const game = SEASON.find((g) => g.id === gameId);
	const ov = useOps((s) => s.overlays[gameId]);
	const ratings = useOps((s) => s.ratings);
	const audit = useOps((s) => s.audit).filter((a) => a.gameId === gameId);
	const live = useOps((s) => s.realPredictionsEnabled);
	const step = useOps((s) => s.step);
	const freeze = useOps((s) => s.freeze);
	const revise = useOps((s) => s.revise);
	const saveResult = useOps((s) => s.saveResult);
	const [homePts, setHomePts] = (0, import_react.useState)("");
	const [awayPts, setAwayPts] = (0, import_react.useState)("");
	const [source, setSource] = (0, import_react.useState)("");
	const [msg, setMsg] = (0, import_react.useState)("");
	if (!game) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banner, {
		tone: "bad",
		children: "Partido no definido. No se inventa."
	});
	const status = ov?.status ?? "PROGRAMADO";
	const pred = ov?.frozen ?? ov?.prediction;
	const home = ratings[game.ha];
	const away = ratings[game.aa];
	const log = audit.slice(-12).reverse();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-widest text-muted uppercase",
				children: game.id
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "text-3xl",
				children: [
					teamName(game.aa),
					" @ ",
					teamName(game.ha)
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
					tone: statusTone(status),
					children: status
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, { children: game.neutral ? "Neutral" : "Localía aplicada en el motor" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-lg border border-line bg-card p-4 text-sm leading-relaxed",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl",
						children: "Identificación"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-muted",
						children: [
							game.date,
							" · ",
							game.time,
							" ",
							game.timezone,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							game.arena,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							game.season,
							game.notes ? ` · ${game.notes}` : ""
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-lg border border-line bg-card p-4 text-sm leading-relaxed",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl",
						children: "Disponibilidad"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-muted",
						children: [
							"Out, questionable, doubtful, probable, minutos e impacto: NOT AVAILABLE / NOT VALIDATED. Questionable no es out. No se imputan minutos. Revisiones registradas: ",
							ov?.info.length ?? 0,
							"."
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-lg border border-line bg-card p-4 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "text-xl",
						children: ["Estado previo · ", game.ha]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-muted",
						children: [
							"Rating ",
							home?.rating,
							" · Off ",
							home?.ortg,
							" · Def ",
							home?.drtg,
							" · Pace ",
							home?.pace,
							" · Forma ",
							home?.form,
							" · ",
							home?.w,
							"-",
							home?.l,
							" · ",
							home?.source
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-lg border border-line bg-card p-4 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "text-xl",
						children: ["Estado previo · ", game.aa]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-muted",
						children: [
							"Rating ",
							away?.rating,
							" · Off ",
							away?.ortg,
							" · Def ",
							away?.drtg,
							" · Pace ",
							away?.pace,
							" · Forma ",
							away?.form,
							" · ",
							away?.w,
							"-",
							away?.l,
							" · ",
							away?.source
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banner, { children: "Rest NOT VALIDATED (n≥25, tope ±1.5, residual no recuperado). Travel NOT VALIDATED (tope ±0.6, distancias no inventadas). Four Factors NOT VALIDATED: no entran al marcador. Mercado: información y auditoría, no modifica el motor." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg border border-line bg-card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl",
						children: "Predicción y freeze"
					}),
					pred ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-2 gap-3 lg:grid-cols-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								k: "Local",
								v: pred.projected_home,
								sub: `${pred.p_home}%`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								k: "Visita",
								v: pred.projected_away,
								sub: `${pred.p_away}%`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								k: "Pick",
								v: pred.pick,
								sub: `${pred.confidence} · ${pred.uncertainty}`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								k: "Margen / total",
								v: pred.projected_margin,
								sub: `total ${pred.projected_total}`
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "Sin predicción. El calendario no genera una sola."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs text-muted",
						children: pred ? `${pred.engine_mark} · ${pred.model_version} · corte ${pred.cutoff} · snapshot v${pred.snapshot_version} · lookahead ${pred.lookahead_status}` : "LOCAL FALLBACK — NO SOURCE OF TRUTH"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								disabled: !live,
								onClick: () => step(game.id),
								children: "Siguiente paso"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								disabled: !live || status !== "PREDICCIÓN_GENERADA",
								onClick: () => freeze(game.id),
								children: "Congelar"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								disabled: !live || !!ov?.frozen,
								onClick: () => revise(game.id),
								children: "Registrar revisión"
							})
						]
					}),
					!live ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "Controles apagados mientras la producción está cerrada."
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg border border-line bg-card p-4 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl",
						children: "Resultado"
					}),
					ov?.result ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-muted",
						children: [
							ov.result.away_pts,
							"-",
							ov.result.home_pts,
							" · ganador ",
							ov.result.winner,
							" · fuente ",
							ov.result.source
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-muted",
						children: "NO DISPONIBLE. checkCompletedGames no inventa marcador."
					}),
					ov?.auditMath ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-muted",
						children: [
							"Error puntos ",
							ov.auditMath.pts_error,
							" · margen ",
							ov.auditMath.margin_error,
							" · total ",
							ov.auditMath.total_error,
							" · ",
							ov.auditMath.hit ? "acierto" : "error",
							" · Brier ",
							ov.auditMath.brier,
							" · log loss ",
							ov.auditMath.logloss
						]
					}) : null,
					status === "EN_ESPERA_RESULTADO" && live ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mt-3 flex flex-wrap gap-2",
						onSubmit: (e) => {
							e.preventDefault();
							const err = saveResult(game.id, Number(homePts), Number(awayPts), source);
							setMsg(err ?? "Resultado registrado.");
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: awayPts,
								onChange: (e) => setAwayPts(e.target.value),
								placeholder: "Puntos visita",
								className: "h-11 w-32 rounded-lg border border-line bg-ink px-3 text-sm"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: homePts,
								onChange: (e) => setHomePts(e.target.value),
								placeholder: "Puntos local",
								className: "h-11 w-32 rounded-lg border border-line bg-ink px-3 text-sm"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: source,
								onChange: (e) => setSource(e.target.value),
								placeholder: "Fuente oficial",
								className: "h-11 min-w-40 flex-1 rounded-lg border border-line bg-ink px-3 text-sm"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								tone: "solid",
								children: "Cargar resultado"
							})
						]
					}) : null,
					msg ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-accent",
						children: msg
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xl",
				children: "Audit log"
			}), log.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Sin acciones sobre este partido."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableWrap, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full border-collapse",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Hora"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Acción"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "De"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "A"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Resultado"
					})
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: log.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: td,
						children: a.timestamp.replace("T", " ").slice(0, 19)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: td,
						children: a.action
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: td,
						children: a.from
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: td,
						children: a.to
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: td,
						children: a.result
					})
				] }, a.id)) })]
			}) })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Foot, {})
		]
	});
}
function Auditoria() {
	const report = useOps((s) => s.sandboxReport);
	const live = useOps((s) => s.realPredictionsEnabled);
	const scheduled = useOps((s) => s.schedulerEnabled);
	const m = METRICS_BUNDLE.metrics;
	const rows = [
		[
			"Integridad histórica",
			"PASS",
			`${m.n} partidos. Accuracy ${m.acc}. No recalculada.`
		],
		[
			"Look-ahead",
			report?.lookaheadPass && report.lookaheadRejectedWinner ? "PASS" : "PENDIENTE",
			"Sandbox: limpio PASS, contaminado REJECTED."
		],
		[
			"Freeze duplicado",
			report?.secondFreeze === "REJECTED_ALREADY_FROZEN" ? "PASS" : "PENDIENTE",
			report?.secondFreeze ?? ""
		],
		[
			"Update no reescribe freeze",
			report?.frozenIntact ? "PASS" : "PENDIENTE",
			"La predicción congelada queda intacta."
		],
		[
			"Player impact",
			"NOT VALIDATED",
			"No entra al marcador. impact_applied = false."
		],
		[
			"Expected minutes",
			"NOT AVAILABLE",
			"No imputados."
		],
		[
			"Rest / travel",
			"NOT VALIDATED",
			"Topes documentados. Residual y distancias no recuperados."
		],
		[
			"Calendario 2026-27",
			"WARN",
			"1200 definidos. 30 pendientes. Pretemporada no incluida."
		],
		[
			"Producción",
			live ? "ABIERTA" : "CERRADA",
			live ? "Predicciones reales habilitadas." : "Predicciones reales apagadas."
		],
		[
			"Scheduler",
			scheduled ? "ON" : "OFF",
			scheduled ? "Automático con la página abierta. 3 h en general, 60 min en las últimas 6 h, 30 min en la ventana crítica y postpartido. Un estado por partido y por ciclo." : "Apagado. No toca partidos."
		],
		[
			"Sandbox",
			report?.purged ? "PASS" : "PENDIENTE",
			report?.note ?? ""
		]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl",
				children: "Auditoría"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Controles del mismo motor. No es una comparación pública de versiones."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableWrap, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full border-collapse",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Control"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Estado"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Nota"
					})
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map(([a, b, c]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: td,
						children: a
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: td,
						children: b
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: `${td} whitespace-normal`,
						children: c
					})
				] }, a)) })]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Foot, {})
		]
	});
}
function Sistema() {
	const state = useOps();
	const counts = productionCounts(state);
	const [arm, setArm] = (0, import_react.useState)(false);
	const report = state.sandboxReport;
	const flags = report ? [
		["Ciclo", report.ran],
		["Look-ahead limpio", report.lookaheadPass],
		["Rechaza ganador", report.lookaheadRejectedWinner],
		["Rechaza puntos", report.lookaheadRejectedPoints],
		["Rechaza resultado", report.lookaheadRejectedResult],
		["Rechaza posterior", report.lookaheadRejectedPost],
		["Predicción", report.prediction],
		["Freeze", report.freeze],
		["Segundo freeze", report.secondFreeze === "REJECTED_ALREADY_FROZEN"],
		["Update", report.update],
		["Freeze intacto", report.frozenIntact],
		["Persistencia", report.persist],
		["Reinicio", report.restart],
		["Aislamiento", report.isolation],
		["Purgado", report.purged],
		["Ratings reales intactos", report.ratingsUntouched],
		["Predicciones reales", report.realPredictions === 0]
	] : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl",
				children: "Sistema"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banner, { children: "LOCAL FALLBACK — NO SOURCE OF TRUTH. build_predicta.py y build_v11.py no están en el paquete. La matemática usada es la recuperada del motor embebido auditado, sin parámetros nuevos. Four Factors, rest, travel y ventanas de eficiencia no se inventan: quedan NOT VALIDATED y fuera del marcador. Tras el partido solo se actualiza el rating con builderUpdate." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Predicciones",
						v: counts.predictions
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Congeladas",
						v: counts.frozen
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Finalizados",
						v: counts.finals
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Actualizados",
						v: counts.updates
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg border border-line bg-card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl",
						children: "Activación manual"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted",
						children: [
							"Producción ",
							state.realPredictionsEnabled ? "abierta" : "cerrada",
							". Scheduler ",
							state.schedulerEnabled ? "encendido y automático" : "apagado",
							". Cada ciclo avanza un solo estado por partido, y solo si ese día ya es el día operativo."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [state.realPredictionsEnabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							tone: "solid",
							onClick: () => state.enableProduction(false),
							children: "Cerrar producción"
						}) : arm ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							tone: "solid",
							onClick: () => state.enableProduction(true),
							children: "Confirmar apertura"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							onClick: () => setArm(true),
							children: "Preparar apertura"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							disabled: !state.realPredictionsEnabled,
							onClick: () => state.enableScheduler(!state.schedulerEnabled),
							children: state.schedulerEnabled ? "Apagar scheduler" : "Encender scheduler"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl",
					children: "Sandbox descartado"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: report?.note ?? "Ejecutando…"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 grid grid-cols-2 gap-2 lg:grid-cols-4",
					children: flags.map(([k, ok]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border border-line bg-card px-3 py-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: ok ? "text-good" : "text-bad",
							children: ok ? "PASS" : "FAIL"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-2 text-muted",
							children: k
						})]
					}, String(k)))
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Foot, {})
		]
	});
}
function Scheduler() {
	const enabled = useOps((s) => s.schedulerEnabled);
	const live = useOps((s) => s.realPredictionsEnabled);
	const log = useOps((s) => s.schedulerLog);
	const overlays = useOps((s) => s.overlays);
	const tick = useOps((s) => s.tick);
	const waiting = checkCompletedGames({
		...useOps.getState(),
		overlays
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl",
				children: "Scheduler"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Banner, { children: [
				enabled ? "Scheduler encendido. Con la página abierta revisa solo el día operativo (hora Este) y avanza cada partido un estado: cada 3 horas, cada 60 minutos en las últimas 6 horas, y cada 30 minutos en los últimos 90 minutos o mientras falte el resultado." : "Scheduler apagado. No corre solo.",
				" ",
				"No recalcula 2025-26 ni reabre un freeze. No adelanta partidos de otro día. Predicciones reales: ",
				live ? "abiertas" : "cerradas",
				"."
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Scheduler",
						v: enabled ? "ON" : "OFF"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Predicciones reales",
						v: live ? "ON" : "OFF"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Resultados en espera",
						v: waiting.length,
						sub: "fuente NOT AVAILABLE"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				tone: "solid",
				onClick: () => tick(true),
				children: "Ejecutar tick ahora"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: enabled ? "El ciclo automático ya corre. Este botón fuerza uno ahora." : "Apagado: el tick solo deja constancia y no toca partidos."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableWrap, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full border-collapse",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
					className: th,
					children: "Hora"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
					className: th,
					children: "Nota"
				})] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: log.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: td,
					colSpan: 2,
					children: "Sin ticks."
				}) }) : [...log].reverse().slice(0, 20).map((row, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: td,
					children: row.timestamp.replace("T", " ").slice(0, 19)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: `${td} whitespace-normal`,
					children: row.note
				})] }, `${row.timestamp}-${i}`)) })]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Foot, {})
		]
	});
}
//#endregion
export { Partidos as a, Scheduler as c, Partido as i, Sistema as l, Calendario as n, Portada as o, Hoy as r, Predicciones as s, Auditoria as t };
