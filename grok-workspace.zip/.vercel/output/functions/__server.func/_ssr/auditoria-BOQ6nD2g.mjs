import { t as Auditoria } from "./ops-pages-DtgvNp5Y.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auditoria-BOQ6nD2g.js
var SplitComponent = Auditoria;
//#endregion
export { SplitComponent as component };
