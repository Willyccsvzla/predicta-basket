import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Route } from "./router-CdYe2R6g.mjs";
import { i as Partido } from "./ops-pages-DtgvNp5Y.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/partido._gameId-9eJqkbcQ.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = function PartidoRoute() {
	const { gameId } = Route.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Partido, { gameId });
};
//#endregion
export { SplitComponent as component };
