import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, _ as lazyRouteComponent, b as Link, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, p as useRouterState, v as createFileRoute, x as useRouter, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-CdYe2R6g.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function Mark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 240 68",
		className: "h-12 w-44",
		"aria-label": "PREDICTA NBA",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "120",
				cy: "34",
				rx: "112",
				ry: "29",
				className: "fill-surface stroke-accent",
				strokeWidth: "1.6"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "120",
				y: "31",
				textAnchor: "middle",
				className: "fill-bone",
				fontFamily: "Georgia, serif",
				fontSize: "18",
				letterSpacing: "3",
				children: "PREDICTA"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: "120",
				y: "48",
				textAnchor: "middle",
				className: "fill-accent",
				fontFamily: "Georgia, serif",
				fontSize: "11",
				letterSpacing: "4",
				children: "NBA"
			})
		]
	});
}
function Stat({ k, v, sub }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-line bg-card p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs tracking-widest text-muted uppercase",
				children: k
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 font-display text-3xl text-bone",
				children: v
			}),
			sub ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm leading-relaxed text-muted",
				children: sub
			}) : null
		]
	});
}
function Banner({ children, tone = "accent" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("border-l-4 bg-surface px-4 py-3 text-sm leading-relaxed text-bone", tone === "bad" ? "border-bad" : "border-accent"),
		children
	});
}
function Pill({ children, tone = "muted" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full border px-2 py-1 text-xs tracking-wide", {
			muted: "border-line text-muted",
			accent: "border-accent text-accent",
			good: "border-good text-good",
			bad: "border-bad text-bad"
		}[tone]),
		children
	});
}
function statusTone(status) {
	if (status === "ERROR") return "bad";
	if (status === "AUDITADO" || status === "ACTUALIZADO" || status === "FINALIZADO") return "good";
	if (status === "PREDICCIÓN_CONGELADA" || status === "PREDICCIÓN_GENERADA") return "accent";
	return "muted";
}
function TableWrap({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "max-h-[40rem] overflow-auto rounded-lg border border-line",
		children
	});
}
var th = "sticky top-0 bg-surface px-3 py-2 text-left text-xs tracking-widest text-muted uppercase";
var td = "border-t border-line px-3 py-2 text-sm whitespace-nowrap";
function Foot() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-8 border-t border-line pt-4 text-xs leading-relaxed text-muted",
		children: "PREDICTA NBA — Resultados estadísticos referenciales. Los datos y cálculos dependen de las fuentes disponibles y pueden estar sujetos a errores humanos, errores de registro o limitaciones de datos. Este documento no constituye garantía de resultados futuros. El motor embebido es LOCAL FALLBACK — NO SOURCE OF TRUTH."
	});
}
function Pager({ page, pages, total, onPrev, onNext }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "h-11 rounded-lg border border-line px-4 text-sm",
				onClick: onPrev,
				disabled: page <= 0,
				children: "Anterior"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-sm text-muted",
				children: [
					total,
					" filas · página ",
					page + 1,
					" de ",
					pages
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "h-11 rounded-lg border border-line px-4 text-sm",
				onClick: onNext,
				disabled: page + 1 >= pages,
				children: "Siguiente"
			})
		]
	});
}
var ranking_default = [
	{
		"team": "San Antonio Spurs",
		"abbr": "SAS",
		"w": 62,
		"l": 20,
		"rating": 1982.6,
		"rating_v1": 1982.6,
		"ortg": 119.68,
		"drtg": 111.41,
		"nrtg": 8.27,
		"pace": 100.1,
		"form": 13.6
	},
	{
		"team": "Oklahoma City Thunder",
		"abbr": "OKC",
		"w": 64,
		"l": 18,
		"rating": 1964.7,
		"rating_v1": 1964.7,
		"ortg": 118.94,
		"drtg": 107.89,
		"nrtg": 11.05,
		"pace": 100.1,
		"form": 10.3
	},
	{
		"team": "Detroit Pistons",
		"abbr": "DET",
		"w": 60,
		"l": 22,
		"rating": 1889.5,
		"rating_v1": 1889.5,
		"ortg": 118.05,
		"drtg": 109.81,
		"nrtg": 8.23,
		"pace": 99.8,
		"form": 11.8
	},
	{
		"team": "Boston Celtics",
		"abbr": "BOS",
		"w": 56,
		"l": 26,
		"rating": 1881.2,
		"rating_v1": 1881.2,
		"ortg": 120.82,
		"drtg": 112.67,
		"nrtg": 8.15,
		"pace": 95.1,
		"form": 11.2
	},
	{
		"team": "Denver Nuggets",
		"abbr": "DEN",
		"w": 54,
		"l": 28,
		"rating": 1810.8,
		"rating_v1": 1810.8,
		"ortg": 122.63,
		"drtg": 117.46,
		"nrtg": 5.17,
		"pace": 99.5,
		"form": 10.5
	},
	{
		"team": "New York Knicks",
		"abbr": "NYK",
		"w": 53,
		"l": 29,
		"rating": 1745.3,
		"rating_v1": 1745.3,
		"ortg": 119.87,
		"drtg": 113.4,
		"nrtg": 6.47,
		"pace": 97.1,
		"form": 2.9
	},
	{
		"team": "Charlotte Hornets",
		"abbr": "CHA",
		"w": 44,
		"l": 38,
		"rating": 1736.3,
		"rating_v1": 1736.3,
		"ortg": 119.5,
		"drtg": 114.47,
		"nrtg": 5.03,
		"pace": 97.1,
		"form": 6.3
	},
	{
		"team": "Cleveland Cavaliers",
		"abbr": "CLE",
		"w": 52,
		"l": 30,
		"rating": 1724.8,
		"rating_v1": 1724.8,
		"ortg": 119.26,
		"drtg": 115.2,
		"nrtg": 4.05,
		"pace": 100.2,
		"form": 2.8
	},
	{
		"team": "Houston Rockets",
		"abbr": "HOU",
		"w": 52,
		"l": 30,
		"rating": 1720.5,
		"rating_v1": 1720.5,
		"ortg": 118.69,
		"drtg": 113.3,
		"nrtg": 5.39,
		"pace": 97.1,
		"form": 15.2
	},
	{
		"team": "Los Angeles Lakers",
		"abbr": "LAL",
		"w": 53,
		"l": 29,
		"rating": 1717.2,
		"rating_v1": 1717.2,
		"ortg": 118.21,
		"drtg": 116.48,
		"nrtg": 1.74,
		"pace": 98.4,
		"form": 4
	},
	{
		"team": "Atlanta Hawks",
		"abbr": "ATL",
		"w": 46,
		"l": 36,
		"rating": 1658.3,
		"rating_v1": 1658.3,
		"ortg": 116.13,
		"drtg": 113.77,
		"nrtg": 2.36,
		"pace": 102,
		"form": 6.4
	},
	{
		"team": "Minnesota Timberwolves",
		"abbr": "MIN",
		"w": 49,
		"l": 33,
		"rating": 1620.6,
		"rating_v1": 1620.6,
		"ortg": 116.76,
		"drtg": 113.68,
		"nrtg": 3.08,
		"pace": 101.1,
		"form": -.3
	},
	{
		"team": "Toronto Raptors",
		"abbr": "TOR",
		"w": 46,
		"l": 36,
		"rating": 1584.6,
		"rating_v1": 1584.6,
		"ortg": 115.83,
		"drtg": 113.25,
		"nrtg": 2.58,
		"pace": 99,
		"form": 12.2
	},
	{
		"team": "Phoenix Suns",
		"abbr": "PHX",
		"w": 45,
		"l": 37,
		"rating": 1573.1,
		"rating_v1": 1573.1,
		"ortg": 115.51,
		"drtg": 114.09,
		"nrtg": 1.42,
		"pace": 97.5,
		"form": 3
	},
	{
		"team": "Los Angeles Clippers",
		"abbr": "LAC",
		"w": 42,
		"l": 40,
		"rating": 1567.7,
		"rating_v1": 1567.7,
		"ortg": 117.45,
		"drtg": 116.32,
		"nrtg": 1.13,
		"pace": 96.9,
		"form": 2.1
	},
	{
		"team": "Orlando Magic",
		"abbr": "ORL",
		"w": 45,
		"l": 37,
		"rating": 1562.7,
		"rating_v1": 1562.7,
		"ortg": 115.09,
		"drtg": 114.54,
		"nrtg": .56,
		"pace": 100.6,
		"form": -1.1
	},
	{
		"team": "Philadelphia 76ers",
		"abbr": "PHI",
		"w": 45,
		"l": 37,
		"rating": 1554.9,
		"rating_v1": 1554.9,
		"ortg": 115.4,
		"drtg": 115.58,
		"nrtg": -.17,
		"pace": 100.4,
		"form": 3.2
	},
	{
		"team": "Portland Trail Blazers",
		"abbr": "POR",
		"w": 42,
		"l": 40,
		"rating": 1554.4,
		"rating_v1": 1554.4,
		"ortg": 114.54,
		"drtg": 114.71,
		"nrtg": -.17,
		"pace": 100.8,
		"form": 13.1
	},
	{
		"team": "Miami Heat",
		"abbr": "MIA",
		"w": 43,
		"l": 39,
		"rating": 1538.2,
		"rating_v1": 1538.2,
		"ortg": 116.71,
		"drtg": 114.54,
		"nrtg": 2.18,
		"pace": 103.6,
		"form": -.4
	},
	{
		"team": "Golden State Warriors",
		"abbr": "GSW",
		"w": 37,
		"l": 45,
		"rating": 1357.4,
		"rating_v1": 1357.4,
		"ortg": 115.05,
		"drtg": 115.6,
		"nrtg": -.55,
		"pace": 99.6,
		"form": -5.9
	},
	{
		"team": "New Orleans Pelicans",
		"abbr": "NOP",
		"w": 26,
		"l": 56,
		"rating": 1291.2,
		"rating_v1": 1291.2,
		"ortg": 114.4,
		"drtg": 119.05,
		"nrtg": -4.65,
		"pace": 101,
		"form": -10.4
	},
	{
		"team": "Milwaukee Bucks",
		"abbr": "MIL",
		"w": 32,
		"l": 50,
		"rating": 1227.1,
		"rating_v1": 1227.1,
		"ortg": 112.9,
		"drtg": 119.4,
		"nrtg": -6.49,
		"pace": 98,
		"form": -7.9
	},
	{
		"team": "Dallas Mavericks",
		"abbr": "DAL",
		"w": 26,
		"l": 56,
		"rating": 1192.3,
		"rating_v1": 1192.3,
		"ortg": 111.23,
		"drtg": 116.66,
		"nrtg": -5.43,
		"pace": 102.6,
		"form": -7.5
	},
	{
		"team": "Chicago Bulls",
		"abbr": "CHI",
		"w": 31,
		"l": 51,
		"rating": 1186.5,
		"rating_v1": 1186.5,
		"ortg": 113.01,
		"drtg": 118.16,
		"nrtg": -5.14,
		"pace": 102.9,
		"form": -10.6
	},
	{
		"team": "Sacramento Kings",
		"abbr": "SAC",
		"w": 22,
		"l": 60,
		"rating": 1122,
		"rating_v1": 1122,
		"ortg": 111.56,
		"drtg": 121.63,
		"nrtg": -10.07,
		"pace": 99.5,
		"form": -10.3
	},
	{
		"team": "Indiana Pacers",
		"abbr": "IND",
		"w": 19,
		"l": 63,
		"rating": 1084,
		"rating_v1": 1084,
		"ortg": 111.01,
		"drtg": 118.97,
		"nrtg": -7.96,
		"pace": 101.3,
		"form": -1.6
	},
	{
		"team": "Memphis Grizzlies",
		"abbr": "MEM",
		"w": 25,
		"l": 57,
		"rating": 1078.4,
		"rating_v1": 1078.4,
		"ortg": 113.05,
		"drtg": 118.95,
		"nrtg": -5.9,
		"pace": 101.4,
		"form": -20.4
	},
	{
		"team": "Utah Jazz",
		"abbr": "UTA",
		"w": 22,
		"l": 60,
		"rating": 1068.1,
		"rating_v1": 1068.1,
		"ortg": 114.18,
		"drtg": 122.39,
		"nrtg": -8.21,
		"pace": 103,
		"form": -14.2
	},
	{
		"team": "Brooklyn Nets",
		"abbr": "BKN",
		"w": 20,
		"l": 62,
		"rating": 1053.5,
		"rating_v1": 1053.5,
		"ortg": 108.84,
		"drtg": 119.11,
		"nrtg": -10.27,
		"pace": 97.3,
		"form": -13.7
	},
	{
		"team": "Washington Wizards",
		"abbr": "WAS",
		"w": 17,
		"l": 65,
		"rating": 951.9,
		"rating_v1": 951.9,
		"ortg": 111,
		"drtg": 122.84,
		"nrtg": -11.84,
		"pace": 101.7,
		"form": -18.1
	}
];
var season_2027_default = /*#__PURE__*/ JSON.parse("[{\"id\":\"NBA2027-0001\",\"date\":\"2026-10-20\",\"time\":\"3:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0002\",\"date\":\"2026-10-20\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0003\",\"date\":\"2026-10-20\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0004\",\"date\":\"2026-10-21\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0005\",\"date\":\"2026-10-21\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0006\",\"date\":\"2026-10-21\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0007\",\"date\":\"2026-10-21\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0008\",\"date\":\"2026-10-21\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0009\",\"date\":\"2026-10-21\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0010\",\"date\":\"2026-10-21\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0011\",\"date\":\"2026-10-21\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0012\",\"date\":\"2026-10-21\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0013\",\"date\":\"2026-10-21\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0014\",\"date\":\"2026-10-21\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0015\",\"date\":\"2026-10-22\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0016\",\"date\":\"2026-10-22\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0017\",\"date\":\"2026-10-23\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0018\",\"date\":\"2026-10-23\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0019\",\"date\":\"2026-10-23\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0020\",\"date\":\"2026-10-23\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0021\",\"date\":\"2026-10-23\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0022\",\"date\":\"2026-10-23\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0023\",\"date\":\"2026-10-23\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0024\",\"date\":\"2026-10-23\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"SAS\",\"arena\":\"Moody Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0025\",\"date\":\"2026-10-23\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0026\",\"date\":\"2026-10-23\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0027\",\"date\":\"2026-10-23\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0028\",\"date\":\"2026-10-23\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0029\",\"date\":\"2026-10-24\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0030\",\"date\":\"2026-10-24\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0031\",\"date\":\"2026-10-24\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0032\",\"date\":\"2026-10-24\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0033\",\"date\":\"2026-10-24\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0034\",\"date\":\"2026-10-24\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0035\",\"date\":\"2026-10-24\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0036\",\"date\":\"2026-10-24\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0037\",\"date\":\"2026-10-25\",\"time\":\"5:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0038\",\"date\":\"2026-10-25\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0039\",\"date\":\"2026-10-25\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0040\",\"date\":\"2026-10-25\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0041\",\"date\":\"2026-10-25\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0042\",\"date\":\"2026-10-25\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0043\",\"date\":\"2026-10-25\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0044\",\"date\":\"2026-10-26\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0045\",\"date\":\"2026-10-26\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0046\",\"date\":\"2026-10-26\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0047\",\"date\":\"2026-10-26\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0048\",\"date\":\"2026-10-26\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0049\",\"date\":\"2026-10-26\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0050\",\"date\":\"2026-10-26\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0051\",\"date\":\"2026-10-26\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0052\",\"date\":\"2026-10-26\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0053\",\"date\":\"2026-10-27\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0054\",\"date\":\"2026-10-27\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0055\",\"date\":\"2026-10-27\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0056\",\"date\":\"2026-10-27\",\"time\":\"11:00p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0057\",\"date\":\"2026-10-28\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0058\",\"date\":\"2026-10-28\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0059\",\"date\":\"2026-10-28\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0060\",\"date\":\"2026-10-28\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0061\",\"date\":\"2026-10-28\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0062\",\"date\":\"2026-10-28\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0063\",\"date\":\"2026-10-28\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0064\",\"date\":\"2026-10-28\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0065\",\"date\":\"2026-10-28\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0066\",\"date\":\"2026-10-28\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0067\",\"date\":\"2026-10-28\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0068\",\"date\":\"2026-10-28\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0069\",\"date\":\"2026-10-29\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0070\",\"date\":\"2026-10-29\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0071\",\"date\":\"2026-10-29\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0072\",\"date\":\"2026-10-30\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0073\",\"date\":\"2026-10-30\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0074\",\"date\":\"2026-10-30\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0075\",\"date\":\"2026-10-30\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0076\",\"date\":\"2026-10-30\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0077\",\"date\":\"2026-10-30\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0078\",\"date\":\"2026-10-30\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0079\",\"date\":\"2026-10-30\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0080\",\"date\":\"2026-10-30\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0081\",\"date\":\"2026-10-30\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0082\",\"date\":\"2026-10-31\",\"time\":\"3:00p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0083\",\"date\":\"2026-10-31\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0084\",\"date\":\"2026-10-31\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0085\",\"date\":\"2026-10-31\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0086\",\"date\":\"2026-10-31\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0087\",\"date\":\"2026-10-31\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0088\",\"date\":\"2026-10-31\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0089\",\"date\":\"2026-11-01\",\"time\":\"3:30p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0090\",\"date\":\"2026-11-01\",\"time\":\"5:00p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0091\",\"date\":\"2026-11-01\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0092\",\"date\":\"2026-11-01\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0093\",\"date\":\"2026-11-02\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0094\",\"date\":\"2026-11-02\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0095\",\"date\":\"2026-11-02\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0096\",\"date\":\"2026-11-02\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0097\",\"date\":\"2026-11-02\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0098\",\"date\":\"2026-11-02\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0099\",\"date\":\"2026-11-02\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0100\",\"date\":\"2026-11-02\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0101\",\"date\":\"2026-11-02\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0102\",\"date\":\"2026-11-02\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0103\",\"date\":\"2026-11-02\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0104\",\"date\":\"2026-11-02\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0105\",\"date\":\"2026-11-02\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0106\",\"date\":\"2026-11-02\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0107\",\"date\":\"2026-11-02\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0108\",\"date\":\"2026-11-04\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0109\",\"date\":\"2026-11-04\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0110\",\"date\":\"2026-11-04\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0111\",\"date\":\"2026-11-04\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0112\",\"date\":\"2026-11-04\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0113\",\"date\":\"2026-11-04\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0114\",\"date\":\"2026-11-04\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0115\",\"date\":\"2026-11-04\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0116\",\"date\":\"2026-11-04\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0117\",\"date\":\"2026-11-04\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0118\",\"date\":\"2026-11-04\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0119\",\"date\":\"2026-11-04\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0120\",\"date\":\"2026-11-04\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0121\",\"date\":\"2026-11-04\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0122\",\"date\":\"2026-11-05\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0123\",\"date\":\"2026-11-05\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0124\",\"date\":\"2026-11-06\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0125\",\"date\":\"2026-11-06\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0126\",\"date\":\"2026-11-06\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0127\",\"date\":\"2026-11-06\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0128\",\"date\":\"2026-11-06\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0129\",\"date\":\"2026-11-06\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0130\",\"date\":\"2026-11-06\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0131\",\"date\":\"2026-11-06\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0132\",\"date\":\"2026-11-06\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0133\",\"date\":\"2026-11-07\",\"time\":\"5:00p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"IND\",\"arena\":\"Mexico City Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0134\",\"date\":\"2026-11-07\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0135\",\"date\":\"2026-11-07\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0136\",\"date\":\"2026-11-07\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0137\",\"date\":\"2026-11-07\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0138\",\"date\":\"2026-11-07\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0139\",\"date\":\"2026-11-07\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0140\",\"date\":\"2026-11-08\",\"time\":\"3:30p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0141\",\"date\":\"2026-11-08\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0142\",\"date\":\"2026-11-08\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0143\",\"date\":\"2026-11-08\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0144\",\"date\":\"2026-11-08\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0145\",\"date\":\"2026-11-08\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0146\",\"date\":\"2026-11-08\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0147\",\"date\":\"2026-11-09\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0148\",\"date\":\"2026-11-09\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0149\",\"date\":\"2026-11-09\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0150\",\"date\":\"2026-11-09\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0151\",\"date\":\"2026-11-09\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0152\",\"date\":\"2026-11-09\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0153\",\"date\":\"2026-11-09\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0154\",\"date\":\"2026-11-09\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0155\",\"date\":\"2026-11-10\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0156\",\"date\":\"2026-11-10\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0157\",\"date\":\"2026-11-10\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0158\",\"date\":\"2026-11-10\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0159\",\"date\":\"2026-11-10\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0160\",\"date\":\"2026-11-10\",\"time\":\"11:00p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0161\",\"date\":\"2026-11-11\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0162\",\"date\":\"2026-11-11\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0163\",\"date\":\"2026-11-11\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0164\",\"date\":\"2026-11-11\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0165\",\"date\":\"2026-11-11\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0166\",\"date\":\"2026-11-11\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0167\",\"date\":\"2026-11-11\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0168\",\"date\":\"2026-11-11\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0169\",\"date\":\"2026-11-11\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0170\",\"date\":\"2026-11-11\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0171\",\"date\":\"2026-11-12\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0172\",\"date\":\"2026-11-12\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0173\",\"date\":\"2026-11-12\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0174\",\"date\":\"2026-11-12\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0175\",\"date\":\"2026-11-13\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0176\",\"date\":\"2026-11-13\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0177\",\"date\":\"2026-11-13\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0178\",\"date\":\"2026-11-13\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0179\",\"date\":\"2026-11-13\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0180\",\"date\":\"2026-11-13\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0181\",\"date\":\"2026-11-13\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0182\",\"date\":\"2026-11-13\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0183\",\"date\":\"2026-11-13\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0184\",\"date\":\"2026-11-14\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0185\",\"date\":\"2026-11-14\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0186\",\"date\":\"2026-11-14\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0187\",\"date\":\"2026-11-14\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0188\",\"date\":\"2026-11-14\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0189\",\"date\":\"2026-11-15\",\"time\":\"1:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0190\",\"date\":\"2026-11-15\",\"time\":\"4:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0191\",\"date\":\"2026-11-15\",\"time\":\"4:30p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0192\",\"date\":\"2026-11-15\",\"time\":\"5:00p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0193\",\"date\":\"2026-11-15\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0194\",\"date\":\"2026-11-15\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0195\",\"date\":\"2026-11-15\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0196\",\"date\":\"2026-11-15\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0197\",\"date\":\"2026-11-15\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0198\",\"date\":\"2026-11-16\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0199\",\"date\":\"2026-11-16\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0200\",\"date\":\"2026-11-16\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0201\",\"date\":\"2026-11-16\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0202\",\"date\":\"2026-11-16\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0203\",\"date\":\"2026-11-16\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0204\",\"date\":\"2026-11-16\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0205\",\"date\":\"2026-11-16\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0206\",\"date\":\"2026-11-17\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0207\",\"date\":\"2026-11-17\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0208\",\"date\":\"2026-11-17\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0209\",\"date\":\"2026-11-17\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0210\",\"date\":\"2026-11-17\",\"time\":\"11:00p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0211\",\"date\":\"2026-11-18\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0212\",\"date\":\"2026-11-18\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0213\",\"date\":\"2026-11-18\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0214\",\"date\":\"2026-11-18\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0215\",\"date\":\"2026-11-18\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0216\",\"date\":\"2026-11-18\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0217\",\"date\":\"2026-11-18\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0218\",\"date\":\"2026-11-18\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0219\",\"date\":\"2026-11-18\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0220\",\"date\":\"2026-11-18\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0221\",\"date\":\"2026-11-18\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0222\",\"date\":\"2026-11-18\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0223\",\"date\":\"2026-11-19\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0224\",\"date\":\"2026-11-19\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0225\",\"date\":\"2026-11-19\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0226\",\"date\":\"2026-11-19\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0227\",\"date\":\"2026-11-20\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0228\",\"date\":\"2026-11-20\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0229\",\"date\":\"2026-11-20\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0230\",\"date\":\"2026-11-20\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0231\",\"date\":\"2026-11-20\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0232\",\"date\":\"2026-11-20\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0233\",\"date\":\"2026-11-20\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0234\",\"date\":\"2026-11-20\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0235\",\"date\":\"2026-11-20\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0236\",\"date\":\"2026-11-21\",\"time\":\"1:00p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0237\",\"date\":\"2026-11-21\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0238\",\"date\":\"2026-11-21\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0239\",\"date\":\"2026-11-21\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0240\",\"date\":\"2026-11-21\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0241\",\"date\":\"2026-11-21\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0242\",\"date\":\"2026-11-22\",\"time\":\"3:30p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0243\",\"date\":\"2026-11-22\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0244\",\"date\":\"2026-11-22\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0245\",\"date\":\"2026-11-22\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0246\",\"date\":\"2026-11-22\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0247\",\"date\":\"2026-11-22\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0248\",\"date\":\"2026-11-22\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0249\",\"date\":\"2026-11-23\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0250\",\"date\":\"2026-11-23\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0251\",\"date\":\"2026-11-23\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0252\",\"date\":\"2026-11-23\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0253\",\"date\":\"2026-11-23\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0254\",\"date\":\"2026-11-23\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0255\",\"date\":\"2026-11-23\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0256\",\"date\":\"2026-11-23\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0257\",\"date\":\"2026-11-23\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0258\",\"date\":\"2026-11-23\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0259\",\"date\":\"2026-11-24\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0260\",\"date\":\"2026-11-24\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0261\",\"date\":\"2026-11-24\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0262\",\"date\":\"2026-11-25\",\"time\":\"5:00p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0263\",\"date\":\"2026-11-25\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0264\",\"date\":\"2026-11-25\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0265\",\"date\":\"2026-11-25\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0266\",\"date\":\"2026-11-25\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0267\",\"date\":\"2026-11-25\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0268\",\"date\":\"2026-11-25\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0269\",\"date\":\"2026-11-25\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0270\",\"date\":\"2026-11-25\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0271\",\"date\":\"2026-11-27\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0272\",\"date\":\"2026-11-27\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0273\",\"date\":\"2026-11-27\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0274\",\"date\":\"2026-11-27\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0275\",\"date\":\"2026-11-27\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0276\",\"date\":\"2026-11-27\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0277\",\"date\":\"2026-11-27\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0278\",\"date\":\"2026-11-27\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0279\",\"date\":\"2026-11-27\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0280\",\"date\":\"2026-11-27\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0281\",\"date\":\"2026-11-27\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"NBA Cup\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0282\",\"date\":\"2026-11-28\",\"time\":\"5:00p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0283\",\"date\":\"2026-11-28\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0284\",\"date\":\"2026-11-28\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0285\",\"date\":\"2026-11-28\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0286\",\"date\":\"2026-11-28\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0287\",\"date\":\"2026-11-29\",\"time\":\"4:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0288\",\"date\":\"2026-11-29\",\"time\":\"4:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0289\",\"date\":\"2026-11-29\",\"time\":\"5:00p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0290\",\"date\":\"2026-11-29\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0291\",\"date\":\"2026-11-29\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0292\",\"date\":\"2026-11-29\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0293\",\"date\":\"2026-11-29\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0294\",\"date\":\"2026-11-29\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0295\",\"date\":\"2026-11-29\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0296\",\"date\":\"2026-11-29\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0297\",\"date\":\"2026-11-30\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0298\",\"date\":\"2026-11-30\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0299\",\"date\":\"2026-11-30\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0300\",\"date\":\"2026-11-30\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0301\",\"date\":\"2026-11-30\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0302\",\"date\":\"2026-11-30\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0303\",\"date\":\"2026-11-30\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0304\",\"date\":\"2026-12-01\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0305\",\"date\":\"2026-12-01\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0306\",\"date\":\"2026-12-01\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0307\",\"date\":\"2026-12-01\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0308\",\"date\":\"2026-12-01\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0309\",\"date\":\"2026-12-01\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0310\",\"date\":\"2026-12-01\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0311\",\"date\":\"2026-12-01\",\"time\":\"11:00p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0312\",\"date\":\"2026-12-02\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0313\",\"date\":\"2026-12-02\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0314\",\"date\":\"2026-12-02\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0315\",\"date\":\"2026-12-02\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0316\",\"date\":\"2026-12-02\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0317\",\"date\":\"2026-12-02\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0318\",\"date\":\"2026-12-02\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0319\",\"date\":\"2026-12-02\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0320\",\"date\":\"2026-12-02\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0321\",\"date\":\"2026-12-03\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0322\",\"date\":\"2026-12-03\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0323\",\"date\":\"2026-12-03\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0324\",\"date\":\"2026-12-03\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0325\",\"date\":\"2026-12-03\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0326\",\"date\":\"2026-12-12\",\"time\":\"5:00p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0327\",\"date\":\"2026-12-12\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0328\",\"date\":\"2026-12-12\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0329\",\"date\":\"2026-12-12\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0330\",\"date\":\"2026-12-12\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0331\",\"date\":\"2026-12-12\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0332\",\"date\":\"2026-12-12\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0333\",\"date\":\"2026-12-12\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0334\",\"date\":\"2026-12-13\",\"time\":\"3:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0335\",\"date\":\"2026-12-13\",\"time\":\"3:30p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0336\",\"date\":\"2026-12-13\",\"time\":\"5:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0337\",\"date\":\"2026-12-13\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0338\",\"date\":\"2026-12-13\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0339\",\"date\":\"2026-12-13\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0340\",\"date\":\"2026-12-14\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0341\",\"date\":\"2026-12-14\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0342\",\"date\":\"2026-12-14\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0343\",\"date\":\"2026-12-14\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0344\",\"date\":\"2026-12-14\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0345\",\"date\":\"2026-12-14\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0346\",\"date\":\"2026-12-14\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0347\",\"date\":\"2026-12-14\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0348\",\"date\":\"2026-12-14\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0349\",\"date\":\"2026-12-14\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0350\",\"date\":\"2026-12-14\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0351\",\"date\":\"2026-12-15\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0352\",\"date\":\"2026-12-15\",\"time\":\"11:00p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0353\",\"date\":\"2026-12-16\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0354\",\"date\":\"2026-12-16\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0355\",\"date\":\"2026-12-16\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0356\",\"date\":\"2026-12-16\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0357\",\"date\":\"2026-12-16\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0358\",\"date\":\"2026-12-16\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0359\",\"date\":\"2026-12-16\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0360\",\"date\":\"2026-12-16\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0361\",\"date\":\"2026-12-16\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0362\",\"date\":\"2026-12-16\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0363\",\"date\":\"2026-12-16\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0364\",\"date\":\"2026-12-16\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0365\",\"date\":\"2026-12-16\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0366\",\"date\":\"2026-12-17\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0367\",\"date\":\"2026-12-17\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0368\",\"date\":\"2026-12-17\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0369\",\"date\":\"2026-12-18\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0370\",\"date\":\"2026-12-18\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0371\",\"date\":\"2026-12-18\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0372\",\"date\":\"2026-12-18\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0373\",\"date\":\"2026-12-18\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0374\",\"date\":\"2026-12-18\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0375\",\"date\":\"2026-12-18\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0376\",\"date\":\"2026-12-18\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0377\",\"date\":\"2026-12-18\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0378\",\"date\":\"2026-12-18\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0379\",\"date\":\"2026-12-18\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0380\",\"date\":\"2026-12-18\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0381\",\"date\":\"2026-12-19\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0382\",\"date\":\"2026-12-19\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0383\",\"date\":\"2026-12-19\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0384\",\"date\":\"2026-12-19\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0385\",\"date\":\"2026-12-20\",\"time\":\"3:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0386\",\"date\":\"2026-12-20\",\"time\":\"3:30p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0387\",\"date\":\"2026-12-20\",\"time\":\"4:00p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0388\",\"date\":\"2026-12-20\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0389\",\"date\":\"2026-12-20\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0390\",\"date\":\"2026-12-20\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0391\",\"date\":\"2026-12-20\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0392\",\"date\":\"2026-12-20\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0393\",\"date\":\"2026-12-20\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0394\",\"date\":\"2026-12-20\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0395\",\"date\":\"2026-12-21\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0396\",\"date\":\"2026-12-21\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0397\",\"date\":\"2026-12-21\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0398\",\"date\":\"2026-12-21\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0399\",\"date\":\"2026-12-21\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0400\",\"date\":\"2026-12-21\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0401\",\"date\":\"2026-12-21\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0402\",\"date\":\"2026-12-21\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0403\",\"date\":\"2026-12-21\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0404\",\"date\":\"2026-12-21\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0405\",\"date\":\"2026-12-22\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0406\",\"date\":\"2026-12-22\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0407\",\"date\":\"2026-12-22\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0408\",\"date\":\"2026-12-23\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0409\",\"date\":\"2026-12-23\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0410\",\"date\":\"2026-12-23\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0411\",\"date\":\"2026-12-23\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0412\",\"date\":\"2026-12-23\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0413\",\"date\":\"2026-12-23\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0414\",\"date\":\"2026-12-23\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0415\",\"date\":\"2026-12-23\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0416\",\"date\":\"2026-12-23\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0417\",\"date\":\"2026-12-23\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0418\",\"date\":\"2026-12-23\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0419\",\"date\":\"2026-12-23\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0420\",\"date\":\"2026-12-23\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0421\",\"date\":\"2026-12-23\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0422\",\"date\":\"2026-12-23\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0423\",\"date\":\"2026-12-25\",\"time\":\"12:00p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0424\",\"date\":\"2026-12-25\",\"time\":\"2:30p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0425\",\"date\":\"2026-12-25\",\"time\":\"5:00p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0426\",\"date\":\"2026-12-25\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0427\",\"date\":\"2026-12-25\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0428\",\"date\":\"2026-12-26\",\"time\":\"1:00p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0429\",\"date\":\"2026-12-26\",\"time\":\"3:30p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0430\",\"date\":\"2026-12-26\",\"time\":\"5:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0431\",\"date\":\"2026-12-26\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0432\",\"date\":\"2026-12-26\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0433\",\"date\":\"2026-12-26\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0434\",\"date\":\"2026-12-26\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0435\",\"date\":\"2026-12-26\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0436\",\"date\":\"2026-12-27\",\"time\":\"3:30p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0437\",\"date\":\"2026-12-27\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0438\",\"date\":\"2026-12-27\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0439\",\"date\":\"2026-12-27\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0440\",\"date\":\"2026-12-27\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0441\",\"date\":\"2026-12-27\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0442\",\"date\":\"2026-12-27\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0443\",\"date\":\"2026-12-27\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0444\",\"date\":\"2026-12-27\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0445\",\"date\":\"2026-12-27\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0446\",\"date\":\"2026-12-27\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0447\",\"date\":\"2026-12-27\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0448\",\"date\":\"2026-12-28\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0449\",\"date\":\"2026-12-28\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0450\",\"date\":\"2026-12-28\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0451\",\"date\":\"2026-12-28\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0452\",\"date\":\"2026-12-29\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0453\",\"date\":\"2026-12-29\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0454\",\"date\":\"2026-12-29\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0455\",\"date\":\"2026-12-29\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0456\",\"date\":\"2026-12-29\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0457\",\"date\":\"2026-12-29\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0458\",\"date\":\"2026-12-29\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0459\",\"date\":\"2026-12-29\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0460\",\"date\":\"2026-12-29\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0461\",\"date\":\"2026-12-30\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0462\",\"date\":\"2026-12-30\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0463\",\"date\":\"2026-12-30\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0464\",\"date\":\"2026-12-30\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0465\",\"date\":\"2026-12-30\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0466\",\"date\":\"2026-12-30\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0467\",\"date\":\"2026-12-31\",\"time\":\"1:00p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0468\",\"date\":\"2026-12-31\",\"time\":\"3:00p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0469\",\"date\":\"2026-12-31\",\"time\":\"3:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0470\",\"date\":\"2026-12-31\",\"time\":\"3:00p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0471\",\"date\":\"2026-12-31\",\"time\":\"4:00p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0472\",\"date\":\"2026-12-31\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0473\",\"date\":\"2026-12-31\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0474\",\"date\":\"2026-12-31\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0475\",\"date\":\"2026-12-31\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0476\",\"date\":\"2027-01-01\",\"time\":\"5:00p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0477\",\"date\":\"2027-01-01\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0478\",\"date\":\"2027-01-01\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0479\",\"date\":\"2027-01-01\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0480\",\"date\":\"2027-01-01\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0481\",\"date\":\"2027-01-01\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0482\",\"date\":\"2027-01-02\",\"time\":\"1:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0483\",\"date\":\"2027-01-02\",\"time\":\"5:00p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0484\",\"date\":\"2027-01-02\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0485\",\"date\":\"2027-01-02\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0486\",\"date\":\"2027-01-02\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0487\",\"date\":\"2027-01-02\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0488\",\"date\":\"2027-01-02\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0489\",\"date\":\"2027-01-02\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0490\",\"date\":\"2027-01-02\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0491\",\"date\":\"2027-01-02\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0492\",\"date\":\"2027-01-03\",\"time\":\"5:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0493\",\"date\":\"2027-01-03\",\"time\":\"5:30p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0494\",\"date\":\"2027-01-03\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0495\",\"date\":\"2027-01-03\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0496\",\"date\":\"2027-01-03\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0497\",\"date\":\"2027-01-03\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0498\",\"date\":\"2027-01-03\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0499\",\"date\":\"2027-01-03\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0500\",\"date\":\"2027-01-04\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0501\",\"date\":\"2027-01-04\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0502\",\"date\":\"2027-01-04\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0503\",\"date\":\"2027-01-04\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0504\",\"date\":\"2027-01-04\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0505\",\"date\":\"2027-01-04\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0506\",\"date\":\"2027-01-05\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0507\",\"date\":\"2027-01-05\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0508\",\"date\":\"2027-01-05\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0509\",\"date\":\"2027-01-05\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0510\",\"date\":\"2027-01-05\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0511\",\"date\":\"2027-01-05\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0512\",\"date\":\"2027-01-05\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0513\",\"date\":\"2027-01-05\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0514\",\"date\":\"2027-01-05\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0515\",\"date\":\"2027-01-06\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0516\",\"date\":\"2027-01-06\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0517\",\"date\":\"2027-01-06\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0518\",\"date\":\"2027-01-06\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0519\",\"date\":\"2027-01-06\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0520\",\"date\":\"2027-01-07\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0521\",\"date\":\"2027-01-07\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0522\",\"date\":\"2027-01-07\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0523\",\"date\":\"2027-01-07\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0524\",\"date\":\"2027-01-07\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0525\",\"date\":\"2027-01-07\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0526\",\"date\":\"2027-01-07\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0527\",\"date\":\"2027-01-07\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0528\",\"date\":\"2027-01-07\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0529\",\"date\":\"2027-01-07\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0530\",\"date\":\"2027-01-07\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0531\",\"date\":\"2027-01-07\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0532\",\"date\":\"2027-01-08\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0533\",\"date\":\"2027-01-08\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0534\",\"date\":\"2027-01-08\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0535\",\"date\":\"2027-01-08\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0536\",\"date\":\"2027-01-08\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0537\",\"date\":\"2027-01-08\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0538\",\"date\":\"2027-01-08\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0539\",\"date\":\"2027-01-08\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0540\",\"date\":\"2027-01-09\",\"time\":\"5:00p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0541\",\"date\":\"2027-01-09\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0542\",\"date\":\"2027-01-09\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0543\",\"date\":\"2027-01-09\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0544\",\"date\":\"2027-01-09\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0545\",\"date\":\"2027-01-09\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0546\",\"date\":\"2027-01-10\",\"time\":\"3:00p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0547\",\"date\":\"2027-01-10\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0548\",\"date\":\"2027-01-10\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0549\",\"date\":\"2027-01-10\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0550\",\"date\":\"2027-01-10\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0551\",\"date\":\"2027-01-10\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0552\",\"date\":\"2027-01-10\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0553\",\"date\":\"2027-01-10\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0554\",\"date\":\"2027-01-11\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0555\",\"date\":\"2027-01-11\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0556\",\"date\":\"2027-01-11\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0557\",\"date\":\"2027-01-11\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0558\",\"date\":\"2027-01-11\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0559\",\"date\":\"2027-01-11\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0560\",\"date\":\"2027-01-12\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0561\",\"date\":\"2027-01-12\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0562\",\"date\":\"2027-01-12\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0563\",\"date\":\"2027-01-12\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0564\",\"date\":\"2027-01-12\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0565\",\"date\":\"2027-01-12\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0566\",\"date\":\"2027-01-12\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0567\",\"date\":\"2027-01-12\",\"time\":\"11:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0568\",\"date\":\"2027-01-13\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0569\",\"date\":\"2027-01-13\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0570\",\"date\":\"2027-01-13\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0571\",\"date\":\"2027-01-13\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0572\",\"date\":\"2027-01-13\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0573\",\"date\":\"2027-01-13\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0574\",\"date\":\"2027-01-13\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0575\",\"date\":\"2027-01-14\",\"time\":\"2:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"SAS\",\"arena\":\"Accor Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0576\",\"date\":\"2027-01-14\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0577\",\"date\":\"2027-01-14\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0578\",\"date\":\"2027-01-14\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0579\",\"date\":\"2027-01-14\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0580\",\"date\":\"2027-01-14\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0581\",\"date\":\"2027-01-14\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0582\",\"date\":\"2027-01-14\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0583\",\"date\":\"2027-01-14\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0584\",\"date\":\"2027-01-15\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0585\",\"date\":\"2027-01-15\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0586\",\"date\":\"2027-01-15\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0587\",\"date\":\"2027-01-15\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0588\",\"date\":\"2027-01-15\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0589\",\"date\":\"2027-01-15\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0590\",\"date\":\"2027-01-15\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0591\",\"date\":\"2027-01-15\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0592\",\"date\":\"2027-01-16\",\"time\":\"12:30p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0593\",\"date\":\"2027-01-16\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0594\",\"date\":\"2027-01-16\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0595\",\"date\":\"2027-01-16\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0596\",\"date\":\"2027-01-16\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0597\",\"date\":\"2027-01-16\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0598\",\"date\":\"2027-01-17\",\"time\":\"10:30a\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"NOP\",\"arena\":\"NO DISPONIBLE\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0599\",\"date\":\"2027-01-17\",\"time\":\"1:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0600\",\"date\":\"2027-01-17\",\"time\":\"3:30p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0601\",\"date\":\"2027-01-17\",\"time\":\"3:30p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0602\",\"date\":\"2027-01-17\",\"time\":\"5:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0603\",\"date\":\"2027-01-17\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0604\",\"date\":\"2027-01-17\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0605\",\"date\":\"2027-01-17\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0606\",\"date\":\"2027-01-18\",\"time\":\"12:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0607\",\"date\":\"2027-01-18\",\"time\":\"2:30p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0608\",\"date\":\"2027-01-18\",\"time\":\"3:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0609\",\"date\":\"2027-01-18\",\"time\":\"5:00p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0610\",\"date\":\"2027-01-18\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0611\",\"date\":\"2027-01-18\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0612\",\"date\":\"2027-01-18\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0613\",\"date\":\"2027-01-19\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0614\",\"date\":\"2027-01-19\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0615\",\"date\":\"2027-01-19\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0616\",\"date\":\"2027-01-19\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0617\",\"date\":\"2027-01-19\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0618\",\"date\":\"2027-01-19\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0619\",\"date\":\"2027-01-19\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0620\",\"date\":\"2027-01-20\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0621\",\"date\":\"2027-01-20\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0622\",\"date\":\"2027-01-20\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0623\",\"date\":\"2027-01-20\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0624\",\"date\":\"2027-01-20\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0625\",\"date\":\"2027-01-20\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0626\",\"date\":\"2027-01-20\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0627\",\"date\":\"2027-01-20\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0628\",\"date\":\"2027-01-20\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0629\",\"date\":\"2027-01-20\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0630\",\"date\":\"2027-01-21\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0631\",\"date\":\"2027-01-21\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0632\",\"date\":\"2027-01-21\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0633\",\"date\":\"2027-01-21\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0634\",\"date\":\"2027-01-22\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0635\",\"date\":\"2027-01-22\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0636\",\"date\":\"2027-01-22\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0637\",\"date\":\"2027-01-22\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0638\",\"date\":\"2027-01-22\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0639\",\"date\":\"2027-01-22\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0640\",\"date\":\"2027-01-22\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0641\",\"date\":\"2027-01-22\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0642\",\"date\":\"2027-01-22\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0643\",\"date\":\"2027-01-22\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0644\",\"date\":\"2027-01-22\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0645\",\"date\":\"2027-01-23\",\"time\":\"5:00p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0646\",\"date\":\"2027-01-23\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0647\",\"date\":\"2027-01-23\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0648\",\"date\":\"2027-01-23\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0649\",\"date\":\"2027-01-23\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0650\",\"date\":\"2027-01-23\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0651\",\"date\":\"2027-01-24\",\"time\":\"3:30p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0652\",\"date\":\"2027-01-24\",\"time\":\"4:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0653\",\"date\":\"2027-01-24\",\"time\":\"4:00p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0654\",\"date\":\"2027-01-24\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0655\",\"date\":\"2027-01-24\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0656\",\"date\":\"2027-01-24\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0657\",\"date\":\"2027-01-24\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0658\",\"date\":\"2027-01-25\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0659\",\"date\":\"2027-01-25\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0660\",\"date\":\"2027-01-25\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0661\",\"date\":\"2027-01-25\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0662\",\"date\":\"2027-01-25\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0663\",\"date\":\"2027-01-25\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0664\",\"date\":\"2027-01-25\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0665\",\"date\":\"2027-01-25\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0666\",\"date\":\"2027-01-26\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0667\",\"date\":\"2027-01-26\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0668\",\"date\":\"2027-01-26\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0669\",\"date\":\"2027-01-26\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0670\",\"date\":\"2027-01-26\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0671\",\"date\":\"2027-01-26\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0672\",\"date\":\"2027-01-26\",\"time\":\"11:00p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0673\",\"date\":\"2027-01-27\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0674\",\"date\":\"2027-01-27\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0675\",\"date\":\"2027-01-27\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0676\",\"date\":\"2027-01-27\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0677\",\"date\":\"2027-01-27\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0678\",\"date\":\"2027-01-27\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0679\",\"date\":\"2027-01-27\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0680\",\"date\":\"2027-01-27\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0681\",\"date\":\"2027-01-27\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0682\",\"date\":\"2027-01-28\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0683\",\"date\":\"2027-01-28\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0684\",\"date\":\"2027-01-28\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0685\",\"date\":\"2027-01-28\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0686\",\"date\":\"2027-01-28\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0687\",\"date\":\"2027-01-28\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0688\",\"date\":\"2027-01-28\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0689\",\"date\":\"2027-01-28\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0690\",\"date\":\"2027-01-29\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0691\",\"date\":\"2027-01-29\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0692\",\"date\":\"2027-01-29\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0693\",\"date\":\"2027-01-29\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0694\",\"date\":\"2027-01-29\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0695\",\"date\":\"2027-01-29\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0696\",\"date\":\"2027-01-30\",\"time\":\"12:30p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0697\",\"date\":\"2027-01-30\",\"time\":\"3:00p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0698\",\"date\":\"2027-01-30\",\"time\":\"5:30p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0699\",\"date\":\"2027-01-30\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0700\",\"date\":\"2027-01-30\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0701\",\"date\":\"2027-01-30\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0702\",\"date\":\"2027-01-30\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0703\",\"date\":\"2027-01-30\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0704\",\"date\":\"2027-01-31\",\"time\":\"3:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0705\",\"date\":\"2027-01-31\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0706\",\"date\":\"2027-01-31\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0707\",\"date\":\"2027-01-31\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0708\",\"date\":\"2027-01-31\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0709\",\"date\":\"2027-01-31\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0710\",\"date\":\"2027-01-31\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0711\",\"date\":\"2027-01-31\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0712\",\"date\":\"2027-02-01\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0713\",\"date\":\"2027-02-01\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0714\",\"date\":\"2027-02-01\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0715\",\"date\":\"2027-02-01\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0716\",\"date\":\"2027-02-01\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0717\",\"date\":\"2027-02-01\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0718\",\"date\":\"2027-02-01\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0719\",\"date\":\"2027-02-02\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0720\",\"date\":\"2027-02-02\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0721\",\"date\":\"2027-02-02\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0722\",\"date\":\"2027-02-02\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0723\",\"date\":\"2027-02-02\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0724\",\"date\":\"2027-02-02\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0725\",\"date\":\"2027-02-02\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0726\",\"date\":\"2027-02-02\",\"time\":\"11:00p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0727\",\"date\":\"2027-02-03\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0728\",\"date\":\"2027-02-03\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0729\",\"date\":\"2027-02-03\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0730\",\"date\":\"2027-02-03\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0731\",\"date\":\"2027-02-03\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0732\",\"date\":\"2027-02-03\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0733\",\"date\":\"2027-02-04\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0734\",\"date\":\"2027-02-04\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0735\",\"date\":\"2027-02-04\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0736\",\"date\":\"2027-02-04\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0737\",\"date\":\"2027-02-04\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0738\",\"date\":\"2027-02-04\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0739\",\"date\":\"2027-02-04\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0740\",\"date\":\"2027-02-04\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0741\",\"date\":\"2027-02-04\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0742\",\"date\":\"2027-02-04\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0743\",\"date\":\"2027-02-05\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0744\",\"date\":\"2027-02-05\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0745\",\"date\":\"2027-02-05\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0746\",\"date\":\"2027-02-05\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0747\",\"date\":\"2027-02-05\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0748\",\"date\":\"2027-02-05\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0749\",\"date\":\"2027-02-06\",\"time\":\"3:00p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0750\",\"date\":\"2027-02-06\",\"time\":\"3:00p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0751\",\"date\":\"2027-02-06\",\"time\":\"5:30p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0752\",\"date\":\"2027-02-06\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0753\",\"date\":\"2027-02-06\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0754\",\"date\":\"2027-02-06\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0755\",\"date\":\"2027-02-06\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0756\",\"date\":\"2027-02-06\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0757\",\"date\":\"2027-02-06\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0758\",\"date\":\"2027-02-07\",\"time\":\"3:00p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0759\",\"date\":\"2027-02-07\",\"time\":\"3:00p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0760\",\"date\":\"2027-02-07\",\"time\":\"3:30p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0761\",\"date\":\"2027-02-07\",\"time\":\"4:30p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0762\",\"date\":\"2027-02-07\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0763\",\"date\":\"2027-02-07\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0764\",\"date\":\"2027-02-07\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0765\",\"date\":\"2027-02-07\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0766\",\"date\":\"2027-02-08\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0767\",\"date\":\"2027-02-08\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0768\",\"date\":\"2027-02-08\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0769\",\"date\":\"2027-02-08\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0770\",\"date\":\"2027-02-08\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0771\",\"date\":\"2027-02-08\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0772\",\"date\":\"2027-02-08\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0773\",\"date\":\"2027-02-09\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0774\",\"date\":\"2027-02-09\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0775\",\"date\":\"2027-02-09\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0776\",\"date\":\"2027-02-09\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0777\",\"date\":\"2027-02-09\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0778\",\"date\":\"2027-02-09\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0779\",\"date\":\"2027-02-09\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0780\",\"date\":\"2027-02-09\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0781\",\"date\":\"2027-02-09\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0782\",\"date\":\"2027-02-09\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0783\",\"date\":\"2027-02-10\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0784\",\"date\":\"2027-02-10\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0785\",\"date\":\"2027-02-10\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0786\",\"date\":\"2027-02-10\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0787\",\"date\":\"2027-02-10\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0788\",\"date\":\"2027-02-10\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0789\",\"date\":\"2027-02-10\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0790\",\"date\":\"2027-02-11\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0791\",\"date\":\"2027-02-11\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0792\",\"date\":\"2027-02-11\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0793\",\"date\":\"2027-02-11\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0794\",\"date\":\"2027-02-11\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0795\",\"date\":\"2027-02-11\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0796\",\"date\":\"2027-02-11\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0797\",\"date\":\"2027-02-12\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0798\",\"date\":\"2027-02-12\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0799\",\"date\":\"2027-02-12\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0800\",\"date\":\"2027-02-12\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0801\",\"date\":\"2027-02-12\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0802\",\"date\":\"2027-02-12\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0803\",\"date\":\"2027-02-12\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0804\",\"date\":\"2027-02-12\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0805\",\"date\":\"2027-02-13\",\"time\":\"2:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0806\",\"date\":\"2027-02-13\",\"time\":\"3:00p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0807\",\"date\":\"2027-02-13\",\"time\":\"3:30p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0808\",\"date\":\"2027-02-13\",\"time\":\"5:30p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0809\",\"date\":\"2027-02-13\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0810\",\"date\":\"2027-02-13\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0811\",\"date\":\"2027-02-13\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0812\",\"date\":\"2027-02-14\",\"time\":\"1:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0813\",\"date\":\"2027-02-14\",\"time\":\"1:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0814\",\"date\":\"2027-02-14\",\"time\":\"1:00p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0815\",\"date\":\"2027-02-14\",\"time\":\"1:00p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0816\",\"date\":\"2027-02-14\",\"time\":\"2:00p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0817\",\"date\":\"2027-02-14\",\"time\":\"2:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0818\",\"date\":\"2027-02-14\",\"time\":\"3:30p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0819\",\"date\":\"2027-02-15\",\"time\":\"12:00p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0820\",\"date\":\"2027-02-15\",\"time\":\"2:30p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0821\",\"date\":\"2027-02-15\",\"time\":\"5:00p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0822\",\"date\":\"2027-02-15\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0823\",\"date\":\"2027-02-15\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0824\",\"date\":\"2027-02-15\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0825\",\"date\":\"2027-02-15\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0826\",\"date\":\"2027-02-15\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0827\",\"date\":\"2027-02-16\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0828\",\"date\":\"2027-02-16\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0829\",\"date\":\"2027-02-16\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0830\",\"date\":\"2027-02-16\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0831\",\"date\":\"2027-02-16\",\"time\":\"11:00p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0832\",\"date\":\"2027-02-17\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0833\",\"date\":\"2027-02-17\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0834\",\"date\":\"2027-02-17\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0835\",\"date\":\"2027-02-17\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0836\",\"date\":\"2027-02-17\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0837\",\"date\":\"2027-02-17\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0838\",\"date\":\"2027-02-17\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0839\",\"date\":\"2027-02-17\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0840\",\"date\":\"2027-02-17\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0841\",\"date\":\"2027-02-17\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0842\",\"date\":\"2027-02-17\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0843\",\"date\":\"2027-02-17\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0844\",\"date\":\"2027-02-17\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0845\",\"date\":\"2027-02-18\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0846\",\"date\":\"2027-02-18\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0847\",\"date\":\"2027-02-18\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0848\",\"date\":\"2027-02-18\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0849\",\"date\":\"2027-02-25\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0850\",\"date\":\"2027-02-25\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0851\",\"date\":\"2027-02-25\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0852\",\"date\":\"2027-02-25\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0853\",\"date\":\"2027-02-25\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0854\",\"date\":\"2027-02-25\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0855\",\"date\":\"2027-02-25\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0856\",\"date\":\"2027-02-25\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0857\",\"date\":\"2027-02-25\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0858\",\"date\":\"2027-02-25\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0859\",\"date\":\"2027-02-26\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0860\",\"date\":\"2027-02-26\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0861\",\"date\":\"2027-02-26\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0862\",\"date\":\"2027-02-26\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"SAS\",\"arena\":\"Moody Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0863\",\"date\":\"2027-02-26\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0864\",\"date\":\"2027-02-26\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0865\",\"date\":\"2027-02-26\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0866\",\"date\":\"2027-02-27\",\"time\":\"3:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0867\",\"date\":\"2027-02-27\",\"time\":\"5:30p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0868\",\"date\":\"2027-02-27\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0869\",\"date\":\"2027-02-27\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0870\",\"date\":\"2027-02-27\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0871\",\"date\":\"2027-02-27\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0872\",\"date\":\"2027-02-28\",\"time\":\"1:00p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"SAS\",\"arena\":\"Moody Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0873\",\"date\":\"2027-02-28\",\"time\":\"3:30p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0874\",\"date\":\"2027-02-28\",\"time\":\"4:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0875\",\"date\":\"2027-02-28\",\"time\":\"4:30p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0876\",\"date\":\"2027-02-28\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0877\",\"date\":\"2027-02-28\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0878\",\"date\":\"2027-02-28\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0879\",\"date\":\"2027-02-28\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0880\",\"date\":\"2027-02-28\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0881\",\"date\":\"2027-03-01\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0882\",\"date\":\"2027-03-01\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0883\",\"date\":\"2027-03-01\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0884\",\"date\":\"2027-03-01\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0885\",\"date\":\"2027-03-01\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0886\",\"date\":\"2027-03-01\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0887\",\"date\":\"2027-03-02\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0888\",\"date\":\"2027-03-02\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0889\",\"date\":\"2027-03-02\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0890\",\"date\":\"2027-03-02\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0891\",\"date\":\"2027-03-02\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0892\",\"date\":\"2027-03-02\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0893\",\"date\":\"2027-03-02\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0894\",\"date\":\"2027-03-02\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0895\",\"date\":\"2027-03-02\",\"time\":\"11:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0896\",\"date\":\"2027-03-03\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0897\",\"date\":\"2027-03-03\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0898\",\"date\":\"2027-03-03\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0899\",\"date\":\"2027-03-03\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0900\",\"date\":\"2027-03-03\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0901\",\"date\":\"2027-03-03\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0902\",\"date\":\"2027-03-03\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0903\",\"date\":\"2027-03-04\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0904\",\"date\":\"2027-03-04\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0905\",\"date\":\"2027-03-04\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0906\",\"date\":\"2027-03-04\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0907\",\"date\":\"2027-03-04\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0908\",\"date\":\"2027-03-04\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0909\",\"date\":\"2027-03-04\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0910\",\"date\":\"2027-03-04\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0911\",\"date\":\"2027-03-05\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0912\",\"date\":\"2027-03-05\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0913\",\"date\":\"2027-03-05\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0914\",\"date\":\"2027-03-05\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0915\",\"date\":\"2027-03-05\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0916\",\"date\":\"2027-03-05\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0917\",\"date\":\"2027-03-06\",\"time\":\"3:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0918\",\"date\":\"2027-03-06\",\"time\":\"5:00p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0919\",\"date\":\"2027-03-06\",\"time\":\"5:30p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0920\",\"date\":\"2027-03-06\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0921\",\"date\":\"2027-03-06\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0922\",\"date\":\"2027-03-06\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0923\",\"date\":\"2027-03-06\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0924\",\"date\":\"2027-03-07\",\"time\":\"1:00p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0925\",\"date\":\"2027-03-07\",\"time\":\"3:30p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0926\",\"date\":\"2027-03-07\",\"time\":\"5:00p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0927\",\"date\":\"2027-03-07\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0928\",\"date\":\"2027-03-07\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0929\",\"date\":\"2027-03-07\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0930\",\"date\":\"2027-03-08\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0931\",\"date\":\"2027-03-08\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0932\",\"date\":\"2027-03-08\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0933\",\"date\":\"2027-03-08\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0934\",\"date\":\"2027-03-08\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0935\",\"date\":\"2027-03-08\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0936\",\"date\":\"2027-03-08\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0937\",\"date\":\"2027-03-08\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0938\",\"date\":\"2027-03-09\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0939\",\"date\":\"2027-03-09\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0940\",\"date\":\"2027-03-09\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0941\",\"date\":\"2027-03-09\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0942\",\"date\":\"2027-03-09\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0943\",\"date\":\"2027-03-09\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0944\",\"date\":\"2027-03-09\",\"time\":\"11:00p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0945\",\"date\":\"2027-03-10\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0946\",\"date\":\"2027-03-10\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0947\",\"date\":\"2027-03-10\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0948\",\"date\":\"2027-03-10\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0949\",\"date\":\"2027-03-10\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0950\",\"date\":\"2027-03-10\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0951\",\"date\":\"2027-03-10\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0952\",\"date\":\"2027-03-10\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0953\",\"date\":\"2027-03-11\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0954\",\"date\":\"2027-03-11\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0955\",\"date\":\"2027-03-11\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0956\",\"date\":\"2027-03-11\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0957\",\"date\":\"2027-03-11\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0958\",\"date\":\"2027-03-11\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0959\",\"date\":\"2027-03-11\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0960\",\"date\":\"2027-03-11\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0961\",\"date\":\"2027-03-11\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0962\",\"date\":\"2027-03-12\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0963\",\"date\":\"2027-03-12\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0964\",\"date\":\"2027-03-12\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0965\",\"date\":\"2027-03-12\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0966\",\"date\":\"2027-03-12\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0967\",\"date\":\"2027-03-12\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0968\",\"date\":\"2027-03-13\",\"time\":\"3:00p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0969\",\"date\":\"2027-03-13\",\"time\":\"3:00p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0970\",\"date\":\"2027-03-13\",\"time\":\"5:30p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0971\",\"date\":\"2027-03-13\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0972\",\"date\":\"2027-03-13\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0973\",\"date\":\"2027-03-13\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0974\",\"date\":\"2027-03-13\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0975\",\"date\":\"2027-03-13\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0976\",\"date\":\"2027-03-14\",\"time\":\"12:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0977\",\"date\":\"2027-03-14\",\"time\":\"2:30p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0978\",\"date\":\"2027-03-14\",\"time\":\"5:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0979\",\"date\":\"2027-03-14\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0980\",\"date\":\"2027-03-14\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0981\",\"date\":\"2027-03-14\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0982\",\"date\":\"2027-03-14\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0983\",\"date\":\"2027-03-15\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0984\",\"date\":\"2027-03-15\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0985\",\"date\":\"2027-03-15\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0986\",\"date\":\"2027-03-15\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0987\",\"date\":\"2027-03-15\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0988\",\"date\":\"2027-03-16\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0989\",\"date\":\"2027-03-16\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0990\",\"date\":\"2027-03-16\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0991\",\"date\":\"2027-03-16\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0992\",\"date\":\"2027-03-16\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0993\",\"date\":\"2027-03-16\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0994\",\"date\":\"2027-03-16\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0995\",\"date\":\"2027-03-16\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0996\",\"date\":\"2027-03-16\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0997\",\"date\":\"2027-03-16\",\"time\":\"11:00p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0998\",\"date\":\"2027-03-17\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-0999\",\"date\":\"2027-03-17\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1000\",\"date\":\"2027-03-17\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1001\",\"date\":\"2027-03-17\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1002\",\"date\":\"2027-03-17\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1003\",\"date\":\"2027-03-17\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1004\",\"date\":\"2027-03-17\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1005\",\"date\":\"2027-03-17\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1006\",\"date\":\"2027-03-18\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1007\",\"date\":\"2027-03-18\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1008\",\"date\":\"2027-03-18\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1009\",\"date\":\"2027-03-18\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1010\",\"date\":\"2027-03-18\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1011\",\"date\":\"2027-03-18\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1012\",\"date\":\"2027-03-18\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1013\",\"date\":\"2027-03-18\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1014\",\"date\":\"2027-03-18\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1015\",\"date\":\"2027-03-19\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1016\",\"date\":\"2027-03-19\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1017\",\"date\":\"2027-03-19\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1018\",\"date\":\"2027-03-19\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1019\",\"date\":\"2027-03-19\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1020\",\"date\":\"2027-03-19\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1021\",\"date\":\"2027-03-20\",\"time\":\"1:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1022\",\"date\":\"2027-03-20\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1023\",\"date\":\"2027-03-20\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1024\",\"date\":\"2027-03-20\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1025\",\"date\":\"2027-03-20\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1026\",\"date\":\"2027-03-20\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1027\",\"date\":\"2027-03-20\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1028\",\"date\":\"2027-03-21\",\"time\":\"3:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1029\",\"date\":\"2027-03-21\",\"time\":\"3:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1030\",\"date\":\"2027-03-21\",\"time\":\"5:00p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1031\",\"date\":\"2027-03-21\",\"time\":\"5:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1032\",\"date\":\"2027-03-21\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1033\",\"date\":\"2027-03-21\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1034\",\"date\":\"2027-03-21\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1035\",\"date\":\"2027-03-22\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1036\",\"date\":\"2027-03-22\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1037\",\"date\":\"2027-03-22\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1038\",\"date\":\"2027-03-22\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1039\",\"date\":\"2027-03-22\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1040\",\"date\":\"2027-03-22\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1041\",\"date\":\"2027-03-22\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1042\",\"date\":\"2027-03-22\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1043\",\"date\":\"2027-03-23\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1044\",\"date\":\"2027-03-23\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1045\",\"date\":\"2027-03-23\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1046\",\"date\":\"2027-03-23\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1047\",\"date\":\"2027-03-23\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1048\",\"date\":\"2027-03-23\",\"time\":\"11:00p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1049\",\"date\":\"2027-03-24\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1050\",\"date\":\"2027-03-24\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1051\",\"date\":\"2027-03-24\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1052\",\"date\":\"2027-03-24\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1053\",\"date\":\"2027-03-24\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1054\",\"date\":\"2027-03-24\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1055\",\"date\":\"2027-03-24\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1056\",\"date\":\"2027-03-24\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1057\",\"date\":\"2027-03-24\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1058\",\"date\":\"2027-03-24\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1059\",\"date\":\"2027-03-24\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1060\",\"date\":\"2027-03-25\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1061\",\"date\":\"2027-03-25\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1062\",\"date\":\"2027-03-25\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1063\",\"date\":\"2027-03-25\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1064\",\"date\":\"2027-03-25\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1065\",\"date\":\"2027-03-25\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1066\",\"date\":\"2027-03-25\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1067\",\"date\":\"2027-03-26\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1068\",\"date\":\"2027-03-26\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1069\",\"date\":\"2027-03-26\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1070\",\"date\":\"2027-03-26\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1071\",\"date\":\"2027-03-26\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1072\",\"date\":\"2027-03-26\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1073\",\"date\":\"2027-03-27\",\"time\":\"3:00p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1074\",\"date\":\"2027-03-27\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1075\",\"date\":\"2027-03-27\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1076\",\"date\":\"2027-03-27\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1077\",\"date\":\"2027-03-27\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1078\",\"date\":\"2027-03-27\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1079\",\"date\":\"2027-03-27\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1080\",\"date\":\"2027-03-28\",\"time\":\"12:30p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1081\",\"date\":\"2027-03-28\",\"time\":\"3:00p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1082\",\"date\":\"2027-03-28\",\"time\":\"3:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1083\",\"date\":\"2027-03-28\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1084\",\"date\":\"2027-03-28\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1085\",\"date\":\"2027-03-28\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1086\",\"date\":\"2027-03-28\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1087\",\"date\":\"2027-03-28\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1088\",\"date\":\"2027-03-28\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1089\",\"date\":\"2027-03-29\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1090\",\"date\":\"2027-03-29\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1091\",\"date\":\"2027-03-29\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1092\",\"date\":\"2027-03-29\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1093\",\"date\":\"2027-03-29\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1094\",\"date\":\"2027-03-29\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1095\",\"date\":\"2027-03-29\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1096\",\"date\":\"2027-03-29\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1097\",\"date\":\"2027-03-30\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1098\",\"date\":\"2027-03-30\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1099\",\"date\":\"2027-03-30\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1100\",\"date\":\"2027-03-30\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1101\",\"date\":\"2027-03-30\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1102\",\"date\":\"2027-03-30\",\"time\":\"11:00p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1103\",\"date\":\"2027-03-31\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1104\",\"date\":\"2027-03-31\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1105\",\"date\":\"2027-03-31\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1106\",\"date\":\"2027-03-31\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1107\",\"date\":\"2027-03-31\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1108\",\"date\":\"2027-03-31\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1109\",\"date\":\"2027-03-31\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1110\",\"date\":\"2027-03-31\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1111\",\"date\":\"2027-03-31\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1112\",\"date\":\"2027-03-31\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1113\",\"date\":\"2027-04-01\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1114\",\"date\":\"2027-04-01\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1115\",\"date\":\"2027-04-01\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1116\",\"date\":\"2027-04-01\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"LAL\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1117\",\"date\":\"2027-04-02\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1118\",\"date\":\"2027-04-02\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1119\",\"date\":\"2027-04-02\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1120\",\"date\":\"2027-04-02\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1121\",\"date\":\"2027-04-02\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1122\",\"date\":\"2027-04-02\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1123\",\"date\":\"2027-04-02\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1124\",\"date\":\"2027-04-02\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1125\",\"date\":\"2027-04-02\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1126\",\"date\":\"2027-04-02\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1127\",\"date\":\"2027-04-02\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1128\",\"date\":\"2027-04-02\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1129\",\"date\":\"2027-04-03\",\"time\":\"5:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1130\",\"date\":\"2027-04-03\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1131\",\"date\":\"2027-04-04\",\"time\":\"1:00p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1132\",\"date\":\"2027-04-04\",\"time\":\"2:00p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1133\",\"date\":\"2027-04-04\",\"time\":\"3:00p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1134\",\"date\":\"2027-04-04\",\"time\":\"3:00p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1135\",\"date\":\"2027-04-04\",\"time\":\"3:00p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1136\",\"date\":\"2027-04-04\",\"time\":\"3:30p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1137\",\"date\":\"2027-04-04\",\"time\":\"4:00p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1138\",\"date\":\"2027-04-04\",\"time\":\"4:30p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1139\",\"date\":\"2027-04-04\",\"time\":\"5:00p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1140\",\"date\":\"2027-04-04\",\"time\":\"5:00p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1141\",\"date\":\"2027-04-04\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1142\",\"date\":\"2027-04-04\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1143\",\"date\":\"2027-04-04\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"SAS\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1144\",\"date\":\"2027-04-05\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1145\",\"date\":\"2027-04-05\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"MIA\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1146\",\"date\":\"2027-04-05\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1147\",\"date\":\"2027-04-06\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1148\",\"date\":\"2027-04-06\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1149\",\"date\":\"2027-04-06\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1150\",\"date\":\"2027-04-06\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1151\",\"date\":\"2027-04-06\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1152\",\"date\":\"2027-04-06\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1153\",\"date\":\"2027-04-06\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1154\",\"date\":\"2027-04-06\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1155\",\"date\":\"2027-04-06\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1156\",\"date\":\"2027-04-06\",\"time\":\"10:30p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1157\",\"date\":\"2027-04-06\",\"time\":\"11:00p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1158\",\"date\":\"2027-04-07\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"DET\",\"arena\":\"Little Caesars Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1159\",\"date\":\"2027-04-07\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1160\",\"date\":\"2027-04-07\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1161\",\"date\":\"2027-04-07\",\"time\":\"7:30p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"TOR\",\"arena\":\"Scotiabank Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1162\",\"date\":\"2027-04-07\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1163\",\"date\":\"2027-04-07\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"MEM\",\"arena\":\"FedExForum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1164\",\"date\":\"2027-04-07\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1165\",\"date\":\"2027-04-07\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1166\",\"date\":\"2027-04-07\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"POR\",\"arena\":\"Moda Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1167\",\"date\":\"2027-04-08\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"PHI\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1168\",\"date\":\"2027-04-08\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"NYK\",\"ha\":\"MIL\",\"arena\":\"Fiserv Forum\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1169\",\"date\":\"2027-04-08\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"NOP\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1170\",\"date\":\"2027-04-08\",\"time\":\"9:00p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1171\",\"date\":\"2027-04-08\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1172\",\"date\":\"2027-04-09\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"BOS\",\"ha\":\"ATL\",\"arena\":\"State Farm Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1173\",\"date\":\"2027-04-09\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"BKN\",\"ha\":\"CHA\",\"arena\":\"Spectrum Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1174\",\"date\":\"2027-04-09\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"CLE\",\"ha\":\"IND\",\"arena\":\"Gainbridge Fieldhouse\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1175\",\"date\":\"2027-04-09\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1176\",\"date\":\"2027-04-09\",\"time\":\"7:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"ORL\",\"arena\":\"Kia Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1177\",\"date\":\"2027-04-09\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"CHI\",\"arena\":\"United Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1178\",\"date\":\"2027-04-09\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"WAS\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1179\",\"date\":\"2027-04-09\",\"time\":\"8:00p\",\"timezone\":\"ET\",\"aa\":\"GSW\",\"ha\":\"OKC\",\"arena\":\"Paycom Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1180\",\"date\":\"2027-04-09\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"HOU\",\"arena\":\"Toyota Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1181\",\"date\":\"2027-04-09\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"LAC\",\"ha\":\"UTA\",\"arena\":\"Delta Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1182\",\"date\":\"2027-04-09\",\"time\":\"9:30p\",\"timezone\":\"ET\",\"aa\":\"DEN\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1183\",\"date\":\"2027-04-09\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"MIN\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1184\",\"date\":\"2027-04-09\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"PHX\",\"arena\":\"Mortgage Matchup Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1185\",\"date\":\"2027-04-09\",\"time\":\"10:00p\",\"timezone\":\"ET\",\"aa\":\"DAL\",\"ha\":\"SAC\",\"arena\":\"Golden 1 Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1186\",\"date\":\"2027-04-11\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"DET\",\"ha\":\"WAS\",\"arena\":\"Capital One Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1187\",\"date\":\"2027-04-11\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"CHA\",\"ha\":\"PHI\",\"arena\":\"Xfinity Mobile Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1188\",\"date\":\"2027-04-11\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"IND\",\"ha\":\"NYK\",\"arena\":\"Madison Square Garden (IV)\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1189\",\"date\":\"2027-04-11\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"CHI\",\"ha\":\"NOP\",\"arena\":\"Smoothie King Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1190\",\"date\":\"2027-04-11\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"ORL\",\"ha\":\"MIA\",\"arena\":\"Kaseya Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1191\",\"date\":\"2027-04-11\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"ATL\",\"ha\":\"CLE\",\"arena\":\"Rocket Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1192\",\"date\":\"2027-04-11\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"TOR\",\"ha\":\"BKN\",\"arena\":\"Barclays Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1193\",\"date\":\"2027-04-11\",\"time\":\"6:00p\",\"timezone\":\"ET\",\"aa\":\"MIL\",\"ha\":\"BOS\",\"arena\":\"TD Garden\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1194\",\"date\":\"2027-04-11\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"UTA\",\"ha\":\"GSW\",\"arena\":\"Chase Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1195\",\"date\":\"2027-04-11\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"SAC\",\"ha\":\"LAC\",\"arena\":\"Intuit Dome\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1196\",\"date\":\"2027-04-11\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"PHX\",\"ha\":\"LAL\",\"arena\":\"Crypto.com Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1197\",\"date\":\"2027-04-11\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"OKC\",\"ha\":\"DEN\",\"arena\":\"Ball Arena\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1198\",\"date\":\"2027-04-11\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"HOU\",\"ha\":\"MIN\",\"arena\":\"Target Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1199\",\"date\":\"2027-04-11\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"MEM\",\"ha\":\"DAL\",\"arena\":\"American Airlines Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"},{\"id\":\"NBA2027-1200\",\"date\":\"2027-04-11\",\"time\":\"8:30p\",\"timezone\":\"ET\",\"aa\":\"POR\",\"ha\":\"SAS\",\"arena\":\"Frost Bank Center\",\"notes\":\"\",\"season\":\"2026-27\",\"status\":\"PROGRAMADO\",\"prediction\":\"PREDICCIÓN PENDIENTE\"}]");
var metrics_default = {
	metrics: {
		"n": 1230,
		"correct": 841,
		"acc": 68.37,
		"brier": .2074,
		"logloss": .603,
		"mae_pts": 9.63,
		"mae_margin": 11.4,
		"mae_total": 15.42
	},
	cuts: {
		"local": {
			"n": 753,
			"correct": 523,
			"acc": 69.46,
			"brier": .204,
			"logloss": .5958,
			"mae_pts": 9.65,
			"mae_margin": 11.15,
			"mae_total": 15.71
		},
		"visita": {
			"n": 477,
			"correct": 318,
			"acc": 66.67,
			"brier": .2128,
			"logloss": .6144,
			"mae_pts": 9.59,
			"mae_margin": 11.8,
			"mae_total": 14.97
		},
		"prorroga": {
			"n": 54,
			"correct": 32,
			"acc": 59.26,
			"brier": .2528,
			"logloss": .7021,
			"mae_pts": 13.74,
			"mae_margin": 6.06,
			"mae_total": 26.39
		},
		"fuerte": {
			"n": 61,
			"correct": 51,
			"acc": 83.61,
			"brier": .1469,
			"logloss": .4724,
			"mae_pts": 9.62,
			"mae_margin": 9.68,
			"mae_total": 16.79
		},
		"neutra": {
			"n": 543,
			"correct": 321,
			"acc": 59.12,
			"brier": .2378,
			"logloss": .668,
			"mae_pts": 9.65,
			"mae_margin": 11.79,
			"mae_total": 15.2
		}
	},
	cal: [
		{
			"label": "50–55%",
			"n": 275,
			"p": 52.5,
			"real": 53.5
		},
		{
			"label": "55–60%",
			"n": 297,
			"p": 57.3,
			"real": 64.6
		},
		{
			"label": "60–65%",
			"n": 209,
			"p": 62.4,
			"real": 65.1
		},
		{
			"label": "65–70%",
			"n": 178,
			"p": 67.4,
			"real": 77
		},
		{
			"label": "70–75%",
			"n": 132,
			"p": 72.3,
			"real": 82.6
		},
		{
			"label": "75%+",
			"n": 139,
			"p": 79.5,
			"real": 86.3
		}
	],
	layer: {
		"status": "PARTIAL",
		"verified_games": 1226,
		"coverage": 99.67,
		"players": 562,
		"out": 3622,
		"questionable": 1026,
		"doubtful": 248,
		"probable": 289,
		"minutes_limit": 0,
		"returning": 0,
		"adj_mean": 0,
		"adj_abs_mean": 0,
		"adj_max": 0,
		"missing_date": "2025-12-11"
	},
	base_metrics: {
		"n": 1230,
		"correct": 831,
		"acc": 67.56,
		"brier": .2053,
		"logloss": .5971,
		"mae_pts": 9.75,
		"mae_margin": 11.59,
		"mae_total": 15.78
	}
};
/** Hora de calendario en America/New_York. El schedule está en ET. */
function etDateISO(now = /* @__PURE__ */ new Date()) {
	const parts = new Intl.DateTimeFormat("en-CA", {
		timeZone: "America/New_York",
		year: "numeric",
		month: "2-digit",
		day: "2-digit"
	}).formatToParts(now);
	const get = (t) => parts.find((p) => p.type === t)?.value ?? "";
	return `${get("year")}-${get("month")}-${get("day")}`;
}
function addDays(iso, days) {
	const [y, m, d] = iso.split("-").map(Number);
	return new Date(Date.UTC(y, m - 1, d + days)).toISOString().slice(0, 10);
}
function parseClock(time) {
	const m = time.trim().match(/^(\d{1,2}):(\d{2})\s*([ap])m?$/i);
	if (!m) return "00:00";
	let h = Number(m[1]) % 12;
	if (m[3].toLowerCase() === "p") h += 12;
	return `${String(h).padStart(2, "0")}:${m[2]}`;
}
function tipInstant(date, time) {
	const hhmm = parseClock(time);
	const [y, mo, d] = date.split("-").map(Number);
	const [h, mi] = hhmm.split(":").map(Number);
	const utc = Date.UTC(y, mo - 1, d, h, mi, 0);
	const dtf = new Intl.DateTimeFormat("en-US", {
		timeZone: "America/New_York",
		hour12: false,
		year: "numeric",
		month: "2-digit",
		day: "2-digit",
		hour: "2-digit",
		minute: "2-digit",
		second: "2-digit"
	});
	const parts = Object.fromEntries(dtf.formatToParts(new Date(utc)).map((p) => [p.type, p.value]));
	let hour = Number(parts.hour);
	if (hour === 24) hour = 0;
	const offset = Date.UTC(Number(parts.year), Number(parts.month) - 1, Number(parts.day), hour, Number(parts.minute), Number(parts.second)) - utc;
	return new Date(utc - offset);
}
function withinFreezeWindow(now, date, time) {
	const tip = tipInstant(date, time).getTime();
	const t = now.getTime();
	return t >= tip - 54e5 && t < tip;
}
function tipReached(now, date, time) {
	return now.getTime() >= tipInstant(date, time).getTime();
}
function sameEtDay(now, date) {
	return etDateISO(now) === date;
}
var RANKING = ranking_default;
var SEASON = season_2027_default;
var METRICS_BUNDLE = metrics_default;
var byId = new Map(SEASON.map((g) => [g.id, g]));
function scheduleGame(id, extras = []) {
	return extras.find((g) => g.id === id) ?? byId.get(id);
}
function gamesOnDate(date, extras = []) {
	return [...SEASON, ...extras].filter((g) => g.date === date).sort((a, b) => parseClock(a.time).localeCompare(parseClock(b.time)) || a.id.localeCompare(b.id));
}
function closureRatings() {
	const out = {};
	for (const t of RANKING) out[t.abbr] = {
		team: t.team,
		abbr: t.abbr,
		w: 0,
		l: 0,
		rating: t.rating,
		ortg: t.ortg,
		drtg: t.drtg,
		pace: t.pace,
		form: t.form,
		source: "cierre 2025-26"
	};
	return out;
}
function teamName(abbr) {
	return RANKING.find((t) => t.abbr === abbr)?.team ?? abbr;
}
/**
* Parámetros protegidos del motor PREDICTA NBA v1.1.
* Recuperados del builder embebido auditado. No modificar.
* LOCAL FALLBACK — NO SOURCE OF TRUTH.
* Los archivos build_predicta.py / build_v11.py no están en este paquete.
*/
var ENGINE_MARK = "LOCAL FALLBACK — NO SOURCE OF TRUTH";
var MODEL_VERSION = "PREDICTA-NBA-v1.1-operational";
var MODEL_PARAMETERS = {
	scale: 28,
	homePts: 3,
	neutralPts: 0,
	K: 18,
	cap: 32,
	pScale: 11.5,
	leaguePrior: 113.5,
	movA: 2.2,
	movB: .001,
	eloDiv: 400,
	weightRating: .6,
	weightEfficiency: .3,
	weightForm: .1,
	fallbackRating: .9,
	fallbackForm: .1,
	ortgOwn: .65,
	drtgOpp: .35,
	paceWindow: .7,
	paceL5: .3,
	minWindowN: 5,
	fourFactorsWeight: .2,
	fourFactorsCap: 3.5,
	restCap: 1.5,
	restMinN: 25,
	travelCap: .6
};
/** Registro congelado v1.1. No recalcular. */
var FROZEN_V11 = {
	season: "2025-26",
	n: 1230,
	correct: 841,
	acc: 68.37,
	brier: .2074,
	logloss: .603,
	maePts: 9.63,
	maeMargin: 11.4,
	maeTotal: 15.42
};
var SCHEDULE_CONTRACT = {
	defined: 1200,
	pendingOfficial: 30,
	expected: 1230,
	coverage: "PARTIAL_OFFICIAL",
	preseason: false,
	first: "2026-10-20",
	last: "2027-04-11"
};
/**
* LOCAL FALLBACK — NO SOURCE OF TRUTH.
* Copia fiel del motor recuperado en el HTML auditado (projectV11 / builderUpdate).
* No es una fórmula nueva. Four Factors, rest y travel no entran:
* el snapshot operativo no trae muestra validada.
*/
function builderUpdate(rh, ra, neutral, homeWin, actualMargin) {
	const rdiff = rh + (neutral ? MODEL_PARAMETERS.neutralPts : MODEL_PARAMETERS.homePts) * MODEL_PARAMETERS.scale - ra;
	const expected = 1 / (1 + Math.exp(-(rdiff / MODEL_PARAMETERS.eloDiv)));
	const movMult = Math.log(Math.abs(actualMargin) + 1) * (MODEL_PARAMETERS.movA / (MODEL_PARAMETERS.movA + MODEL_PARAMETERS.movB * Math.abs(rdiff)));
	let delta = MODEL_PARAMETERS.K * movMult * ((homeWin ? 1 : 0) - expected);
	delta = Math.max(-MODEL_PARAMETERS.cap, Math.min(MODEL_PARAMETERS.cap, delta));
	return {
		home: rh + delta,
		away: ra - delta,
		delta
	};
}
function lookAheadCheck(gameId, snapshot) {
	if (!snapshot || snapshot.game_id !== gameId || snapshot.result_used) return "REJECTED_LOOKAHEAD";
	if (snapshot.home_pts != null || snapshot.away_pts != null || snapshot.winner) return "REJECTED_LOOKAHEAD";
	if (snapshot.box_score != null || snapshot.post_cutoff) return "REJECTED_LOOKAHEAD";
	if (!snapshot.cutoff_timestamp) return "REJECTED_LOOKAHEAD";
	return "PASS";
}
function projectV11(snap) {
	const homePrior = snap.neutral ? MODEL_PARAMETERS.neutralPts : MODEL_PARAMETERS.homePts;
	const ratingMargin = (snap.rating_home + homePrior * MODEL_PARAMETERS.scale - snap.rating_away) / MODEL_PARAMETERS.scale;
	const formMargin = snap.form_margin || 0;
	const ready = !!snap.window_home && !!snap.window_away && snap.window_home.n >= MODEL_PARAMETERS.minWindowN && snap.window_away.n >= MODEL_PARAMETERS.minWindowN && !!snap.window_home_l5 && !!snap.window_away_l5;
	let margin;
	let total;
	let fallback = true;
	if (ready && snap.window_home && snap.window_away && snap.window_home_l5 && snap.window_away_l5) {
		fallback = false;
		const pace = MODEL_PARAMETERS.paceWindow * ((snap.window_home.pace + snap.window_away.pace) / 2) + MODEL_PARAMETERS.paceL5 * ((snap.window_home_l5.pace + snap.window_away_l5.pace) / 2);
		const ortgH = MODEL_PARAMETERS.ortgOwn * snap.window_home.ortg + MODEL_PARAMETERS.drtgOpp * snap.window_away.drtg;
		const ortgA = MODEL_PARAMETERS.ortgOwn * snap.window_away.ortg + MODEL_PARAMETERS.drtgOpp * snap.window_home.drtg;
		const ptsH = ortgH / 100 * pace;
		const ptsA = ortgA / 100 * pace;
		total = ptsH + ptsA;
		margin = MODEL_PARAMETERS.weightRating * ratingMargin + MODEL_PARAMETERS.weightEfficiency * (ptsH - ptsA) + MODEL_PARAMETERS.weightForm * formMargin;
	} else {
		margin = MODEL_PARAMETERS.fallbackRating * ratingMargin + MODEL_PARAMETERS.fallbackForm * formMargin;
		total = (snap.league_pts || MODEL_PARAMETERS.leaguePrior) * 2;
	}
	const projHome = (total + margin) / 2;
	const pHome = 1 / (1 + Math.exp(-(margin / MODEL_PARAMETERS.pScale)));
	const pick = pHome >= .5 ? snap.home : snap.away;
	const pPick = pHome >= .5 ? pHome : 1 - pHome;
	return {
		projected_home: +projHome.toFixed(1),
		projected_away: +(total - projHome).toFixed(1),
		projected_total: +total.toFixed(1),
		projected_margin: +margin.toFixed(1),
		margin_raw: margin,
		p_home: +(pHome * 100).toFixed(1),
		p_away: +((1 - pHome) * 100).toFixed(1),
		pick,
		p_pick: +(pPick * 100).toFixed(1),
		confidence: "NEUTRA",
		uncertainty: "ALTA",
		fallback,
		model_version: MODEL_VERSION,
		engine_mark: ENGINE_MARK,
		model_state: "PREGAME"
	};
}
function buildPregameSnapshot(game, cutoff, home, away, version) {
	return {
		gameId: game.id,
		game_id: game.id,
		version,
		season: "2026-27",
		date: game.date,
		time: game.time,
		timezone: game.timezone,
		away: game.aa,
		home: game.ha,
		away_team: game.aa,
		home_team: game.ha,
		arena: game.arena,
		neutral: !!game.neutral,
		rating_home: home.rating,
		rating_away: away.rating,
		form_home: home.form,
		form_away: away.form,
		form_margin: 0,
		offense_home: home.ortg,
		offense_away: away.ortg,
		defense_home: home.drtg,
		defense_away: away.drtg,
		pace_home: home.pace,
		pace_away: away.pace,
		four_factors_home: null,
		four_factors_away: null,
		four_factors_status: "NOT VALIDATED",
		rest_home: null,
		rest_away: null,
		rest_status: "NOT VALIDATED",
		travel_home: null,
		travel_away: null,
		travel_status: "NOT VALIDATED",
		b2b_home: false,
		b2b_away: false,
		availability: "NOT APPLIED",
		availability_status: "NOT AVAILABLE",
		impact_applied: false,
		cutoff,
		cutoff_timestamp: cutoff,
		timestamp: cutoff,
		model_version: MODEL_VERSION,
		engine_mark: ENGINE_MARK,
		model_parameters: {
			scale: MODEL_PARAMETERS.scale,
			home_pts: MODEL_PARAMETERS.homePts,
			K: MODEL_PARAMETERS.K,
			cap: MODEL_PARAMETERS.cap,
			p_scale: MODEL_PARAMETERS.pScale,
			league_prior: MODEL_PARAMETERS.leaguePrior
		},
		model_state: "PREGAME",
		result_used: false,
		n_home: 0,
		n_away: 0,
		league_pts: MODEL_PARAMETERS.leaguePrior
	};
}
function predictionFingerprint(p) {
	return JSON.stringify({
		m: p.projected_margin,
		raw: p.margin_raw,
		t: p.projected_total,
		h: p.p_home,
		a: p.p_away,
		pick: p.pick,
		c: p.confidence,
		cut: p.cutoff,
		sv: p.snapshot_version
	});
}
function blankOverlay() {
	return {
		status: "PROGRAMADO",
		info: [],
		snapshots: [],
		predictionHistory: []
	};
}
function createInitialState() {
	return {
		version: 1,
		ready: false,
		schedulerEnabled: false,
		realPredictionsEnabled: false,
		overlays: {},
		ratings: closureRatings(),
		audit: [],
		schedulerLog: [],
		sandboxReport: null,
		seq: 1
	};
}
function overlayOf(state, id) {
	return state.overlays[id] ?? blankOverlay();
}
function stamp(state, partial) {
	const entry = {
		...partial,
		id: `A${state.seq}`
	};
	return {
		state: {
			...state,
			seq: state.seq + 1,
			audit: [...state.audit, entry]
		},
		entry
	};
}
function commit(state, gameId, ov, partial) {
	return {
		...stamp(state, {
			...partial,
			gameId
		}).state,
		overlays: {
			...state.overlays,
			[gameId]: ov
		}
	};
}
function infoRevision(timestamp) {
	return {
		timestamp,
		availability: "NOT AVAILABLE",
		questionable: "NOT AVAILABLE",
		doubtful: "NOT AVAILABLE",
		probable: "NOT AVAILABLE",
		out: "NOT AVAILABLE",
		minutes: "NOT AVAILABLE",
		impact: "NOT VALIDATED",
		rest: "NOT VALIDATED",
		travel: "NOT VALIDATED",
		market: {
			moneyline: null,
			spread: null,
			total: null,
			movement: null,
			role: "INFORMACIÓN / AUDITORÍA"
		},
		source: "sin fuente prepartido 2026-27 — no inventada"
	};
}
function reject(state, gameId, from, action, error) {
	return {
		state: stamp(state, {
			timestamp: (/* @__PURE__ */ new Date()).toISOString(),
			gameId,
			action,
			from,
			to: from,
			source: "orquestador",
			result: error,
			error
		}).state,
		step: {
			gameId,
			action,
			from,
			to: from,
			result: error,
			error
		}
	};
}
function auditMath(pred, result, home) {
	const y = result.winner === home ? 1 : 0;
	const p = Math.min(1 - 1e-6, Math.max(1e-6, pred.p_home / 100));
	const margin = result.home_pts - result.away_pts;
	return {
		pts_error: +((Math.abs(pred.projected_home - result.home_pts) + Math.abs(pred.projected_away - result.away_pts)) / 2).toFixed(2),
		margin_error: +Math.abs(pred.projected_margin - margin).toFixed(2),
		total_error: +Math.abs(pred.projected_total - (result.home_pts + result.away_pts)).toFixed(2),
		hit: pred.pick === result.winner,
		brier: +((p - y) ** 2).toFixed(4),
		logloss: +(-(y * Math.log(p) + (1 - y) * Math.log(1 - p))).toFixed(4)
	};
}
function productionCounts(state) {
	let predictions = 0;
	let frozen = 0;
	let finals = 0;
	let updates = 0;
	for (const [id, ov] of Object.entries(state.overlays)) {
		if (id.startsWith("SANDBOX")) continue;
		if (ov.prediction || ov.frozen) predictions += 1;
		if (ov.frozen) frozen += 1;
		if (ov.status === "FINALIZADO" || ov.status === "ACTUALIZADO" || ov.status === "AUDITADO") finals += 1;
		if (ov.status === "ACTUALIZADO" || ov.status === "AUDITADO") updates += 1;
	}
	return {
		predictions,
		frozen,
		finals,
		updates
	};
}
function stepGame(state, gameId, now, opts = {}) {
	const game = scheduleGame(gameId, opts.sandboxGames);
	if (!game) return reject(state, gameId, "ERROR", "GAME_MISSING", "partido no definido");
	if (!opts.sandbox && !state.realPredictionsEnabled) return reject(state, gameId, overlayOf(state, gameId).status, "BLOCKED_PRODUCTION_CLOSED", "producción cerrada");
	const ov = overlayOf(state, gameId);
	const from = ov.status;
	if (!(opts.sandbox || opts.forceWindow || sameEtDay(now, game.date)) && (from === "PROGRAMADO" || from === "DATOS_ACTUALIZADOS" || from === "PREDICCIÓN_PENDIENTE" || from === "PREDICCIÓN_GENERADA")) return reject(state, gameId, from, "FUERA_DE_VENTANA", "el día del partido todavía no es el día operativo ET");
	if (from === "PROGRAMADO") return {
		state: commit(state, gameId, {
			...ov,
			status: "DATOS_ACTUALIZADOS",
			info: [...ov.info, infoRevision(now.toISOString())]
		}, {
			timestamp: now.toISOString(),
			action: "SNAPSHOT_INFO",
			from,
			to: "DATOS_ACTUALIZADOS",
			source: "sin fuente inventada",
			result: "disponibilidad NOT AVAILABLE"
		}),
		step: {
			gameId,
			action: "SNAPSHOT_INFO",
			from,
			to: "DATOS_ACTUALIZADOS",
			result: "PASS"
		}
	};
	if (from === "DATOS_ACTUALIZADOS") return {
		state: commit(state, gameId, {
			...ov,
			status: "PREDICCIÓN_PENDIENTE"
		}, {
			timestamp: now.toISOString(),
			action: "PREDICTION_READY",
			from,
			to: "PREDICCIÓN_PENDIENTE",
			source: "orquestador",
			result: "listo para snapshot"
		}),
		step: {
			gameId,
			action: "PREDICTION_READY",
			from,
			to: "PREDICCIÓN_PENDIENTE",
			result: "PASS"
		}
	};
	if (from === "PREDICCIÓN_PENDIENTE") {
		if (ov.prediction || ov.frozen) return reject(state, gameId, from, "REJECTED_DUPLICATE", "ya existe una predicción activa");
		const home = state.ratings[game.ha];
		const away = state.ratings[game.aa];
		if (!home || !away) return reject(state, gameId, from, "MISSING_TEAM", "estado de equipo ausente");
		const snap = buildPregameSnapshot(game, now.toISOString(), home, away, ov.snapshots.length + 1);
		const la = lookAheadCheck(gameId, snap);
		if (la !== "PASS") return {
			state: commit(state, gameId, {
				...ov,
				status: "ERROR",
				snapshots: [...ov.snapshots, snap],
				errorNote: la
			}, {
				timestamp: now.toISOString(),
				action: "LOOKAHEAD_REJECTED",
				from,
				to: "ERROR",
				source: "lookAheadCheck",
				result: la,
				error: la
			}),
			step: {
				gameId,
				action: "LOOKAHEAD_REJECTED",
				from,
				to: "ERROR",
				result: la,
				error: la
			}
		};
		const projected = projectV11(snap);
		const prediction = {
			...projected,
			predicted_winner: projected.pick,
			timestamp: now.toISOString(),
			cutoff: snap.cutoff,
			snapshot_version: snap.version,
			lookahead_status: la,
			inputs_snapshot: snap
		};
		return {
			state: commit(state, gameId, {
				...ov,
				status: "PREDICCIÓN_GENERADA",
				snapshots: [...ov.snapshots, snap],
				prediction,
				predictionHistory: [...ov.predictionHistory, prediction]
			}, {
				timestamp: now.toISOString(),
				action: "PREDICTION_GENERATED",
				from,
				to: "PREDICCIÓN_GENERADA",
				source: prediction.engine_mark,
				result: `${prediction.pick} ${prediction.p_pick}`
			}),
			step: {
				gameId,
				action: "PREDICTION_GENERATED",
				from,
				to: "PREDICCIÓN_GENERADA",
				result: "PASS"
			}
		};
	}
	if (from === "PREDICCIÓN_GENERADA") {
		if (ov.frozen) return reject(state, gameId, from, "REJECTED_ALREADY_FROZEN", "REJECTED_ALREADY_FROZEN");
		if (!ov.prediction) return reject(state, gameId, from, "MISSING_PREDICTION", "no hay predicción activa");
		if (!(opts.forceFreeze || withinFreezeWindow(now, game.date, game.time))) return reject(state, gameId, from, "FREEZE_WAITING_WINDOW", "congelación solo en los últimos 90 minutos o por orden explícita de sandbox");
		const frozen = structuredClone(ov.prediction);
		return {
			state: commit(state, gameId, {
				...ov,
				status: "PREDICCIÓN_CONGELADA",
				frozen
			}, {
				timestamp: now.toISOString(),
				action: "PREDICTION_FROZEN",
				from,
				to: "PREDICCIÓN_CONGELADA",
				source: "freezePrediction",
				result: "PASS"
			}),
			step: {
				gameId,
				action: "PREDICTION_FROZEN",
				from,
				to: "PREDICCIÓN_CONGELADA",
				result: "PASS"
			}
		};
	}
	if (from === "PREDICCIÓN_CONGELADA") {
		if (!ov.frozen) return reject(state, gameId, from, "MISSING_FREEZE", "freeze ausente");
		if (!opts.forceFreeze && !tipReached(now, game.date, game.time)) return reject(state, gameId, from, "WAITING_TIP", "todavía no es el tip");
		return {
			state: commit(state, gameId, {
				...ov,
				status: "EN_ESPERA_RESULTADO"
			}, {
				timestamp: now.toISOString(),
				action: "AWAITING_RESULT",
				from,
				to: "EN_ESPERA_RESULTADO",
				source: "scheduler",
				result: "resultado NOT AVAILABLE"
			}),
			step: {
				gameId,
				action: "AWAITING_RESULT",
				from,
				to: "EN_ESPERA_RESULTADO",
				result: "PASS"
			}
		};
	}
	if (from === "EN_ESPERA_RESULTADO") return reject(state, gameId, from, "RESULT_NOT_AVAILABLE", "no hay resultado oficial. No se inventa marcador.");
	if (from === "FINALIZADO") {
		if (!ov.frozen || !ov.result) return reject(state, gameId, from, "UPDATE_BLOCKED", "falta freeze o resultado");
		const before = predictionFingerprint(ov.frozen);
		const home = state.ratings[game.ha];
		const away = state.ratings[game.aa];
		if (!home || !away) return reject(state, gameId, from, "MISSING_TEAM", "estado de equipo ausente");
		const upd = builderUpdate(home.rating, away.rating, !!game.neutral, ov.result.winner === game.ha, ov.result.home_pts - ov.result.away_pts);
		const ratings = {
			...state.ratings,
			[game.ha]: {
				...home,
				rating: +upd.home.toFixed(4),
				w: home.w + (ov.result.winner === game.ha ? 1 : 0),
				l: home.l + (ov.result.winner === game.ha ? 0 : 1)
			},
			[game.aa]: {
				...away,
				rating: +upd.away.toFixed(4),
				w: away.w + (ov.result.winner === game.aa ? 1 : 0),
				l: away.l + (ov.result.winner === game.aa ? 0 : 1)
			}
		};
		const math = auditMath(ov.frozen, ov.result, game.ha);
		const nextOv = {
			...ov,
			status: "ACTUALIZADO",
			auditMath: math
		};
		if (predictionFingerprint(nextOv.frozen) !== before) return reject(state, gameId, from, "FREEZE_REWRITTEN", "NO MODIFICADO — la predicción congelada cambió");
		return {
			state: commit({
				...state,
				ratings
			}, gameId, nextOv, {
				timestamp: now.toISOString(),
				action: "STATE_UPDATED",
				from,
				to: "ACTUALIZADO",
				source: "builderUpdate",
				result: `delta rating local ${upd.delta.toFixed(2)}`
			}),
			step: {
				gameId,
				action: "STATE_UPDATED",
				from,
				to: "ACTUALIZADO",
				result: "PASS"
			}
		};
	}
	if (from === "ACTUALIZADO") return {
		state: commit(state, gameId, {
			...ov,
			status: "AUDITADO"
		}, {
			timestamp: now.toISOString(),
			action: "AUDITED",
			from,
			to: "AUDITADO",
			source: "auditoría",
			result: ov.auditMath ? `hit=${ov.auditMath.hit}` : "sin métrica"
		}),
		step: {
			gameId,
			action: "AUDITED",
			from,
			to: "AUDITADO",
			result: "PASS"
		}
	};
	if (from === "AUDITADO") return {
		state,
		step: {
			gameId,
			action: "NO_ACTION",
			from,
			to: from,
			result: "ya auditado"
		}
	};
	return reject(state, gameId, from, "NO_TRANSITION", "estado sin transición automática");
}
function operatorFreeze(state, gameId, now, opts = {}) {
	return stepGame(state, gameId, now, {
		...opts,
		forceFreeze: true
	});
}
function freezeAgain(state, gameId) {
	const ov = overlayOf(state, gameId);
	if (ov.frozen || ov.status === "PREDICCIÓN_CONGELADA" || ov.status === "EN_ESPERA_RESULTADO" || ov.status === "FINALIZADO" || ov.status === "ACTUALIZADO" || ov.status === "AUDITADO") return reject(state, gameId, ov.status, "REJECTED_ALREADY_FROZEN", "REJECTED_ALREADY_FROZEN");
	return reject(state, gameId, ov.status, "FREEZE_NOT_READY", "no hay predicción congelable");
}
function ingestResult(state, gameId, result, opts = {}) {
	if (!opts.sandbox && !state.realPredictionsEnabled) return reject(state, gameId, overlayOf(state, gameId).status, "BLOCKED_PRODUCTION_CLOSED", "producción cerrada");
	const game = scheduleGame(gameId, opts.sandboxGames);
	if (!game) return reject(state, gameId, "ERROR", "GAME_MISSING", "partido no definido");
	const ov = overlayOf(state, gameId);
	if (ov.result) return reject(state, gameId, ov.status, "REJECTED_DUPLICATE_RESULT", "ya existe un resultado");
	if (ov.status !== "EN_ESPERA_RESULTADO") return reject(state, gameId, ov.status, "RESULT_OUT_OF_ORDER", "el resultado solo entra en EN_ESPERA_RESULTADO");
	if (!Number.isInteger(result.home_pts) || !Number.isInteger(result.away_pts) || result.home_pts < 0 || result.away_pts < 0) return reject(state, gameId, ov.status, "RESULT_INVALID", "marcador inválido");
	if (result.home_pts === result.away_pts) return reject(state, gameId, ov.status, "RESULT_INVALID", "la NBA no empata");
	const winner = result.home_pts > result.away_pts ? game.ha : game.aa;
	if (result.winner !== winner) return reject(state, gameId, ov.status, "RESULT_INVALID", "ganador no coincide con el marcador");
	if (!result.source.trim()) return reject(state, gameId, ov.status, "RESULT_INVALID", "falta fuente");
	return {
		state: commit(state, gameId, {
			...ov,
			status: "FINALIZADO",
			result: {
				...result,
				winner
			}
		}, {
			timestamp: result.timestamp,
			action: "RESULT_RECEIVED",
			from: ov.status,
			to: "FINALIZADO",
			source: result.source,
			result: `${result.away_pts}-${result.home_pts}`
		}),
		step: {
			gameId,
			action: "RESULT_RECEIVED",
			from: ov.status,
			to: "FINALIZADO",
			result: "PASS"
		}
	};
}
function refreshInfo(state, gameId, now, opts = {}) {
	if (!opts.sandbox && !state.realPredictionsEnabled) return reject(state, gameId, overlayOf(state, gameId).status, "BLOCKED_PRODUCTION_CLOSED", "producción cerrada");
	const ov = overlayOf(state, gameId);
	if ([
		"PREDICCIÓN_CONGELADA",
		"EN_ESPERA_RESULTADO",
		"FINALIZADO",
		"ACTUALIZADO",
		"AUDITADO"
	].includes(ov.status)) return reject(state, gameId, ov.status, "INFO_IGNORED_FROZEN", "la predicción congelada no se reabre");
	if (ov.status === "PROGRAMADO") return stepGame(state, gameId, now, opts);
	const cleared = ov.status === "PREDICCIÓN_GENERADA";
	return {
		state: commit(state, gameId, {
			...ov,
			status: "DATOS_ACTUALIZADOS",
			info: [...ov.info, infoRevision(now.toISOString())],
			prediction: void 0
		}, {
			timestamp: now.toISOString(),
			action: cleared ? "INFO_REVISED_PREDICTION_CLEARED" : "INFO_REVISED",
			from: ov.status,
			to: "DATOS_ACTUALIZADOS",
			source: "sin fuente inventada",
			result: "nueva revisión. Sin lesiones inventadas."
		}),
		step: {
			gameId,
			action: "INFO_REVISED",
			from: ov.status,
			to: "DATOS_ACTUALIZADOS",
			result: "PASS"
		}
	};
}
function processDay(state, date, now, opts = {}) {
	const games = gamesOnDate(date, opts.sandboxGames).filter((g) => opts.sandbox ? g.id.startsWith("SANDBOX") : !g.id.startsWith("SANDBOX"));
	if (!opts.sandbox && !state.realPredictionsEnabled) {
		const note = `DRY RUN ${date}: ${games.length} partidos. Producción cerrada. Ningún estado de partido cambió.`;
		const log = {
			timestamp: now.toISOString(),
			note
		};
		return {
			state: {
				...state,
				schedulerLog: [...state.schedulerLog, log]
			},
			steps: games.map((g) => ({
				gameId: g.id,
				action: "BLOCKED_PRODUCTION_CLOSED",
				from: overlayOf(state, g.id).status,
				to: overlayOf(state, g.id).status,
				result: "producción cerrada"
			}))
		};
	}
	let cursor = state;
	const steps = [];
	for (const g of games) {
		const out = stepGame(cursor, g.id, now, opts);
		cursor = out.state;
		steps.push(out.step);
	}
	const log = {
		timestamp: now.toISOString(),
		note: `PROCESS ${date}: ${steps.map((s) => `${s.gameId}:${s.action}`).join(" · ") || "sin partidos"}`
	};
	return {
		state: {
			...cursor,
			schedulerLog: [...cursor.schedulerLog, log]
		},
		steps
	};
}
function checkCompletedGames(state) {
	return Object.entries(state.overlays).filter(([id, ov]) => !id.startsWith("SANDBOX") && ov.status === "EN_ESPERA_RESULTADO" && !ov.result).map(([gameId]) => ({
		gameId,
		source: "NOT AVAILABLE"
	}));
}
var CADENCE_GENERAL = 108e5;
var CADENCE_LATE = 36e5;
var CADENCE_CRITICAL = 18e5;
function schedulerCadenceMs(state, now) {
	const games = gamesOnDate(etDateISO(now)).filter((g) => !g.id.startsWith("SANDBOX"));
	let ms = CADENCE_GENERAL;
	for (const g of games) {
		const status = overlayOf(state, g.id).status;
		const until = tipInstant(g.date, g.time).getTime() - now.getTime();
		if (status === "EN_ESPERA_RESULTADO" || status === "FINALIZADO" || until <= 54e5 && until > -144e5) ms = Math.min(ms, CADENCE_CRITICAL);
		else if (until > 0 && until <= 216e5) ms = Math.min(ms, CADENCE_LATE);
	}
	return ms;
}
function schedulerTickDue(state, now) {
	if (!state.schedulerEnabled || !state.realPredictionsEnabled) return false;
	const last = state.schedulerLog[state.schedulerLog.length - 1];
	if (!last) return true;
	const at = Date.parse(last.timestamp);
	if (!Number.isFinite(at)) return true;
	return now.getTime() - at >= schedulerCadenceMs(state, now);
}
function schedulerTick(state, now) {
	if (!state.schedulerEnabled || !state.realPredictionsEnabled) {
		const note = state.schedulerEnabled ? "tick ignorado: predicciones reales apagadas" : "tick ignorado: scheduler apagado";
		return {
			state: {
				...state,
				schedulerLog: [...state.schedulerLog, {
					timestamp: now.toISOString(),
					note
				}]
			},
			steps: []
		};
	}
	return processDay(state, etDateISO(now), now);
}
function setProduction(state, enabled, now) {
	return {
		...stamp(state, {
			timestamp: now.toISOString(),
			gameId: "SYSTEM",
			action: enabled ? "PRODUCTION_ON" : "PRODUCTION_OFF",
			from: String(state.realPredictionsEnabled),
			to: String(enabled),
			source: "activación manual",
			result: enabled ? "predicciones reales habilitadas" : "predicciones reales cerradas"
		}).state,
		realPredictionsEnabled: enabled,
		schedulerEnabled: enabled ? state.schedulerEnabled : false,
		activatedAt: enabled ? now.toISOString() : state.activatedAt
	};
}
function setScheduler(state, enabled, now) {
	if (enabled && !state.realPredictionsEnabled) return stamp(state, {
		timestamp: now.toISOString(),
		gameId: "SYSTEM",
		action: "SCHEDULER_REJECTED",
		from: "false",
		to: "false",
		source: "activación manual",
		result: "no se enciende el scheduler con producción cerrada",
		error: "PRODUCTION_CLOSED"
	}).state;
	return {
		...stamp(state, {
			timestamp: now.toISOString(),
			gameId: "SYSTEM",
			action: enabled ? "SCHEDULER_ON" : "SCHEDULER_OFF",
			from: String(state.schedulerEnabled),
			to: String(enabled),
			source: "activación manual",
			result: enabled ? "scheduler encendido" : "scheduler apagado"
		}).state,
		schedulerEnabled: enabled
	};
}
var SANDBOX_GAMES = [{
	id: "SANDBOX-1",
	date: "2099-01-01",
	time: "12:00p",
	timezone: "ET",
	aa: "BOS",
	ha: "DET",
	arena: "SANDBOX",
	notes: "",
	season: "sandbox",
	status: "PROGRAMADO",
	prediction: "PREDICCIÓN PENDIENTE"
}, {
	id: "SANDBOX-2",
	date: "2099-01-01",
	time: "3:00p",
	timezone: "ET",
	aa: "NYK",
	ha: "MIA",
	arena: "SANDBOX",
	notes: "",
	season: "sandbox",
	status: "PROGRAMADO",
	prediction: "PREDICCIÓN PENDIENTE"
}];
function advance(state, id, now, opts) {
	return stepGame(state, id, now, {
		sandbox: true,
		sandboxGames: SANDBOX_GAMES,
		forceWindow: true,
		...opts
	});
}
function executeSandbox() {
	const untouched = JSON.stringify(closureRatings());
	let state = createInitialState();
	const now = /* @__PURE__ */ new Date("2099-01-01T16:00:00Z");
	const opts = {
		sandbox: true,
		sandboxGames: SANDBOX_GAMES,
		forceWindow: true
	};
	let pass = true;
	for (let i = 0; i < 3; i++) {
		const out = advance(state, "SANDBOX-1", now);
		state = out.state;
		pass = pass && out.step.result === "PASS";
	}
	const pred = overlayOf(state, "SANDBOX-1").prediction;
	const snap = pred?.inputs_snapshot ?? buildPregameSnapshot(SANDBOX_GAMES[0], now.toISOString(), state.ratings.DET, state.ratings.BOS, 1);
	const lookaheadPass = lookAheadCheck("SANDBOX-1", snap) === "PASS";
	const lookaheadRejectedWinner = lookAheadCheck("SANDBOX-1", {
		...snap,
		winner: "DET"
	}) === "REJECTED_LOOKAHEAD";
	const lookaheadRejectedPoints = lookAheadCheck("SANDBOX-1", {
		...snap,
		home_pts: 110,
		away_pts: 100
	}) === "REJECTED_LOOKAHEAD";
	const lookaheadRejectedResult = lookAheadCheck("SANDBOX-1", {
		...snap,
		result_used: true
	}) === "REJECTED_LOOKAHEAD";
	const lookaheadRejectedPost = lookAheadCheck("SANDBOX-1", {
		...snap,
		post_cutoff: true,
		box_score: { pts: 1 }
	}) === "REJECTED_LOOKAHEAD";
	const frozenStep = advance(state, "SANDBOX-1", now, { forceFreeze: true });
	state = frozenStep.state;
	const freeze = frozenStep.step.result === "PASS" && !!overlayOf(state, "SANDBOX-1").frozen;
	const second = freezeAgain(state, "SANDBOX-1");
	state = second.state;
	const secondFreeze = second.step.error === "REJECTED_ALREADY_FROZEN" ? "REJECTED_ALREADY_FROZEN" : "FAIL";
	const finger = overlayOf(state, "SANDBOX-1").frozen ? predictionFingerprint(overlayOf(state, "SANDBOX-1").frozen) : "";
	state = advance(state, "SANDBOX-1", /* @__PURE__ */ new Date("2099-01-01T18:00:00Z")).state;
	state = ingestResult(state, "SANDBOX-1", {
		home_pts: 110,
		away_pts: 100,
		winner: "DET",
		source: "sandbox",
		timestamp: "2099-01-01T20:00:00Z"
	}, opts).state;
	const updated = advance(state, "SANDBOX-1", /* @__PURE__ */ new Date("2099-01-01T20:05:00Z"));
	state = updated.state;
	const after = overlayOf(state, "SANDBOX-1").frozen ? predictionFingerprint(overlayOf(state, "SANDBOX-1").frozen) : "";
	const frozenIntact = !!finger && finger === after;
	state = advance(state, "SANDBOX-1", /* @__PURE__ */ new Date("2099-01-01T20:06:00Z")).state;
	const serialized = JSON.stringify(state);
	const restored = JSON.parse(serialized);
	const persist = predictionFingerprint(restored.overlays["SANDBOX-1"].frozen) === finger;
	let iso = createInitialState();
	for (let i = 0; i < 3; i++) iso = advance(iso, "SANDBOX-1", now).state;
	iso = advance(iso, "SANDBOX-1", now, { forceFreeze: true }).state;
	const fingerA = overlayOf(iso, "SANDBOX-1").frozen ? predictionFingerprint(overlayOf(iso, "SANDBOX-1").frozen) : "";
	for (let i = 0; i < 3; i++) iso = advance(iso, "SANDBOX-2", now).state;
	const predB = overlayOf(iso, "SANDBOX-2").prediction;
	const isolation = !!fingerA && !!predB && predictionFingerprint(overlayOf(iso, "SANDBOX-1").frozen) === fingerA && predB.inputs_snapshot.home === "MIA" && predB.inputs_snapshot.away === "NYK" && overlayOf(iso, "SANDBOX-1").info !== overlayOf(iso, "SANDBOX-2").info;
	const day = processDay(createInitialState(), "2099-01-01", now, {
		...opts,
		sandboxGames: SANDBOX_GAMES
	});
	const dayOk = day.steps.length === 2 && day.steps.every((s) => s.gameId.startsWith("SANDBOX"));
	delete state.overlays["SANDBOX-1"];
	delete state.overlays["SANDBOX-2"];
	const purged = !state.overlays["SANDBOX-1"] && !state.overlays["SANDBOX-2"];
	const ratingsUntouched = JSON.stringify(closureRatings()) === untouched;
	const real = productionCounts(createInitialState());
	return {
		ran: pass && !!pred && pred.fallback === true,
		lookaheadPass,
		lookaheadRejectedWinner,
		lookaheadRejectedPoints,
		lookaheadRejectedResult,
		lookaheadRejectedPost,
		prediction: !!pred && pred.lookahead_status === "PASS",
		freeze,
		secondFreeze,
		update: updated.step.result === "PASS",
		frozenIntact,
		persist,
		restart: persist && restored.overlays["SANDBOX-1"].status === "AUDITADO",
		isolation: isolation && dayOk,
		purged,
		ratingsUntouched,
		realPredictions: real.predictions,
		realFrozen: real.frozen,
		realFinals: real.finals,
		realUpdates: real.updates,
		note: "SANDBOX-1 y SANDBOX-2 se ejecutaron en memoria y se descartaron. No entran al calendario."
	};
}
var KEY = "predicta-nba-ops-v1";
/** Orden explícita del operador. No reabre la producción si después se cierra. */
var OPERATOR_ORDER = "2026-10-05-predicciones";
var SCHEDULER_ORDER = "2026-10-05-scheduler";
function authorize(state) {
	if (state.activationOrder === OPERATOR_ORDER) return state;
	return {
		...state.realPredictionsEnabled ? state : setProduction(state, true, /* @__PURE__ */ new Date()),
		activationOrder: OPERATOR_ORDER
	};
}
function armScheduler(state) {
	if (state.schedulerOrder === SCHEDULER_ORDER) return state;
	if (!state.realPredictionsEnabled) return state;
	return schedulerTick({
		...state.schedulerEnabled ? state : setScheduler(state, true, /* @__PURE__ */ new Date()),
		schedulerOrder: SCHEDULER_ORDER
	}, /* @__PURE__ */ new Date()).state;
}
function apply(next) {
	const current = useOps.getState();
	const clean = {
		version: 1,
		ready: true,
		schedulerEnabled: next.schedulerEnabled,
		realPredictionsEnabled: next.realPredictionsEnabled,
		activatedAt: next.activatedAt,
		activationOrder: next.activationOrder ?? current.activationOrder,
		schedulerOrder: next.schedulerOrder ?? current.schedulerOrder,
		overlays: next.overlays,
		ratings: next.ratings,
		audit: next.audit,
		schedulerLog: next.schedulerLog,
		sandboxReport: current.sandboxReport,
		seq: next.seq
	};
	const payload = {
		version: 1,
		schedulerEnabled: clean.schedulerEnabled,
		realPredictionsEnabled: clean.realPredictionsEnabled,
		activatedAt: clean.activatedAt,
		activationOrder: clean.activationOrder,
		schedulerOrder: clean.schedulerOrder,
		overlays: clean.overlays,
		ratings: clean.ratings,
		audit: clean.audit,
		schedulerLog: clean.schedulerLog,
		seq: clean.seq
	};
	localStorage.setItem(KEY, JSON.stringify(payload));
	useOps.setState(clean);
}
var useOps = create((set, get) => ({
	...createInitialState(),
	viewDate: "2026-10-20",
	dateTouched: false,
	hydrate: () => {
		const base = createInitialState();
		let next = base;
		try {
			const raw = localStorage.getItem(KEY);
			if (raw) {
				const saved = JSON.parse(raw);
				if (saved.version === 1 && saved.overlays && saved.ratings) {
					const overlays = { ...saved.overlays };
					for (const key of Object.keys(overlays)) if (key.startsWith("SANDBOX")) delete overlays[key];
					const moved = Object.values(overlays).some((o) => o.status === "ACTUALIZADO" || o.status === "AUDITADO");
					next = {
						...base,
						schedulerEnabled: !!saved.schedulerEnabled && !!saved.realPredictionsEnabled,
						realPredictionsEnabled: !!saved.realPredictionsEnabled,
						activatedAt: saved.activatedAt,
						activationOrder: saved.activationOrder,
						schedulerOrder: saved.schedulerOrder,
						overlays,
						ratings: moved ? saved.ratings : closureRatings(),
						audit: Array.isArray(saved.audit) ? saved.audit : [],
						schedulerLog: Array.isArray(saved.schedulerLog) ? saved.schedulerLog : [],
						seq: saved.seq || 1
					};
				}
			}
		} catch {
			next = base;
		}
		let report = null;
		try {
			report = executeSandbox();
		} catch (error) {
			report = {
				ran: false,
				lookaheadPass: false,
				lookaheadRejectedWinner: false,
				lookaheadRejectedPoints: false,
				lookaheadRejectedResult: false,
				lookaheadRejectedPost: false,
				prediction: false,
				freeze: false,
				secondFreeze: "FAIL",
				update: false,
				frozenIntact: false,
				persist: false,
				restart: false,
				isolation: false,
				purged: false,
				ratingsUntouched: false,
				realPredictions: -1,
				realFrozen: -1,
				realFinals: -1,
				realUpdates: -1,
				note: error instanceof Error ? error.message : "sandbox falló"
			};
		}
		const touched = useOps.getState().dateTouched;
		const keptDate = useOps.getState().viewDate;
		apply(armScheduler(authorize(next)));
		set({
			ready: true,
			sandboxReport: report,
			viewDate: touched ? keptDate : etDateISO(),
			dateTouched: touched
		});
	},
	setViewDate: (date) => set({
		viewDate: date,
		dateTouched: true
	}),
	processSelectedDay: () => {
		const cur = get();
		apply(processDay(cur, cur.viewDate, /* @__PURE__ */ new Date()).state);
	},
	step: (id) => {
		apply(stepGame(get(), id, /* @__PURE__ */ new Date()).state);
	},
	freeze: (id) => {
		apply(operatorFreeze(get(), id, /* @__PURE__ */ new Date()).state);
	},
	revise: (id) => {
		apply(refreshInfo(get(), id, /* @__PURE__ */ new Date()).state);
	},
	saveResult: (id, homePts, awayPts, source) => {
		const cur = get();
		const game = scheduleGame(id);
		if (!game) return "partido no definido";
		const out = ingestResult(cur, id, {
			home_pts: homePts,
			away_pts: awayPts,
			winner: homePts > awayPts ? game.ha : game.aa,
			source,
			timestamp: (/* @__PURE__ */ new Date()).toISOString()
		});
		apply(out.state);
		return out.step.error ?? null;
	},
	enableProduction: (on) => apply(setProduction(get(), on, /* @__PURE__ */ new Date())),
	enableScheduler: (on) => apply(setScheduler(get(), on, /* @__PURE__ */ new Date())),
	tick: (manual) => {
		const cur = get();
		const now = /* @__PURE__ */ new Date();
		if (manual !== true && !schedulerTickDue(cur, now)) return;
		apply(schedulerTick(cur, now).state);
	}
}));
var NAV = [
	["/", "Portada"],
	["/hoy", "Hoy"],
	["/calendario", "Calendario"],
	["/predicciones", "Predicciones"],
	["/partidos", "Partidos"],
	["/numeros", "Números"],
	["/equipos", "Equipos"],
	["/jugadores", "Jugadores"],
	["/auditoria", "Auditoría"],
	["/sistema", "Sistema"],
	["/scheduler", "Scheduler"]
];
function Shell({ children }) {
	const hydrate = useOps((s) => s.hydrate);
	const ready = useOps((s) => s.ready);
	const live = useOps((s) => s.realPredictionsEnabled);
	const scheduled = useOps((s) => s.schedulerEnabled);
	const path = useRouterState({ select: (s) => s.location.pathname });
	const once = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (once.current) return;
		once.current = true;
		hydrate();
	}, [hydrate]);
	(0, import_react.useEffect)(() => {
		if (!ready || !live || !scheduled) return;
		const run = () => useOps.getState().tick(false);
		run();
		const id = window.setInterval(run, 6e4);
		return () => window.clearInterval(id);
	}, [
		ready,
		live,
		scheduled
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-ink text-bone",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "sticky top-0 z-20 border-b border-line bg-ink/95 backdrop-blur",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl flex-wrap items-center gap-4 px-4 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "sr-only",
							children: "PREDICTA NBA"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xl",
							children: "PREDICTA NBA"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Orquestador operativo · motor v1.1 · no es una casa de apuestas"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
						tone: !ready ? "muted" : live ? "bad" : "accent",
						children: !ready ? "CARGANDO" : live ? "PRODUCCIÓN ABIERTA" : "PRODUCCIÓN CERRADA"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pill, {
						tone: !ready ? "muted" : scheduled ? "accent" : "muted",
						children: !ready ? "…" : scheduled ? "SCHEDULER ON" : "SCHEDULER OFF"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "mx-auto flex max-w-6xl gap-2 overflow-x-auto px-4 pb-3",
				"aria-label": "Secciones",
				children: NAV.map(([href, label]) => {
					const on = href === "/" ? path === "/" : path === href || path.startsWith(`${href}/`);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: href,
						className: cn("inline-flex h-11 shrink-0 items-center rounded-full border px-3 text-sm", on ? "border-bone bg-bone text-ink" : "border-line text-muted"),
						children: label
					}, href);
				})
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "mx-auto max-w-6xl px-4 py-6",
			children
		})]
	});
}
var styles_default = "/assets/styles-6T9zKXrY.css";
var Route$13 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "PREDICTA NBA" },
			{
				name: "description",
				content: "Orquestador operativo PREDICTA NBA. Motor v1.1. Predicciones reales por partido, el día operativo."
			},
			{
				name: "theme-color",
				content: "#0b0c0a"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600&family=Outfit:wght@360;480;560&display=swap"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "es",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$12 = () => import("./routes-BeW6SfcG.mjs");
var Route$12 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$12, "component") });
var $$splitComponentImporter$11 = () => import("./auditoria-BOQ6nD2g.mjs");
var Route$11 = createFileRoute("/auditoria")({ component: lazyRouteComponent($$splitComponentImporter$11, "component") });
var $$splitComponentImporter$10 = () => import("./calendario-BtYErJIL.mjs");
var Route$10 = createFileRoute("/calendario")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./equipos-BmbW9SZA.mjs");
var Route$9 = createFileRoute("/equipos")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./hoy-DQgotFkk.mjs");
var Route$8 = createFileRoute("/hoy")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./jugadores-Eue00a44.mjs");
var Route$7 = createFileRoute("/jugadores")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./numeros-hk1HhATd.mjs");
var Route$6 = createFileRoute("/numeros")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./partidos-B6QjbNoT.mjs");
var Route$5 = createFileRoute("/partidos")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./predicciones-C5JJq2pP.mjs");
var Route$4 = createFileRoute("/predicciones")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./scheduler-BuT4WPrH.mjs");
var Route$3 = createFileRoute("/scheduler")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./sistema-D1w5lqwe.mjs");
var Route$2 = createFileRoute("/sistema")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./historico._key-PVJQdjSp.mjs");
var Route$1 = createFileRoute("/historico/$key")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./partido._gameId-9eJqkbcQ.mjs");
var Route = createFileRoute("/partido/$gameId")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$12.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$13
	}),
	AuditoriaRoute: Route$11.update({
		id: "/auditoria",
		path: "/auditoria",
		getParentRoute: () => Route$13
	}),
	CalendarioRoute: Route$10.update({
		id: "/calendario",
		path: "/calendario",
		getParentRoute: () => Route$13
	}),
	EquiposRoute: Route$9.update({
		id: "/equipos",
		path: "/equipos",
		getParentRoute: () => Route$13
	}),
	HoyRoute: Route$8.update({
		id: "/hoy",
		path: "/hoy",
		getParentRoute: () => Route$13
	}),
	JugadoresRoute: Route$7.update({
		id: "/jugadores",
		path: "/jugadores",
		getParentRoute: () => Route$13
	}),
	NumerosRoute: Route$6.update({
		id: "/numeros",
		path: "/numeros",
		getParentRoute: () => Route$13
	}),
	PartidosRoute: Route$5.update({
		id: "/partidos",
		path: "/partidos",
		getParentRoute: () => Route$13
	}),
	PrediccionesRoute: Route$4.update({
		id: "/predicciones",
		path: "/predicciones",
		getParentRoute: () => Route$13
	}),
	SchedulerRoute: Route$3.update({
		id: "/scheduler",
		path: "/scheduler",
		getParentRoute: () => Route$13
	}),
	SistemaRoute: Route$2.update({
		id: "/sistema",
		path: "/sistema",
		getParentRoute: () => Route$13
	}),
	HistoricoKeyRoute: Route$1.update({
		id: "/historico/$key",
		path: "/historico/$key",
		getParentRoute: () => Route$13
	}),
	PartidoGameIdRoute: Route.update({
		id: "/partido/$gameId",
		path: "/partido/$gameId",
		getParentRoute: () => Route$13
	})
};
var routeTree = Route$13._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { td as C, statusTone as S, cn as T, Foot as _, checkCompletedGames as a, Stat as b, FROZEN_V11 as c, RANKING as d, SEASON as f, Banner as g, addDays as h, useOps as i, SCHEDULE_CONTRACT as l, teamName as m, Route as n, overlayOf as o, gamesOnDate as p, Route$1 as r, productionCounts as s, router_exports as t, METRICS_BUNDLE as u, Pager as v, th as w, TableWrap as x, Pill as y };
