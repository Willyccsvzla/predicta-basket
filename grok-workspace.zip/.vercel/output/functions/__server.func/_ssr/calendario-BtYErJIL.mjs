import { n as Calendario } from "./ops-pages-DtgvNp5Y.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/calendario-BtYErJIL.js
var SplitComponent = Calendario;
//#endregion
export { SplitComponent as component };
