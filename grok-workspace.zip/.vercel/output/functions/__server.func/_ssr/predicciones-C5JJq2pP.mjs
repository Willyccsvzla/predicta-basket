import { s as Predicciones } from "./ops-pages-DtgvNp5Y.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/predicciones-C5JJq2pP.js
var SplitComponent = Predicciones;
//#endregion
export { SplitComponent as component };
