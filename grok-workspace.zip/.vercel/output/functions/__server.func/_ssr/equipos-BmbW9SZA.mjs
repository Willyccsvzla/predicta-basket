import { t as Equipos } from "./ledger-pages-CH-SfaYW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/equipos-BmbW9SZA.js
var SplitComponent = Equipos;
//#endregion
export { SplitComponent as component };
