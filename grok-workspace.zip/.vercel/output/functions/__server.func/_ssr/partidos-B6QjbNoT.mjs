import { a as Partidos } from "./ops-pages-DtgvNp5Y.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/partidos-B6QjbNoT.js
var SplitComponent = Partidos;
//#endregion
export { SplitComponent as component };
