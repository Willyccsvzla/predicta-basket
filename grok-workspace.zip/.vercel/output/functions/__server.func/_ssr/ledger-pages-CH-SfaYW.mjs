import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as td, _ as Foot, b as Stat, c as FROZEN_V11, d as RANKING, g as Banner, i as useOps, u as METRICS_BUNDLE, v as Pager, w as th, x as TableWrap } from "./router-CdYe2R6g.mjs";
import { a as Bar, i as CartesianGrid, n as YAxis, o as ResponsiveContainer, r as XAxis, s as Tooltip, t as BarChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ledger-pages-CH-SfaYW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CHART = {
	accent: "#d6a15a",
	bone: "#e8eadf",
	line: "#2e3128",
	muted: "#9aa392"
};
function gameKey(g) {
	return `${g.date}_${g.aa}_${g.ha}`;
}
function Numeros() {
	const m = METRICS_BUNDLE.metrics;
	const cuts = [
		["Todos", m],
		["Pick local", METRICS_BUNDLE.cuts.local],
		["Pick visita", METRICS_BUNDLE.cuts.visita],
		["Prórroga", METRICS_BUNDLE.cuts.prorroga],
		["Confianza fuerte", METRICS_BUNDLE.cuts.fuerte],
		["Confianza neutra", METRICS_BUNDLE.cuts.neutra]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl",
				children: "Números"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-relaxed text-muted",
				children: "2025-26 es el histórico congelado. No se recalcula. 2026-27 todavía no tiene partidos jugados en este sistema: no hay accuracy operativa."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Analizados",
						v: m.n,
						sub: `${m.correct} aciertos · ${m.n - m.correct} errores`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Accuracy",
						v: `${m.acc}%`,
						sub: `local ${METRICS_BUNDLE.cuts.local.acc}% · visita ${METRICS_BUNDLE.cuts.visita.acc}%`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Brier",
						v: m.brier,
						sub: `log loss ${m.logloss}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "MAE",
						v: m.mae_pts,
						sub: `margen ${m.mae_margin} · total ${m.mae_total}`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Banner, { children: [
				"El registro v1.1 guarda log loss ",
				FROZEN_V11.logloss,
				". El prompt maestro lo cita como 0.6030, la misma cifra a tres decimales. No se reescribió."
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableWrap, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full border-collapse",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Corte"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "N"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Accuracy"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Brier"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Log loss"
					})
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: cuts.map(([label, row]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: td,
						children: label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: td,
						children: row.n
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
						className: td,
						children: [row.acc, "%"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: td,
						children: row.brier
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: td,
						children: row.logloss
					})
				] }, label)) })]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl",
				children: "Calibración"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-64 rounded-lg border border-line bg-card p-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: "100%",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
						data: METRICS_BUNDLE.cal,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
								stroke: CHART.line,
								vertical: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "label",
								stroke: CHART.muted,
								fontSize: 12
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								stroke: CHART.muted,
								fontSize: 12
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
								background: "#141612",
								border: "1px solid #2e3128",
								color: "#e8eadf"
							} }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: "p",
								name: "Probabilidad",
								fill: CHART.accent
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: "real",
								name: "Real",
								fill: CHART.bone
							})
						]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistTable, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Foot, {})
		]
	});
}
function HistTable() {
	const [games, setGames] = (0, import_react.useState)(null);
	const [q, setQ] = (0, import_react.useState)("");
	const [hit, setHit] = (0, import_react.useState)("");
	const [page, setPage] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		let on = true;
		import("./games-2025-BM5PYijv.mjs").then((mod) => {
			if (on) setGames(mod.default);
		});
		return () => {
			on = false;
		};
	}, []);
	const rows = (0, import_react.useMemo)(() => {
		if (!games) return [];
		return games.filter((g) => {
			if (q && !`${g.date} ${g.aa} ${g.ha}`.toLowerCase().includes(q.trim().toLowerCase())) return false;
			if (hit === "1" && !g.hit) return false;
			if (hit === "0" && g.hit) return false;
			return true;
		});
	}, [
		games,
		q,
		hit
	]);
	if (!games) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "Cargando histórico congelado…"
	});
	const pages = Math.max(1, Math.ceil(rows.length / 40));
	const safe = Math.min(page, pages - 1);
	const slice = rows.slice(safe * 40, safe * 40 + 40);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl",
				children: "2025-26 congelada"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: q,
					onChange: (e) => {
						setPage(0);
						setQ(e.target.value);
					},
					placeholder: "Equipo o fecha",
					className: "h-11 rounded-lg border border-line bg-card px-3 text-sm"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: hit,
					onChange: (e) => {
						setPage(0);
						setHit(e.target.value);
					},
					className: "h-11 rounded-lg border border-line bg-card px-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Acierto o error"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "1",
							children: "Acierto"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "0",
							children: "Error"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pager, {
				page: safe,
				pages,
				total: rows.length,
				onPrev: () => setPage((p) => Math.max(0, p - 1)),
				onNext: () => setPage((p) => p + 1)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableWrap, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full border-collapse",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Fecha"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Visitante"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Local"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Pick"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Proyección"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Real"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Estado"
					})
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: slice.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: td,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/historico/$key",
							params: { key: gameKey(g) },
							className: "underline",
							children: g.date
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: td,
						children: g.aa
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: td,
						children: g.ha
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: td,
						children: g.pick
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
						className: td,
						children: [
							g.proj_away,
							"-",
							g.proj_home
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
						className: td,
						children: [
							g.away_pts,
							"-",
							g.home_pts,
							g.ot ? ` ${g.ot}` : ""
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: g.hit ? `${td} text-good` : `${td} text-bad`,
						children: g.hit ? "Acierto" : "Error"
					})
				] }, gameKey(g))) })]
			}) })
		]
	});
}
function Historico({ id }) {
	const [game, setGame] = (0, import_react.useState)(void 0);
	(0, import_react.useEffect)(() => {
		import("./games-2025-BM5PYijv.mjs").then((mod) => {
			const rows = mod.default;
			setGame(rows.find((g) => gameKey(g) === id) ?? null);
		});
	}, [id]);
	if (game === void 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "Cargando partido histórico…"
	});
	if (!game) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banner, {
		tone: "bad",
		children: "Ese partido no está en la base 2025-26."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-widest text-muted uppercase",
				children: "Histórico congelado · no operativo"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "text-3xl",
				children: [
					game.aa,
					" @ ",
					game.ha
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					game.date,
					" · hora histórica no disponible · pick ",
					game.pick,
					" ",
					game.p_pick,
					"% · ",
					game.conf,
					" · ",
					game.unc
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Proyección",
						v: `${game.proj_away}-${game.proj_home}`,
						sub: `margen ${game.proj_margin} · total ${game.proj_total}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Real",
						v: `${game.away_pts}-${game.home_pts}`,
						sub: game.hit ? "Acierto" : "Error"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Rating previo",
						v: `${game.r_away} / ${game.r_home}`,
						sub: "visita / local"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Banner, { children: [
				"Disponibilidad informativa. No entró al marcador. Timestamp ",
				game.availability_timestamp || "no verificado",
				"."
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-lg border border-line bg-card p-4 text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl text-bone",
							children: "Out local"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2",
							children: game.players_out_home.join(", ") || "Ninguno en el registro"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2",
							children: ["Questionable: ", game.players_questionable_home.join(", ") || "ninguno"]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-lg border border-line bg-card p-4 text-sm text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl text-bone",
							children: "Out visita"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2",
							children: game.players_out_away.join(", ") || "Ninguno en el registro"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2",
							children: ["Questionable: ", game.players_questionable_away.join(", ") || "ninguno"]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Foot, {})
		]
	});
}
function Equipos() {
	const ratings = useOps((s) => s.ratings);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl",
				children: "Equipos"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Cierre 2025-26. No es un ranking externo. El operativo 2026-27 arranca 0-0 con ese rating y solo entra al motor cuando el partido se procesa."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableWrap, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full border-collapse",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: th }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Equipo"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "W"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "L"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Rating"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Off"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Def"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Net"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Pace"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Forma"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Ops 26-27"
					})
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: RANKING.map((t, i) => {
					const live = ratings[t.abbr];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: i + 1
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: t.team
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: t.w
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: t.l
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: t.rating
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: t.ortg
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: t.drtg
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: t.nrtg
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: t.pace
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: t.form
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: live ? `${live.w}-${live.l} · ${live.rating}` : "—"
						})
					] }, t.abbr);
				}) })]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Foot, {})
		]
	});
}
function Jugadores() {
	const layer = METRICS_BUNDLE.layer;
	const [rows, setRows] = (0, import_react.useState)(null);
	const [q, setQ] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		import("./player-log-UERsUIsG.mjs").then((mod) => setRows(mod.default));
	}, []);
	const shown = (rows ?? []).filter((r) => !q || `${r.player} ${r.team} ${r.date}`.toLowerCase().includes(q.trim().toLowerCase())).slice(0, 80);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl",
				children: "Jugadores"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banner, { children: "Capa de información. No entra al motor. Questionable no es out. Minutos e impacto = NO DISPONIBLE, no cero." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Con reporte",
						v: layer.verified_games,
						sub: "de 1230 · falta 2025-12-11"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Cobertura",
						v: `${layer.coverage}%`,
						sub: `${layer.players} jugadores`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Questionable",
						v: layer.questionable,
						sub: "estado original"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Impacto",
						v: "NOT VALIDATED",
						sub: "impact_applied = false"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableWrap, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full border-collapse",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Estado"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Filas"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Uso en motor"
					})
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: "OUT"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: layer.out
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: "No"
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: "QUESTIONABLE"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: layer.questionable
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: "No"
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: "DOUBTFUL"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: layer.doubtful
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: "No"
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: "PROBABLE"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: layer.probable
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: "No"
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: "Minutos / returning"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: "NOT AVAILABLE"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: td,
							children: "No"
						})
					] })
				] })]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"Índice con motivo entregado en el registro: ",
					rows?.length ?? "…",
					" filas. Los agregados de arriba son el conteo auditado, no una lista inventada."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: q,
				onChange: (e) => setQ(e.target.value),
				placeholder: "Jugador o equipo",
				className: "h-11 rounded-lg border border-line bg-card px-3 text-sm"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableWrap, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full border-collapse",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Fecha"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Equipo"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Jugador"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Estado"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Motivo"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Min"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: th,
						children: "Impacto"
					})
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: shown.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: td,
						children: r.date
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: td,
						children: r.team
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: td,
						children: r.player
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: td,
						children: r.status
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: `${td} whitespace-normal`,
						children: r.reason
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: td,
						children: "NO DISPONIBLE"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: td,
						children: "NO DISPONIBLE"
					})
				] }, `${r.date}-${r.team}-${r.player}-${r.status}`)) })]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Foot, {})
		]
	});
}
//#endregion
export { Numeros as i, Historico as n, Jugadores as r, Equipos as t };
