import { i as Numeros } from "./ledger-pages-CH-SfaYW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/numeros-hk1HhATd.js
var SplitComponent = Numeros;
//#endregion
export { SplitComponent as component };
