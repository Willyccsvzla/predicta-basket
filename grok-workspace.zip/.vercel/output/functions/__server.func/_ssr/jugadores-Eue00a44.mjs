import { r as Jugadores } from "./ledger-pages-CH-SfaYW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/jugadores-Eue00a44.js
var SplitComponent = Jugadores;
//#endregion
export { SplitComponent as component };
