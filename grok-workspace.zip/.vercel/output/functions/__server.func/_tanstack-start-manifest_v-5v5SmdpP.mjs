//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-5v5SmdpP.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/auditoria",
			"/calendario",
			"/equipos",
			"/hoy",
			"/jugadores",
			"/numeros",
			"/partidos",
			"/predicciones",
			"/scheduler",
			"/sistema",
			"/historico/$key",
			"/partido/$gameId"
		],
		preloads: [
			"/assets/index-WeMNOBlz.js",
			"/assets/store-CU-X_6ZW.js",
			"/assets/lazyRouteComponent-5W73CymN.js",
			"/assets/preload-helper-DjzSQ1t3.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-WeMNOBlz.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-C8OFz5DG.js", "/assets/ops-pages-pF0aR2-Q.js"]
	},
	"/auditoria": {
		filePath: "/workspace/src/routes/auditoria.tsx",
		children: void 0,
		preloads: ["/assets/auditoria-DdB8HaD5.js", "/assets/ops-pages-pF0aR2-Q.js"]
	},
	"/calendario": {
		filePath: "/workspace/src/routes/calendario.tsx",
		children: void 0,
		preloads: ["/assets/calendario-Bu7grUm3.js", "/assets/ops-pages-pF0aR2-Q.js"]
	},
	"/equipos": {
		filePath: "/workspace/src/routes/equipos.tsx",
		children: void 0,
		preloads: ["/assets/equipos-DZ06qvI_.js", "/assets/ledger-pages-YzYfDOlW.js"]
	},
	"/hoy": {
		filePath: "/workspace/src/routes/hoy.tsx",
		children: void 0,
		preloads: ["/assets/hoy-DI2MCuHL.js", "/assets/ops-pages-pF0aR2-Q.js"]
	},
	"/jugadores": {
		filePath: "/workspace/src/routes/jugadores.tsx",
		children: void 0,
		preloads: ["/assets/jugadores-CKwaWmKJ.js", "/assets/ledger-pages-YzYfDOlW.js"]
	},
	"/numeros": {
		filePath: "/workspace/src/routes/numeros.tsx",
		children: void 0,
		preloads: ["/assets/numeros-DtCHaPkK.js", "/assets/ledger-pages-YzYfDOlW.js"]
	},
	"/partidos": {
		filePath: "/workspace/src/routes/partidos.tsx",
		children: void 0,
		preloads: ["/assets/partidos-CvzUqy3U.js", "/assets/ops-pages-pF0aR2-Q.js"]
	},
	"/predicciones": {
		filePath: "/workspace/src/routes/predicciones.tsx",
		children: void 0,
		preloads: ["/assets/predicciones-HM-K8VA4.js", "/assets/ops-pages-pF0aR2-Q.js"]
	},
	"/scheduler": {
		filePath: "/workspace/src/routes/scheduler.tsx",
		children: void 0,
		preloads: ["/assets/scheduler-CZXX3hUZ.js", "/assets/ops-pages-pF0aR2-Q.js"]
	},
	"/sistema": {
		filePath: "/workspace/src/routes/sistema.tsx",
		children: void 0,
		preloads: ["/assets/sistema-xPE-cDM8.js", "/assets/ops-pages-pF0aR2-Q.js"]
	},
	"/historico/$key": {
		filePath: "/workspace/src/routes/historico.$key.tsx",
		children: void 0,
		preloads: ["/assets/historico._key-DHMXecgb.js", "/assets/ledger-pages-YzYfDOlW.js"]
	},
	"/partido/$gameId": {
		filePath: "/workspace/src/routes/partido.$gameId.tsx",
		children: void 0,
		preloads: ["/assets/partido._gameId-Cvkb3Wda.js", "/assets/ops-pages-pF0aR2-Q.js"]
	}
} });
//#endregion
export { tsrStartManifest };
