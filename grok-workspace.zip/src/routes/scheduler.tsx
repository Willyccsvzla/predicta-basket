import { createFileRoute } from "@tanstack/react-router";
import { Scheduler } from "@/components/predicta/ops-pages";

export const Route = createFileRoute("/scheduler")({ component: Scheduler });
