import { createFileRoute } from "@tanstack/react-router";
import { Hoy } from "@/components/predicta/ops-pages";

export const Route = createFileRoute("/hoy")({ component: Hoy });
