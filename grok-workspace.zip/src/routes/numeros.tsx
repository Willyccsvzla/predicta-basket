import { createFileRoute } from "@tanstack/react-router";
import { Numeros } from "@/components/predicta/ledger-pages";

export const Route = createFileRoute("/numeros")({ component: Numeros });
