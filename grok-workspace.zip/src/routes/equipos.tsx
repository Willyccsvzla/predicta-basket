import { createFileRoute } from "@tanstack/react-router";
import { Equipos } from "@/components/predicta/ledger-pages";

export const Route = createFileRoute("/equipos")({ component: Equipos });
