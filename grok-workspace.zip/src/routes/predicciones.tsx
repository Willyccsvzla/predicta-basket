import { createFileRoute } from "@tanstack/react-router";
import { Predicciones } from "@/components/predicta/ops-pages";

export const Route = createFileRoute("/predicciones")({ component: Predicciones });
