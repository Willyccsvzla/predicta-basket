import { createFileRoute } from "@tanstack/react-router";
import { Historico } from "@/components/predicta/ledger-pages";

export const Route = createFileRoute("/historico/$key")({
  component: function HistoricoRoute() {
    const { key } = Route.useParams();
    return <Historico id={key} />;
  },
});
