import { createFileRoute } from "@tanstack/react-router";
import { Portada } from "@/components/predicta/ops-pages";

export const Route = createFileRoute("/")({ component: Portada });
