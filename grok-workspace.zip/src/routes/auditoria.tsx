import { createFileRoute } from "@tanstack/react-router";
import { Auditoria } from "@/components/predicta/ops-pages";

export const Route = createFileRoute("/auditoria")({ component: Auditoria });
