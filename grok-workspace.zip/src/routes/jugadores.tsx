import { createFileRoute } from "@tanstack/react-router";
import { Jugadores } from "@/components/predicta/ledger-pages";

export const Route = createFileRoute("/jugadores")({ component: Jugadores });
