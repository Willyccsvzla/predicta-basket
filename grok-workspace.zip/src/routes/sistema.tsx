import { createFileRoute } from "@tanstack/react-router";
import { Sistema } from "@/components/predicta/ops-pages";

export const Route = createFileRoute("/sistema")({ component: Sistema });
