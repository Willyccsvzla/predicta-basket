import { createFileRoute } from "@tanstack/react-router";
import { Calendario } from "@/components/predicta/ops-pages";

export const Route = createFileRoute("/calendario")({ component: Calendario });
