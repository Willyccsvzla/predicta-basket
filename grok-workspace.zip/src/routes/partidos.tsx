import { createFileRoute } from "@tanstack/react-router";
import { Partidos } from "@/components/predicta/ops-pages";

export const Route = createFileRoute("/partidos")({ component: Partidos });
