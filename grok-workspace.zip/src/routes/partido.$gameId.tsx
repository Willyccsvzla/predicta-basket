import { createFileRoute } from "@tanstack/react-router";
import { Partido } from "@/components/predicta/ops-pages";

export const Route = createFileRoute("/partido/$gameId")({
  component: function PartidoRoute() {
    const { gameId } = Route.useParams();
    return <Partido gameId={gameId} />;
  },
});
