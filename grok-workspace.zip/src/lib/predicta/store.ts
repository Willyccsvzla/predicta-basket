import { create } from "zustand";
import { closureRatings, scheduleGame } from "@/lib/predicta/catalog";
import {
  createInitialState,
  ingestResult,
  operatorFreeze,
  processDay,
  refreshInfo,
  schedulerTick,
  schedulerTickDue,
  setProduction,
  setScheduler,
  stepGame,
} from "@/lib/predicta/orchestrator";
import { executeSandbox } from "@/lib/predicta/sandbox";
import { etDateISO } from "@/lib/predicta/time";
import type { OpsState } from "@/lib/predicta/types";

const KEY = "predicta-nba-ops-v1";
/** Orden explícita del operador. No reabre la producción si después se cierra. */
const OPERATOR_ORDER = "2026-10-05-predicciones";
const SCHEDULER_ORDER = "2026-10-05-scheduler";

function authorize(state: OpsState): OpsState {
  if (state.activationOrder === OPERATOR_ORDER) return state;
  const opened = state.realPredictionsEnabled ? state : setProduction(state, true, new Date());
  return { ...opened, activationOrder: OPERATOR_ORDER };
}

function armScheduler(state: OpsState): OpsState {
  if (state.schedulerOrder === SCHEDULER_ORDER) return state;
  if (!state.realPredictionsEnabled) return state;
  const armed = state.schedulerEnabled ? state : setScheduler(state, true, new Date());
  const withOrder = { ...armed, schedulerOrder: SCHEDULER_ORDER };
  return schedulerTick(withOrder, new Date()).state;
}

interface DeskExtras {
  viewDate: string;
  dateTouched: boolean;
  hydrate: () => void;
  setViewDate: (date: string) => void;
  processSelectedDay: () => void;
  step: (id: string) => void;
  freeze: (id: string) => void;
  revise: (id: string) => void;
  saveResult: (id: string, homePts: number, awayPts: number, source: string) => string | null;
  enableProduction: (on: boolean) => void;
  enableScheduler: (on: boolean) => void;
  tick: (manual?: boolean) => void;
}

export type DeskState = OpsState & DeskExtras;

function apply(next: OpsState) {
  const current = useOps.getState();
  const clean: OpsState = {
    version: 1,
    ready: true,
    schedulerEnabled: next.schedulerEnabled,
    realPredictionsEnabled: next.realPredictionsEnabled,
    activatedAt: next.activatedAt,
    activationOrder: next.activationOrder ?? current.activationOrder,
    schedulerOrder: next.schedulerOrder ?? current.schedulerOrder,
    overlays: next.overlays,
    ratings: next.ratings,
    audit: next.audit,
    schedulerLog: next.schedulerLog,
    sandboxReport: current.sandboxReport,
    seq: next.seq,
  };
  const payload = {
    version: 1 as const,
    schedulerEnabled: clean.schedulerEnabled,
    realPredictionsEnabled: clean.realPredictionsEnabled,
    activatedAt: clean.activatedAt,
    activationOrder: clean.activationOrder,
    schedulerOrder: clean.schedulerOrder,
    overlays: clean.overlays,
    ratings: clean.ratings,
    audit: clean.audit,
    schedulerLog: clean.schedulerLog,
    seq: clean.seq,
  };
  localStorage.setItem(KEY, JSON.stringify(payload));
  useOps.setState(clean);
}

export const useOps = create<DeskState>((set, get) => ({
  ...createInitialState(),
  viewDate: "2026-10-20",
  dateTouched: false,
  hydrate: () => {
    const base = createInitialState();
    let next: OpsState = base;
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const saved = JSON.parse(raw) as OpsState;
        if (saved.version === 1 && saved.overlays && saved.ratings) {
          const overlays = { ...saved.overlays };
          for (const key of Object.keys(overlays)) {
            if (key.startsWith("SANDBOX")) delete overlays[key];
          }
          const moved = Object.values(overlays).some((o) => o.status === "ACTUALIZADO" || o.status === "AUDITADO");
          next = {
            ...base,
            schedulerEnabled: !!saved.schedulerEnabled && !!saved.realPredictionsEnabled,
            realPredictionsEnabled: !!saved.realPredictionsEnabled,
            activatedAt: saved.activatedAt,
            activationOrder: saved.activationOrder,
            schedulerOrder: saved.schedulerOrder,
            overlays,
            ratings: moved ? saved.ratings : closureRatings(),
            audit: Array.isArray(saved.audit) ? saved.audit : [],
            schedulerLog: Array.isArray(saved.schedulerLog) ? saved.schedulerLog : [],
            seq: saved.seq || 1,
          };
        }
      }
    } catch {
      next = base;
    }
    let report = null;
    try {
      report = executeSandbox();
    } catch (error) {
      report = {
        ran: false,
        lookaheadPass: false,
        lookaheadRejectedWinner: false,
        lookaheadRejectedPoints: false,
        lookaheadRejectedResult: false,
        lookaheadRejectedPost: false,
        prediction: false,
        freeze: false,
        secondFreeze: "FAIL" as const,
        update: false,
        frozenIntact: false,
        persist: false,
        restart: false,
        isolation: false,
        purged: false,
        ratingsUntouched: false,
        realPredictions: -1,
        realFrozen: -1,
        realFinals: -1,
        realUpdates: -1,
        note: error instanceof Error ? error.message : "sandbox falló",
      };
    }
    const touched = useOps.getState().dateTouched;
    const keptDate = useOps.getState().viewDate;
    const authorized = armScheduler(authorize(next));
    apply(authorized);
    set({ ready: true, sandboxReport: report, viewDate: touched ? keptDate : etDateISO(), dateTouched: touched });
  },
  setViewDate: (date) => set({ viewDate: date, dateTouched: true }),
  processSelectedDay: () => {
    const cur = get();
    const out = processDay(cur, cur.viewDate, new Date());
    apply(out.state);
  },
  step: (id) => {
    const cur = get();
    const out = stepGame(cur, id, new Date());
    apply(out.state);
  },
  freeze: (id) => {
    const cur = get();
    const out = operatorFreeze(cur, id, new Date());
    apply(out.state);
  },
  revise: (id) => {
    const cur = get();
    const out = refreshInfo(cur, id, new Date());
    apply(out.state);
  },
  saveResult: (id, homePts, awayPts, source) => {
    const cur = get();
    const game = scheduleGame(id);
    if (!game) return "partido no definido";
    const winner = homePts > awayPts ? game.ha : game.aa;
    const out = ingestResult(cur, id, {
      home_pts: homePts,
      away_pts: awayPts,
      winner,
      source,
      timestamp: new Date().toISOString(),
    });
    apply(out.state);
    return out.step.error ?? null;
  },
  enableProduction: (on) => apply(setProduction(get(), on, new Date())),
  enableScheduler: (on) => apply(setScheduler(get(), on, new Date())),
  tick: (manual) => {
    const cur = get();
    const now = new Date();
    if (manual !== true && !schedulerTickDue(cur, now)) return;
    apply(schedulerTick(cur, now).state);
  },
}));
