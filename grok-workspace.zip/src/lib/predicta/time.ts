/** Hora de calendario en America/New_York. El schedule está en ET. */

export function etDateISO(now = new Date()): string {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/New_York",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(now);
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? "";
  return `${get("year")}-${get("month")}-${get("day")}`;
}

export function addDays(iso: string, days: number): string {
  const [y, m, d] = iso.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d + days));
  return dt.toISOString().slice(0, 10);
}

export function parseClock(time: string): string {
  const m = time.trim().match(/^(\d{1,2}):(\d{2})\s*([ap])m?$/i);
  if (!m) return "00:00";
  let h = Number(m[1]) % 12;
  if (m[3].toLowerCase() === "p") h += 12;
  return `${String(h).padStart(2, "0")}:${m[2]}`;
}

export function tipInstant(date: string, time: string): Date {
  const hhmm = parseClock(time);
  const [y, mo, d] = date.split("-").map(Number);
  const [h, mi] = hhmm.split(":").map(Number);
  const utc = Date.UTC(y, mo - 1, d, h, mi, 0);
  const dtf = new Intl.DateTimeFormat("en-US", {
    timeZone: "America/New_York",
    hour12: false,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
  const parts = Object.fromEntries(dtf.formatToParts(new Date(utc)).map((p) => [p.type, p.value]));
  let hour = Number(parts.hour);
  if (hour === 24) hour = 0;
  const asUTC = Date.UTC(Number(parts.year), Number(parts.month) - 1, Number(parts.day), hour, Number(parts.minute), Number(parts.second));
  const offset = asUTC - utc;
  return new Date(utc - offset);
}

export function withinFreezeWindow(now: Date, date: string, time: string): boolean {
  const tip = tipInstant(date, time).getTime();
  const t = now.getTime();
  return t >= tip - 90 * 60 * 1000 && t < tip;
}

export function tipReached(now: Date, date: string, time: string): boolean {
  return now.getTime() >= tipInstant(date, time).getTime();
}

export function sameEtDay(now: Date, date: string): boolean {
  return etDateISO(now) === date;
}
