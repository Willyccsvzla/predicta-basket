import { closureRatings, scheduleGame, gamesOnDate } from "@/lib/predicta/catalog";
import { buildPregameSnapshot, builderUpdate, lookAheadCheck, predictionFingerprint, projectV11 } from "@/lib/predicta/engine";
import { etDateISO, sameEtDay, tipInstant, tipReached, withinFreezeWindow } from "@/lib/predicta/time";
import type {
  AuditEntry,
  AuditMath,
  GameOverlay,
  GameResult,
  GameStatus,
  InfoRevision,
  OpsState,
  PredictionOutput,
  ScheduleGame,
  SchedulerLogEntry,
} from "@/lib/predicta/types";

export interface StepOpts {
  sandbox?: boolean;
  sandboxGames?: ScheduleGame[];
  forceFreeze?: boolean;
  forceWindow?: boolean;
  now?: Date;
}

export interface StepResult {
  gameId: string;
  action: string;
  from: string;
  to: string;
  result: string;
  error?: string;
}

function blankOverlay(): GameOverlay {
  return { status: "PROGRAMADO", info: [], snapshots: [], predictionHistory: [] };
}

export function createInitialState(): OpsState {
  return {
    version: 1,
    ready: false,
    schedulerEnabled: false,
    realPredictionsEnabled: false,
    overlays: {},
    ratings: closureRatings(),
    audit: [],
    schedulerLog: [],
    sandboxReport: null,
    seq: 1,
  };
}

export function overlayOf(state: OpsState, id: string): GameOverlay {
  return state.overlays[id] ?? blankOverlay();
}

function stamp(state: OpsState, partial: Omit<AuditEntry, "id">): { state: OpsState; entry: AuditEntry } {
  const entry: AuditEntry = { ...partial, id: `A${state.seq}` };
  return { state: { ...state, seq: state.seq + 1, audit: [...state.audit, entry] }, entry };
}

function commit(state: OpsState, gameId: string, ov: GameOverlay, partial: Omit<AuditEntry, "id" | "gameId">): OpsState {
  const next = stamp(state, { ...partial, gameId });
  return {
    ...next.state,
    overlays: { ...state.overlays, [gameId]: ov },
  };
}

function infoRevision(timestamp: string): InfoRevision {
  return {
    timestamp,
    availability: "NOT AVAILABLE",
    questionable: "NOT AVAILABLE",
    doubtful: "NOT AVAILABLE",
    probable: "NOT AVAILABLE",
    out: "NOT AVAILABLE",
    minutes: "NOT AVAILABLE",
    impact: "NOT VALIDATED",
    rest: "NOT VALIDATED",
    travel: "NOT VALIDATED",
    market: { moneyline: null, spread: null, total: null, movement: null, role: "INFORMACIÓN / AUDITORÍA" },
    source: "sin fuente prepartido 2026-27 — no inventada",
  };
}

function reject(state: OpsState, gameId: string, from: string, action: string, error: string): { state: OpsState; step: StepResult } {
  const next = stamp(state, {
    timestamp: new Date().toISOString(),
    gameId,
    action,
    from,
    to: from,
    source: "orquestador",
    result: error,
    error,
  });
  return {
    state: next.state,
    step: { gameId, action, from, to: from, result: error, error },
  };
}

function auditMath(pred: PredictionOutput, result: GameResult, home: string): AuditMath {
  const y = result.winner === home ? 1 : 0;
  const p = Math.min(1 - 1e-6, Math.max(1e-6, pred.p_home / 100));
  const margin = result.home_pts - result.away_pts;
  const ptsError = (Math.abs(pred.projected_home - result.home_pts) + Math.abs(pred.projected_away - result.away_pts)) / 2;
  return {
    pts_error: +ptsError.toFixed(2),
    margin_error: +Math.abs(pred.projected_margin - margin).toFixed(2),
    total_error: +Math.abs(pred.projected_total - (result.home_pts + result.away_pts)).toFixed(2),
    hit: pred.pick === result.winner,
    brier: +((p - y) ** 2).toFixed(4),
    logloss: +(-(y * Math.log(p) + (1 - y) * Math.log(1 - p))).toFixed(4),
  };
}

export function productionCounts(state: OpsState) {
  let predictions = 0;
  let frozen = 0;
  let finals = 0;
  let updates = 0;
  for (const [id, ov] of Object.entries(state.overlays)) {
    if (id.startsWith("SANDBOX")) continue;
    if (ov.prediction || ov.frozen) predictions += 1;
    if (ov.frozen) frozen += 1;
    if (ov.status === "FINALIZADO" || ov.status === "ACTUALIZADO" || ov.status === "AUDITADO") finals += 1;
    if (ov.status === "ACTUALIZADO" || ov.status === "AUDITADO") updates += 1;
  }
  return { predictions, frozen, finals, updates };
}

export function stepGame(state: OpsState, gameId: string, now: Date, opts: StepOpts = {}): { state: OpsState; step: StepResult } {
  const game = scheduleGame(gameId, opts.sandboxGames);
  if (!game) {
    return reject(state, gameId, "ERROR", "GAME_MISSING", "partido no definido");
  }
  if (!opts.sandbox && !state.realPredictionsEnabled) {
    return reject(state, gameId, overlayOf(state, gameId).status, "BLOCKED_PRODUCTION_CLOSED", "producción cerrada");
  }
  const ov = overlayOf(state, gameId);
  const from = ov.status;
  const inDay = opts.sandbox || opts.forceWindow || sameEtDay(now, game.date);
  if (!inDay && (from === "PROGRAMADO" || from === "DATOS_ACTUALIZADOS" || from === "PREDICCIÓN_PENDIENTE" || from === "PREDICCIÓN_GENERADA")) {
    return reject(state, gameId, from, "FUERA_DE_VENTANA", "el día del partido todavía no es el día operativo ET");
  }

  if (from === "PROGRAMADO") {
    const nextOv: GameOverlay = { ...ov, status: "DATOS_ACTUALIZADOS", info: [...ov.info, infoRevision(now.toISOString())] };
    const next = commit(state, gameId, nextOv, {
      timestamp: now.toISOString(),
      action: "SNAPSHOT_INFO",
      from,
      to: "DATOS_ACTUALIZADOS",
      source: "sin fuente inventada",
      result: "disponibilidad NOT AVAILABLE",
    });
    return { state: next, step: { gameId, action: "SNAPSHOT_INFO", from, to: "DATOS_ACTUALIZADOS", result: "PASS" } };
  }

  if (from === "DATOS_ACTUALIZADOS") {
    const nextOv: GameOverlay = { ...ov, status: "PREDICCIÓN_PENDIENTE" };
    const next = commit(state, gameId, nextOv, {
      timestamp: now.toISOString(),
      action: "PREDICTION_READY",
      from,
      to: "PREDICCIÓN_PENDIENTE",
      source: "orquestador",
      result: "listo para snapshot",
    });
    return { state: next, step: { gameId, action: "PREDICTION_READY", from, to: "PREDICCIÓN_PENDIENTE", result: "PASS" } };
  }

  if (from === "PREDICCIÓN_PENDIENTE") {
    if (ov.prediction || ov.frozen) return reject(state, gameId, from, "REJECTED_DUPLICATE", "ya existe una predicción activa");
    const home = state.ratings[game.ha];
    const away = state.ratings[game.aa];
    if (!home || !away) return reject(state, gameId, from, "MISSING_TEAM", "estado de equipo ausente");
    const snap = buildPregameSnapshot(game, now.toISOString(), home, away, ov.snapshots.length + 1);
    const la = lookAheadCheck(gameId, snap);
    if (la !== "PASS") {
      const nextOv: GameOverlay = { ...ov, status: "ERROR", snapshots: [...ov.snapshots, snap], errorNote: la };
      const next = commit(state, gameId, nextOv, {
        timestamp: now.toISOString(),
        action: "LOOKAHEAD_REJECTED",
        from,
        to: "ERROR",
        source: "lookAheadCheck",
        result: la,
        error: la,
      });
      return { state: next, step: { gameId, action: "LOOKAHEAD_REJECTED", from, to: "ERROR", result: la, error: la } };
    }
    const projected = projectV11(snap);
    const prediction: PredictionOutput = {
      ...projected,
      predicted_winner: projected.pick,
      timestamp: now.toISOString(),
      cutoff: snap.cutoff,
      snapshot_version: snap.version,
      lookahead_status: la,
      inputs_snapshot: snap,
    };
    const nextOv: GameOverlay = {
      ...ov,
      status: "PREDICCIÓN_GENERADA",
      snapshots: [...ov.snapshots, snap],
      prediction,
      predictionHistory: [...ov.predictionHistory, prediction],
    };
    const next = commit(state, gameId, nextOv, {
      timestamp: now.toISOString(),
      action: "PREDICTION_GENERATED",
      from,
      to: "PREDICCIÓN_GENERADA",
      source: prediction.engine_mark,
      result: `${prediction.pick} ${prediction.p_pick}`,
    });
    return { state: next, step: { gameId, action: "PREDICTION_GENERATED", from, to: "PREDICCIÓN_GENERADA", result: "PASS" } };
  }

  if (from === "PREDICCIÓN_GENERADA") {
    if (ov.frozen) return reject(state, gameId, from, "REJECTED_ALREADY_FROZEN", "REJECTED_ALREADY_FROZEN");
    if (!ov.prediction) return reject(state, gameId, from, "MISSING_PREDICTION", "no hay predicción activa");
    const canFreeze = opts.forceFreeze || withinFreezeWindow(now, game.date, game.time);
    if (!canFreeze) {
      return reject(state, gameId, from, "FREEZE_WAITING_WINDOW", "congelación solo en los últimos 90 minutos o por orden explícita de sandbox");
    }
    const frozen = structuredClone(ov.prediction);
    const nextOv: GameOverlay = { ...ov, status: "PREDICCIÓN_CONGELADA", frozen };
    const next = commit(state, gameId, nextOv, {
      timestamp: now.toISOString(),
      action: "PREDICTION_FROZEN",
      from,
      to: "PREDICCIÓN_CONGELADA",
      source: "freezePrediction",
      result: "PASS",
    });
    return { state: next, step: { gameId, action: "PREDICTION_FROZEN", from, to: "PREDICCIÓN_CONGELADA", result: "PASS" } };
  }

  if (from === "PREDICCIÓN_CONGELADA") {
    if (!ov.frozen) return reject(state, gameId, from, "MISSING_FREEZE", "freeze ausente");
    if (!opts.forceFreeze && !tipReached(now, game.date, game.time)) {
      return reject(state, gameId, from, "WAITING_TIP", "todavía no es el tip");
    }
    const nextOv: GameOverlay = { ...ov, status: "EN_ESPERA_RESULTADO" };
    const next = commit(state, gameId, nextOv, {
      timestamp: now.toISOString(),
      action: "AWAITING_RESULT",
      from,
      to: "EN_ESPERA_RESULTADO",
      source: "scheduler",
      result: "resultado NOT AVAILABLE",
    });
    return { state: next, step: { gameId, action: "AWAITING_RESULT", from, to: "EN_ESPERA_RESULTADO", result: "PASS" } };
  }

  if (from === "EN_ESPERA_RESULTADO") {
    return reject(state, gameId, from, "RESULT_NOT_AVAILABLE", "no hay resultado oficial. No se inventa marcador.");
  }

  if (from === "FINALIZADO") {
    if (!ov.frozen || !ov.result) return reject(state, gameId, from, "UPDATE_BLOCKED", "falta freeze o resultado");
    const before = predictionFingerprint(ov.frozen);
    const home = state.ratings[game.ha];
    const away = state.ratings[game.aa];
    if (!home || !away) return reject(state, gameId, from, "MISSING_TEAM", "estado de equipo ausente");
    const upd = builderUpdate(home.rating, away.rating, !!game.neutral, ov.result.winner === game.ha, ov.result.home_pts - ov.result.away_pts);
    const ratings = {
      ...state.ratings,
      [game.ha]: {
        ...home,
        rating: +upd.home.toFixed(4),
        w: home.w + (ov.result.winner === game.ha ? 1 : 0),
        l: home.l + (ov.result.winner === game.ha ? 0 : 1),
      },
      [game.aa]: {
        ...away,
        rating: +upd.away.toFixed(4),
        w: away.w + (ov.result.winner === game.aa ? 1 : 0),
        l: away.l + (ov.result.winner === game.aa ? 0 : 1),
      },
    };
    const math = auditMath(ov.frozen, ov.result, game.ha);
    const nextOv: GameOverlay = { ...ov, status: "ACTUALIZADO", auditMath: math };
    if (predictionFingerprint(nextOv.frozen!) !== before) {
      return reject(state, gameId, from, "FREEZE_REWRITTEN", "NO MODIFICADO — la predicción congelada cambió");
    }
    const logged = commit({ ...state, ratings }, gameId, nextOv, {
      timestamp: now.toISOString(),
      action: "STATE_UPDATED",
      from,
      to: "ACTUALIZADO",
      source: "builderUpdate",
      result: `delta rating local ${upd.delta.toFixed(2)}`,
    });
    return { state: logged, step: { gameId, action: "STATE_UPDATED", from, to: "ACTUALIZADO", result: "PASS" } };
  }

  if (from === "ACTUALIZADO") {
    const nextOv: GameOverlay = { ...ov, status: "AUDITADO" };
    const next = commit(state, gameId, nextOv, {
      timestamp: now.toISOString(),
      action: "AUDITED",
      from,
      to: "AUDITADO",
      source: "auditoría",
      result: ov.auditMath ? `hit=${ov.auditMath.hit}` : "sin métrica",
    });
    return { state: next, step: { gameId, action: "AUDITED", from, to: "AUDITADO", result: "PASS" } };
  }

  if (from === "AUDITADO") {
    return { state, step: { gameId, action: "NO_ACTION", from, to: from, result: "ya auditado" } };
  }

  return reject(state, gameId, from, "NO_TRANSITION", "estado sin transición automática");
}

export function operatorFreeze(state: OpsState, gameId: string, now: Date, opts: StepOpts = {}): { state: OpsState; step: StepResult } {
  return stepGame(state, gameId, now, { ...opts, forceFreeze: true });
}

export function freezeAgain(state: OpsState, gameId: string): { state: OpsState; step: StepResult } {
  const ov = overlayOf(state, gameId);
  if (ov.frozen || ov.status === "PREDICCIÓN_CONGELADA" || ov.status === "EN_ESPERA_RESULTADO" || ov.status === "FINALIZADO" || ov.status === "ACTUALIZADO" || ov.status === "AUDITADO") {
    return reject(state, gameId, ov.status, "REJECTED_ALREADY_FROZEN", "REJECTED_ALREADY_FROZEN");
  }
  return reject(state, gameId, ov.status, "FREEZE_NOT_READY", "no hay predicción congelable");
}

export function ingestResult(state: OpsState, gameId: string, result: GameResult, opts: StepOpts = {}): { state: OpsState; step: StepResult } {
  if (!opts.sandbox && !state.realPredictionsEnabled) {
    return reject(state, gameId, overlayOf(state, gameId).status, "BLOCKED_PRODUCTION_CLOSED", "producción cerrada");
  }
  const game = scheduleGame(gameId, opts.sandboxGames);
  if (!game) return reject(state, gameId, "ERROR", "GAME_MISSING", "partido no definido");
  const ov = overlayOf(state, gameId);
  if (ov.result) return reject(state, gameId, ov.status, "REJECTED_DUPLICATE_RESULT", "ya existe un resultado");
  if (ov.status !== "EN_ESPERA_RESULTADO") {
    return reject(state, gameId, ov.status, "RESULT_OUT_OF_ORDER", "el resultado solo entra en EN_ESPERA_RESULTADO");
  }
  if (!Number.isInteger(result.home_pts) || !Number.isInteger(result.away_pts) || result.home_pts < 0 || result.away_pts < 0) {
    return reject(state, gameId, ov.status, "RESULT_INVALID", "marcador inválido");
  }
  if (result.home_pts === result.away_pts) return reject(state, gameId, ov.status, "RESULT_INVALID", "la NBA no empata");
  const winner = result.home_pts > result.away_pts ? game.ha : game.aa;
  if (result.winner !== winner) return reject(state, gameId, ov.status, "RESULT_INVALID", "ganador no coincide con el marcador");
  if (!result.source.trim()) return reject(state, gameId, ov.status, "RESULT_INVALID", "falta fuente");
  const nextOv: GameOverlay = { ...ov, status: "FINALIZADO", result: { ...result, winner } };
  const next = commit(state, gameId, nextOv, {
    timestamp: result.timestamp,
    action: "RESULT_RECEIVED",
    from: ov.status,
    to: "FINALIZADO",
    source: result.source,
    result: `${result.away_pts}-${result.home_pts}`,
  });
  return { state: next, step: { gameId, action: "RESULT_RECEIVED", from: ov.status, to: "FINALIZADO", result: "PASS" } };
}

export function refreshInfo(state: OpsState, gameId: string, now: Date, opts: StepOpts = {}): { state: OpsState; step: StepResult } {
  if (!opts.sandbox && !state.realPredictionsEnabled) {
    return reject(state, gameId, overlayOf(state, gameId).status, "BLOCKED_PRODUCTION_CLOSED", "producción cerrada");
  }
  const ov = overlayOf(state, gameId);
  const locked: GameStatus[] = ["PREDICCIÓN_CONGELADA", "EN_ESPERA_RESULTADO", "FINALIZADO", "ACTUALIZADO", "AUDITADO"];
  if (locked.includes(ov.status)) {
    return reject(state, gameId, ov.status, "INFO_IGNORED_FROZEN", "la predicción congelada no se reabre");
  }
  if (ov.status === "PROGRAMADO") return stepGame(state, gameId, now, opts);
  const cleared = ov.status === "PREDICCIÓN_GENERADA";
  const nextOv: GameOverlay = {
    ...ov,
    status: "DATOS_ACTUALIZADOS",
    info: [...ov.info, infoRevision(now.toISOString())],
    prediction: undefined,
  };
  const next = commit(state, gameId, nextOv, {
    timestamp: now.toISOString(),
    action: cleared ? "INFO_REVISED_PREDICTION_CLEARED" : "INFO_REVISED",
    from: ov.status,
    to: "DATOS_ACTUALIZADOS",
    source: "sin fuente inventada",
    result: "nueva revisión. Sin lesiones inventadas.",
  });
  return { state: next, step: { gameId, action: "INFO_REVISED", from: ov.status, to: "DATOS_ACTUALIZADOS", result: "PASS" } };
}

export function processDay(state: OpsState, date: string, now: Date, opts: StepOpts = {}): { state: OpsState; steps: StepResult[] } {
  const games = gamesOnDate(date, opts.sandboxGames).filter((g) => (opts.sandbox ? g.id.startsWith("SANDBOX") : !g.id.startsWith("SANDBOX")));
  if (!opts.sandbox && !state.realPredictionsEnabled) {
    const note = `DRY RUN ${date}: ${games.length} partidos. Producción cerrada. Ningún estado de partido cambió.`;
    const log: SchedulerLogEntry = { timestamp: now.toISOString(), note };
    return {
      state: { ...state, schedulerLog: [...state.schedulerLog, log] },
      steps: games.map((g) => ({
        gameId: g.id,
        action: "BLOCKED_PRODUCTION_CLOSED",
        from: overlayOf(state, g.id).status,
        to: overlayOf(state, g.id).status,
        result: "producción cerrada",
      })),
    };
  }
  let cursor = state;
  const steps: StepResult[] = [];
  for (const g of games) {
    const out = stepGame(cursor, g.id, now, opts);
    cursor = out.state;
    steps.push(out.step);
  }
  const log: SchedulerLogEntry = {
    timestamp: now.toISOString(),
    note: `PROCESS ${date}: ${steps.map((s) => `${s.gameId}:${s.action}`).join(" · ") || "sin partidos"}`,
  };
  return { state: { ...cursor, schedulerLog: [...cursor.schedulerLog, log] }, steps };
}

export function checkCompletedGames(state: OpsState): { gameId: string; source: "NOT AVAILABLE" }[] {
  return Object.entries(state.overlays)
    .filter(([id, ov]) => !id.startsWith("SANDBOX") && ov.status === "EN_ESPERA_RESULTADO" && !ov.result)
    .map(([gameId]) => ({ gameId, source: "NOT AVAILABLE" as const }));
}

const CADENCE_GENERAL = 3 * 60 * 60 * 1000;
const CADENCE_LATE = 60 * 60 * 1000;
const CADENCE_CRITICAL = 30 * 60 * 1000;

export function schedulerCadenceMs(state: OpsState, now: Date): number {
  const games = gamesOnDate(etDateISO(now)).filter((g) => !g.id.startsWith("SANDBOX"));
  let ms = CADENCE_GENERAL;
  for (const g of games) {
    const status = overlayOf(state, g.id).status;
    const until = tipInstant(g.date, g.time).getTime() - now.getTime();
    const waiting = status === "EN_ESPERA_RESULTADO" || status === "FINALIZADO";
    if (waiting || (until <= 90 * 60 * 1000 && until > -4 * 60 * 60 * 1000)) ms = Math.min(ms, CADENCE_CRITICAL);
    else if (until > 0 && until <= 6 * 60 * 60 * 1000) ms = Math.min(ms, CADENCE_LATE);
  }
  return ms;
}

export function schedulerTickDue(state: OpsState, now: Date): boolean {
  if (!state.schedulerEnabled || !state.realPredictionsEnabled) return false;
  const last = state.schedulerLog[state.schedulerLog.length - 1];
  if (!last) return true;
  const at = Date.parse(last.timestamp);
  if (!Number.isFinite(at)) return true;
  return now.getTime() - at >= schedulerCadenceMs(state, now);
}

export function schedulerTick(state: OpsState, now: Date): { state: OpsState; steps: StepResult[] } {
  if (!state.schedulerEnabled || !state.realPredictionsEnabled) {
    const note = state.schedulerEnabled ? "tick ignorado: predicciones reales apagadas" : "tick ignorado: scheduler apagado";
    return {
      state: { ...state, schedulerLog: [...state.schedulerLog, { timestamp: now.toISOString(), note }] },
      steps: [],
    };
  }
  return processDay(state, etDateISO(now), now);
}

export function setProduction(state: OpsState, enabled: boolean, now: Date): OpsState {
  const entry = stamp(state, {
    timestamp: now.toISOString(),
    gameId: "SYSTEM",
    action: enabled ? "PRODUCTION_ON" : "PRODUCTION_OFF",
    from: String(state.realPredictionsEnabled),
    to: String(enabled),
    source: "activación manual",
    result: enabled ? "predicciones reales habilitadas" : "predicciones reales cerradas",
  });
  return {
    ...entry.state,
    realPredictionsEnabled: enabled,
    schedulerEnabled: enabled ? state.schedulerEnabled : false,
    activatedAt: enabled ? now.toISOString() : state.activatedAt,
  };
}

export function setScheduler(state: OpsState, enabled: boolean, now: Date): OpsState {
  if (enabled && !state.realPredictionsEnabled) {
    const entry = stamp(state, {
      timestamp: now.toISOString(),
      gameId: "SYSTEM",
      action: "SCHEDULER_REJECTED",
      from: "false",
      to: "false",
      source: "activación manual",
      result: "no se enciende el scheduler con producción cerrada",
      error: "PRODUCTION_CLOSED",
    });
    return entry.state;
  }
  const entry = stamp(state, {
    timestamp: now.toISOString(),
    gameId: "SYSTEM",
    action: enabled ? "SCHEDULER_ON" : "SCHEDULER_OFF",
    from: String(state.schedulerEnabled),
    to: String(enabled),
    source: "activación manual",
    result: enabled ? "scheduler encendido" : "scheduler apagado",
  });
  return { ...entry.state, schedulerEnabled: enabled };
}
