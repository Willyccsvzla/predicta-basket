import { closureRatings } from "@/lib/predicta/catalog";
import { buildPregameSnapshot, lookAheadCheck, predictionFingerprint } from "@/lib/predicta/engine";
import {
  createInitialState,
  freezeAgain,
  ingestResult,
  overlayOf,
  processDay,
  productionCounts,
  stepGame,
} from "@/lib/predicta/orchestrator";
import type { OpsState, SandboxReport, ScheduleGame } from "@/lib/predicta/types";

const SANDBOX_GAMES: ScheduleGame[] = [
  {
    id: "SANDBOX-1",
    date: "2099-01-01",
    time: "12:00p",
    timezone: "ET",
    aa: "BOS",
    ha: "DET",
    arena: "SANDBOX",
    notes: "",
    season: "sandbox",
    status: "PROGRAMADO",
    prediction: "PREDICCIÓN PENDIENTE",
  },
  {
    id: "SANDBOX-2",
    date: "2099-01-01",
    time: "3:00p",
    timezone: "ET",
    aa: "NYK",
    ha: "MIA",
    arena: "SANDBOX",
    notes: "",
    season: "sandbox",
    status: "PROGRAMADO",
    prediction: "PREDICCIÓN PENDIENTE",
  },
];

function advance(state: OpsState, id: string, now: Date, opts?: { forceFreeze?: boolean }) {
  return stepGame(state, id, now, { sandbox: true, sandboxGames: SANDBOX_GAMES, forceWindow: true, ...opts });
}

export function executeSandbox(): SandboxReport {
  const untouched = JSON.stringify(closureRatings());
  let state = createInitialState();
  const now = new Date("2099-01-01T16:00:00Z");
  const opts = { sandbox: true as const, sandboxGames: SANDBOX_GAMES, forceWindow: true };

  let pass = true;
  for (let i = 0; i < 3; i++) {
    const out = advance(state, "SANDBOX-1", now);
    state = out.state;
    pass = pass && out.step.result === "PASS";
  }
  const pred = overlayOf(state, "SANDBOX-1").prediction;
  const snap = pred?.inputs_snapshot ?? buildPregameSnapshot(SANDBOX_GAMES[0], now.toISOString(), state.ratings.DET, state.ratings.BOS, 1);
  const lookaheadPass = lookAheadCheck("SANDBOX-1", snap) === "PASS";
  const lookaheadRejectedWinner = lookAheadCheck("SANDBOX-1", { ...snap, winner: "DET" }) === "REJECTED_LOOKAHEAD";
  const lookaheadRejectedPoints = lookAheadCheck("SANDBOX-1", { ...snap, home_pts: 110, away_pts: 100 }) === "REJECTED_LOOKAHEAD";
  const lookaheadRejectedResult = lookAheadCheck("SANDBOX-1", { ...snap, result_used: true }) === "REJECTED_LOOKAHEAD";
  const lookaheadRejectedPost = lookAheadCheck("SANDBOX-1", { ...snap, post_cutoff: true, box_score: { pts: 1 } }) === "REJECTED_LOOKAHEAD";

  const frozenStep = advance(state, "SANDBOX-1", now, { forceFreeze: true });
  state = frozenStep.state;
  const freeze = frozenStep.step.result === "PASS" && !!overlayOf(state, "SANDBOX-1").frozen;
  const second = freezeAgain(state, "SANDBOX-1");
  state = second.state;
  const secondFreeze = second.step.error === "REJECTED_ALREADY_FROZEN" ? "REJECTED_ALREADY_FROZEN" : "FAIL";
  const finger = overlayOf(state, "SANDBOX-1").frozen ? predictionFingerprint(overlayOf(state, "SANDBOX-1").frozen!) : "";

  const wait = advance(state, "SANDBOX-1", new Date("2099-01-01T18:00:00Z"));
  state = wait.state;
  const ingested = ingestResult(
    state,
    "SANDBOX-1",
    { home_pts: 110, away_pts: 100, winner: "DET", source: "sandbox", timestamp: "2099-01-01T20:00:00Z" },
    opts,
  );
  state = ingested.state;
  const updated = advance(state, "SANDBOX-1", new Date("2099-01-01T20:05:00Z"));
  state = updated.state;
  const after = overlayOf(state, "SANDBOX-1").frozen ? predictionFingerprint(overlayOf(state, "SANDBOX-1").frozen!) : "";
  const frozenIntact = !!finger && finger === after;
  const audited = advance(state, "SANDBOX-1", new Date("2099-01-01T20:06:00Z"));
  state = audited.state;

  const serialized = JSON.stringify(state);
  const restored = JSON.parse(serialized) as OpsState;
  const persist = predictionFingerprint(restored.overlays["SANDBOX-1"].frozen!) === finger;

  let iso = createInitialState();
  for (let i = 0; i < 3; i++) iso = advance(iso, "SANDBOX-1", now).state;
  iso = advance(iso, "SANDBOX-1", now, { forceFreeze: true }).state;
  const fingerA = overlayOf(iso, "SANDBOX-1").frozen ? predictionFingerprint(overlayOf(iso, "SANDBOX-1").frozen!) : "";
  for (let i = 0; i < 3; i++) iso = advance(iso, "SANDBOX-2", now).state;
  const predB = overlayOf(iso, "SANDBOX-2").prediction;
  const isolation =
    !!fingerA &&
    !!predB &&
    predictionFingerprint(overlayOf(iso, "SANDBOX-1").frozen!) === fingerA &&
    predB.inputs_snapshot.home === "MIA" &&
    predB.inputs_snapshot.away === "NYK" &&
    overlayOf(iso, "SANDBOX-1").info !== overlayOf(iso, "SANDBOX-2").info;

  const day = processDay(createInitialState(), "2099-01-01", now, { ...opts, sandboxGames: SANDBOX_GAMES });
  const dayOk = day.steps.length === 2 && day.steps.every((s) => s.gameId.startsWith("SANDBOX"));

  delete state.overlays["SANDBOX-1"];
  delete state.overlays["SANDBOX-2"];
  const purged = !state.overlays["SANDBOX-1"] && !state.overlays["SANDBOX-2"];
  const ratingsUntouched = JSON.stringify(closureRatings()) === untouched;
  const real = productionCounts(createInitialState());

  return {
    ran: pass && !!pred && pred.fallback === true,
    lookaheadPass,
    lookaheadRejectedWinner,
    lookaheadRejectedPoints,
    lookaheadRejectedResult,
    lookaheadRejectedPost,
    prediction: !!pred && pred.lookahead_status === "PASS",
    freeze,
    secondFreeze,
    update: updated.step.result === "PASS",
    frozenIntact,
    persist,
    restart: persist && restored.overlays["SANDBOX-1"].status === "AUDITADO",
    isolation: isolation && dayOk,
    purged,
    ratingsUntouched,
    realPredictions: real.predictions,
    realFrozen: real.frozen,
    realFinals: real.finals,
    realUpdates: real.updates,
    note: "SANDBOX-1 y SANDBOX-2 se ejecutaron en memoria y se descartaron. No entran al calendario.",
  };
}
