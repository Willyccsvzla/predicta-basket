import rankingJson from "@/data/ranking.json";
import seasonJson from "@/data/season-2027.json";
import metricsJson from "@/data/metrics.json";
import { parseClock } from "@/lib/predicta/time";
import type { ScheduleGame, TeamLive } from "@/lib/predicta/types";

interface RankRow {
  team: string;
  abbr: string;
  w: number;
  l: number;
  rating: number;
  ortg: number;
  drtg: number;
  nrtg: number;
  pace: number;
  form: number;
}

export const RANKING = rankingJson as RankRow[];
export const SEASON: ScheduleGame[] = seasonJson as ScheduleGame[];
export const METRICS_BUNDLE = metricsJson as {
  metrics: {
    n: number;
    correct: number;
    acc: number;
    brier: number;
    logloss: number;
    mae_pts: number;
    mae_margin: number;
    mae_total: number;
  };
  cuts: Record<string, { n: number; correct: number; acc: number; brier: number; logloss: number; mae_pts: number; mae_margin: number; mae_total: number }>;
  cal: { label: string; n: number; p: number; real: number }[];
  layer: {
    status: string;
    verified_games: number;
    coverage: number;
    players: number;
    out: number;
    questionable: number;
    doubtful: number;
    probable: number;
    minutes_limit: number;
    returning: number;
    missing_date: string;
  };
  base_metrics: { n: number; correct: number; acc: number; brier: number; logloss: number; mae_pts: number; mae_margin: number; mae_total: number };
};

const byId = new Map(SEASON.map((g) => [g.id, g]));

export function scheduleGame(id: string, extras: ScheduleGame[] = []): ScheduleGame | undefined {
  return extras.find((g) => g.id === id) ?? byId.get(id);
}

export function gamesOnDate(date: string, extras: ScheduleGame[] = []): ScheduleGame[] {
  const rows = [...SEASON, ...extras].filter((g) => g.date === date);
  return rows.sort((a, b) => parseClock(a.time).localeCompare(parseClock(b.time)) || a.id.localeCompare(b.id));
}

export function closureRatings(): Record<string, TeamLive> {
  const out: Record<string, TeamLive> = {};
  for (const t of RANKING) {
    out[t.abbr] = {
      team: t.team,
      abbr: t.abbr,
      w: 0,
      l: 0,
      rating: t.rating,
      ortg: t.ortg,
      drtg: t.drtg,
      pace: t.pace,
      form: t.form,
      source: "cierre 2025-26",
    };
  }
  return out;
}

export function teamName(abbr: string): string {
  return RANKING.find((t) => t.abbr === abbr)?.team ?? abbr;
}
