/**
 * Parámetros protegidos del motor PREDICTA NBA v1.1.
 * Recuperados del builder embebido auditado. No modificar.
 * LOCAL FALLBACK — NO SOURCE OF TRUTH.
 * Los archivos build_predicta.py / build_v11.py no están en este paquete.
 */
export const ENGINE_MARK = "LOCAL FALLBACK — NO SOURCE OF TRUTH" as const;
export const MODEL_VERSION = "PREDICTA-NBA-v1.1-operational" as const;

export const MODEL_PARAMETERS = {
  scale: 28,
  homePts: 3,
  neutralPts: 0,
  K: 18,
  cap: 32,
  pScale: 11.5,
  leaguePrior: 113.5,
  movA: 2.2,
  movB: 0.001,
  eloDiv: 400,
  weightRating: 0.6,
  weightEfficiency: 0.3,
  weightForm: 0.1,
  fallbackRating: 0.9,
  fallbackForm: 0.1,
  ortgOwn: 0.65,
  drtgOpp: 0.35,
  paceWindow: 0.7,
  paceL5: 0.3,
  minWindowN: 5,
  fourFactorsWeight: 0.2,
  fourFactorsCap: 3.5,
  restCap: 1.5,
  restMinN: 25,
  travelCap: 0.6,
} as const;

/** Registro congelado v1.1. No recalcular. */
export const FROZEN_V11 = {
  season: "2025-26",
  n: 1230,
  correct: 841,
  acc: 68.37,
  brier: 0.2074,
  logloss: 0.603,
  maePts: 9.63,
  maeMargin: 11.4,
  maeTotal: 15.42,
} as const;

export const SCHEDULE_CONTRACT = {
  defined: 1200,
  pendingOfficial: 30,
  expected: 1230,
  coverage: "PARTIAL_OFFICIAL",
  preseason: false,
  first: "2026-10-20",
  last: "2027-04-11",
} as const;

export const FREEZE_WINDOW_MS = 90 * 60 * 1000;
