export const GAME_STATUSES = [
  "PROGRAMADO",
  "DATOS_ACTUALIZADOS",
  "PREDICCIÓN_PENDIENTE",
  "PREDICCIÓN_GENERADA",
  "PREDICCIÓN_CONGELADA",
  "EN_ESPERA_RESULTADO",
  "FINALIZADO",
  "ACTUALIZADO",
  "AUDITADO",
  "ERROR",
] as const;

export type GameStatus = (typeof GAME_STATUSES)[number];

export interface ScheduleGame {
  id: string;
  date: string;
  time: string;
  timezone: string;
  aa: string;
  ha: string;
  arena: string;
  notes: string;
  season: string;
  status: string;
  prediction: string;
  neutral?: boolean;
}

export interface TeamLive {
  team: string;
  abbr: string;
  w: number;
  l: number;
  rating: number;
  ortg: number;
  drtg: number;
  pace: number;
  form: number;
  source: string;
}

export interface WindowSample {
  n: number;
  pace: number;
  ortg: number;
  drtg: number;
}

export interface Snapshot {
  gameId: string;
  game_id: string;
  version: number;
  season: "2026-27";
  date: string;
  time: string;
  timezone: string;
  away: string;
  home: string;
  away_team: string;
  home_team: string;
  arena: string;
  neutral: boolean;
  rating_home: number;
  rating_away: number;
  form_home: number;
  form_away: number;
  form_margin: number;
  offense_home: number;
  offense_away: number;
  defense_home: number;
  defense_away: number;
  pace_home: number;
  pace_away: number;
  four_factors_home: null;
  four_factors_away: null;
  four_factors_status: "NOT VALIDATED";
  rest_home: null;
  rest_away: null;
  rest_status: "NOT VALIDATED";
  travel_home: null;
  travel_away: null;
  travel_status: "NOT VALIDATED";
  b2b_home: false;
  b2b_away: false;
  availability: "NOT APPLIED";
  availability_status: "NOT AVAILABLE";
  impact_applied: false;
  cutoff: string;
  cutoff_timestamp: string;
  timestamp: string;
  model_version: string;
  engine_mark: string;
  model_parameters: {
    scale: number;
    home_pts: number;
    K: number;
    cap: number;
    p_scale: number;
    league_prior: number;
  };
  model_state: "PREGAME";
  result_used: boolean;
  n_home: number;
  n_away: number;
  league_pts: number;
  window_home?: WindowSample;
  window_away?: WindowSample;
  window_home_l5?: WindowSample;
  window_away_l5?: WindowSample;
  winner?: string;
  home_pts?: number;
  away_pts?: number;
  box_score?: unknown;
  post_cutoff?: boolean;
}

export interface PredictionOutput {
  projected_home: number;
  projected_away: number;
  projected_total: number;
  projected_margin: number;
  margin_raw: number;
  p_home: number;
  p_away: number;
  pick: string;
  p_pick: number;
  confidence: "FUERTE" | "MODERADA" | "NEUTRA";
  uncertainty: "ALTA";
  fallback: boolean;
  model_version: string;
  engine_mark: string;
  model_state: "PREGAME";
  timestamp: string;
  cutoff: string;
  snapshot_version: number;
  lookahead_status: "PASS" | "REJECTED_LOOKAHEAD";
  inputs_snapshot: Snapshot;
  predicted_winner: string;
}

export interface InfoRevision {
  timestamp: string;
  availability: "NOT AVAILABLE";
  questionable: "NOT AVAILABLE";
  doubtful: "NOT AVAILABLE";
  probable: "NOT AVAILABLE";
  out: "NOT AVAILABLE";
  minutes: "NOT AVAILABLE";
  impact: "NOT VALIDATED";
  rest: "NOT VALIDATED";
  travel: "NOT VALIDATED";
  market: {
    moneyline: null;
    spread: null;
    total: null;
    movement: null;
    role: "INFORMACIÓN / AUDITORÍA";
  };
  source: string;
}

export interface GameResult {
  home_pts: number;
  away_pts: number;
  winner: string;
  source: string;
  timestamp: string;
}

export interface AuditMath {
  pts_error: number;
  margin_error: number;
  total_error: number;
  hit: boolean;
  brier: number;
  logloss: number;
}

export interface GameOverlay {
  status: GameStatus;
  info: InfoRevision[];
  snapshots: Snapshot[];
  predictionHistory: PredictionOutput[];
  prediction?: PredictionOutput;
  frozen?: PredictionOutput;
  result?: GameResult;
  auditMath?: AuditMath;
  errorNote?: string;
}

export interface AuditEntry {
  id: string;
  timestamp: string;
  gameId: string;
  action: string;
  from: string;
  to: string;
  source: string;
  result: string;
  error?: string;
}

export interface SchedulerLogEntry {
  timestamp: string;
  note: string;
  gameId?: string;
}

export interface SandboxReport {
  ran: boolean;
  lookaheadPass: boolean;
  lookaheadRejectedWinner: boolean;
  lookaheadRejectedPoints: boolean;
  lookaheadRejectedResult: boolean;
  lookaheadRejectedPost: boolean;
  prediction: boolean;
  freeze: boolean;
  secondFreeze: "REJECTED_ALREADY_FROZEN" | "FAIL";
  update: boolean;
  frozenIntact: boolean;
  persist: boolean;
  restart: boolean;
  isolation: boolean;
  purged: boolean;
  ratingsUntouched: boolean;
  realPredictions: number;
  realFrozen: number;
  realFinals: number;
  realUpdates: number;
  note: string;
}

export interface OpsState {
  version: 1;
  ready: boolean;
  schedulerEnabled: boolean;
  realPredictionsEnabled: boolean;
  /** Orden del operador ya aplicada. Si coincide, un cierre posterior no se reabre. */
  activationOrder?: string;
  /** Igual que la producción: encender una vez, no reabrir si el operador lo apaga. */
  schedulerOrder?: string;
  activatedAt?: string;
  overlays: Record<string, GameOverlay>;
  ratings: Record<string, TeamLive>;
  audit: AuditEntry[];
  schedulerLog: SchedulerLogEntry[];
  sandboxReport: SandboxReport | null;
  seq: number;
}
