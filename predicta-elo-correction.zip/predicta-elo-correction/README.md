# PREDICTA NBA — corrección aislada de Elo

Cambio aislado en la expectativa del motor Elo: se usa la logística estándar de base 10, `1 / (1 + 10 ** (-diferencia / 400))`, en lugar de `1 / (1 + exp(-diferencia / 400))`.

Se conservan los parámetros de producción existentes (K, MOV, ventaja local, tope y parámetros del modelo), el historial congelado 2025-26 y el resto del motor. Se amplió `scripts/predicta-check.mjs` con pruebas de regresión para expectativa, actualización, conservación de suma de ratings y tope MOV.

Integración: copiar `engine.ts` a `src/lib/predicta/engine.ts` y `predicta-check.mjs` a `scripts/predicta-check.mjs` del repositorio.
