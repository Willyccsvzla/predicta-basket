import fs from "node:fs";
import { createServer } from "vite";

const metrics = JSON.parse(fs.readFileSync("src/data/metrics.json", "utf8"));
const season = JSON.parse(fs.readFileSync("src/data/season-2027.json", "utf8"));
const games = JSON.parse(fs.readFileSync("src/data/games-2025.json", "utf8"));
const ids = new Set(season.map((g) => g.id));
const failures = [];
if (games.length !== 1230) failures.push("games");
if (metrics.metrics.n !== 1230 || metrics.metrics.acc !== 68.37 || metrics.metrics.brier !== 0.2074) failures.push("metrics");
if (metrics.metrics.correct !== 841) failures.push("correct");
if (season.length !== 1200 || ids.size !== 1200) failures.push("season");
if (season.some((g) => String(g.id).startsWith("SANDBOX"))) failures.push("sandbox in calendar");
const counts = {};
for (const g of season) {
  counts[g.aa] = (counts[g.aa] || 0) + 1;
  counts[g.ha] = (counts[g.ha] || 0) + 1;
}
if (Object.keys(counts).length !== 30 || Object.values(counts).some((n) => n !== 80)) failures.push("team counts");

const server = await createServer({ server: { middlewareMode: true }, appType: "custom", logLevel: "error" });
const mod = await server.ssrLoadModule("/src/lib/predicta/sandbox.ts");
const report = mod.executeSandbox();
const engine = await server.ssrLoadModule("/src/lib/predicta/engine.ts");
const elo = await server.ssrLoadModule("/src/lib/predicta/parameters.ts");
const { MODEL_PARAMETERS: P } = elo;
const close = (a, b, eps = 1e-9) => Math.abs(a - b) <= eps;
// Regression checks for the Elo probability scale and update invariants.
const p400 = 1 / (1 + 10 ** (-400 / P.eloDiv));
if (!close(p400, 1 / 1.1)) failures.push("elo probability scale: 400 points must map to 90.91%");
const gap400 = engine.builderUpdate(1900, 1500, true, true, 10);
const expected400 = 1 / (1 + 10 ** (-400 / P.eloDiv));
const mov400 = Math.log(11) * (P.movA / (P.movA + P.movB * 400));
const delta400 = Math.min(P.cap, P.K * mov400 * (1 - expected400));
if (!close(gap400.delta, delta400)) failures.push("elo update uses standard base-10 expectation");
const neutral = engine.builderUpdate(1500, 1500, true, true, 10);
const neutralExpected = 1 / (1 + 10 ** (-(1500 - 1500) / P.eloDiv));
const neutralMov = Math.log(11) * (P.movA / (P.movA + P.movB * 0));
const neutralDelta = Math.min(P.cap, P.K * neutralMov * (1 - neutralExpected));
if (!close(neutral.delta, neutralDelta)) failures.push("elo neutral update formula");
if (!close(neutral.home + neutral.away, 3000)) failures.push("elo rating conservation");
const blowout = engine.builderUpdate(1500, 1500, true, true, 80);
if (Math.abs(blowout.delta) > P.cap + 1e-9) failures.push("elo MOV cap");
const local = engine.builderUpdate(1500, 1500, false, true, 10);
if (!(local.delta < neutral.delta)) failures.push("elo home advantage expectation");
await server.close();
const flags = Object.entries(report).filter(([, v]) => v === false);
if (flags.length) failures.push(`sandbox ${flags.map(([k]) => k).join(",")}`);
if (report.realPredictions !== 0 || report.secondFreeze !== "REJECTED_ALREADY_FROZEN") failures.push("counters");
console.log(JSON.stringify({ failures, report }, null, 2));
if (failures.length) process.exit(1);
