import { ENGINE_MARK, MODEL_PARAMETERS, MODEL_VERSION } from "@/lib/predicta/parameters";
import type { PredictionOutput, Snapshot, TeamLive } from "@/lib/predicta/types";

/**
 * LOCAL FALLBACK — NO SOURCE OF TRUTH.
 * Copia fiel del motor recuperado en el HTML auditado (projectV11 / builderUpdate).
 * No es una fórmula nueva. Four Factors, rest y travel no entran:
 * el snapshot operativo no trae muestra validada.
 */

export function builderUpdate(
  rh: number,
  ra: number,
  neutral: boolean,
  homeWin: boolean,
  actualMargin: number,
) {
  const homePrior = neutral ? MODEL_PARAMETERS.neutralPts : MODEL_PARAMETERS.homePts;
  const rdiff = rh + homePrior * MODEL_PARAMETERS.scale - ra;
  // Elo estándar: probabilidad logística en base 10 (400 puntos ≈ 90.9% de expectativa).
  // La versión anterior usaba exp(), que convierte 400 puntos en solo 73.1% y
  // no corresponde a la escala Elo declarada. Se conservan K, MOV, localía y topes.
  const expected = 1 / (1 + 10 ** (-rdiff / MODEL_PARAMETERS.eloDiv));
  const movMult =
    Math.log(Math.abs(actualMargin) + 1) *
    (MODEL_PARAMETERS.movA / (MODEL_PARAMETERS.movA + MODEL_PARAMETERS.movB * Math.abs(rdiff)));
  let delta = MODEL_PARAMETERS.K * movMult * ((homeWin ? 1 : 0) - expected);
  delta = Math.max(-MODEL_PARAMETERS.cap, Math.min(MODEL_PARAMETERS.cap, delta));
  return { home: rh + delta, away: ra - delta, delta };
}

export function lookAheadCheck(
  gameId: string,
  snapshot: Snapshot | null | undefined,
): "PASS" | "REJECTED_LOOKAHEAD" {
  if (!snapshot || snapshot.game_id !== gameId || snapshot.result_used) return "REJECTED_LOOKAHEAD";
  if (snapshot.home_pts != null || snapshot.away_pts != null || snapshot.winner) return "REJECTED_LOOKAHEAD";
  if (snapshot.box_score != null || snapshot.post_cutoff) return "REJECTED_LOOKAHEAD";
  if (!snapshot.cutoff_timestamp) return "REJECTED_LOOKAHEAD";
  return "PASS";
}

export function projectV11(snap: Snapshot): Omit<
  PredictionOutput,
  "timestamp" | "cutoff" | "snapshot_version" | "lookahead_status" | "inputs_snapshot" | "predicted_winner"
> {
  const homePrior = snap.neutral ? MODEL_PARAMETERS.neutralPts : MODEL_PARAMETERS.homePts;
  const ratingMargin = (snap.rating_home + homePrior * MODEL_PARAMETERS.scale - snap.rating_away) / MODEL_PARAMETERS.scale;
  const formMargin = snap.form_margin || 0;
  const ready =
    !!snap.window_home &&
    !!snap.window_away &&
    snap.window_home.n >= MODEL_PARAMETERS.minWindowN &&
    snap.window_away.n >= MODEL_PARAMETERS.minWindowN &&
    !!snap.window_home_l5 &&
    !!snap.window_away_l5;
  let margin: number;
  let total: number;
  let fallback = true;
  if (ready && snap.window_home && snap.window_away && snap.window_home_l5 && snap.window_away_l5) {
    fallback = false;
    const pace =
      MODEL_PARAMETERS.paceWindow * ((snap.window_home.pace + snap.window_away.pace) / 2) +
      MODEL_PARAMETERS.paceL5 * ((snap.window_home_l5.pace + snap.window_away_l5.pace) / 2);
    const ortgH = MODEL_PARAMETERS.ortgOwn * snap.window_home.ortg + MODEL_PARAMETERS.drtgOpp * snap.window_away.drtg;
    const ortgA = MODEL_PARAMETERS.ortgOwn * snap.window_away.ortg + MODEL_PARAMETERS.drtgOpp * snap.window_home.drtg;
    const ptsH = (ortgH / 100) * pace;
    const ptsA = (ortgA / 100) * pace;
    total = ptsH + ptsA;
    margin =
      MODEL_PARAMETERS.weightRating * ratingMargin +
      MODEL_PARAMETERS.weightEfficiency * (ptsH - ptsA) +
      MODEL_PARAMETERS.weightForm * formMargin;
  } else {
    margin = MODEL_PARAMETERS.fallbackRating * ratingMargin + MODEL_PARAMETERS.fallbackForm * formMargin;
    total = (snap.league_pts || MODEL_PARAMETERS.leaguePrior) * 2;
  }
  const projHome = (total + margin) / 2;
  const pHome = 1 / (1 + Math.exp(-(margin / MODEL_PARAMETERS.pScale)));
  const pick = pHome >= 0.5 ? snap.home : snap.away;
  const pPick = pHome >= 0.5 ? pHome : 1 - pHome;
  // El builder recuperado fija incertidumbre en ALTA. Con eso, FUERTE y MODERADA no disparan.
  const uncertainty: string = "ALTA";
  const confidence: "FUERTE" | "MODERADA" | "NEUTRA" =
    pPick >= 0.68 && uncertainty === "BAJA" && !fallback
      ? "FUERTE"
      : pPick >= 0.58 && uncertainty !== "ALTA"
        ? "MODERADA"
        : "NEUTRA";
  return {
    projected_home: +projHome.toFixed(1),
    projected_away: +(total - projHome).toFixed(1),
    projected_total: +total.toFixed(1),
    projected_margin: +margin.toFixed(1),
    margin_raw: margin,
    p_home: +(pHome * 100).toFixed(1),
    p_away: +((1 - pHome) * 100).toFixed(1),
    pick,
    p_pick: +(pPick * 100).toFixed(1),
    confidence,
    uncertainty: "ALTA",
    fallback,
    model_version: MODEL_VERSION,
    engine_mark: ENGINE_MARK,
    model_state: "PREGAME",
  };
}

export function buildPregameSnapshot(
  game: { id: string; date: string; time: string; timezone: string; aa: string; ha: string; arena: string; neutral?: boolean },
  cutoff: string,
  home: TeamLive,
  away: TeamLive,
  version: number,
): Snapshot {
  return {
    gameId: game.id,
    game_id: game.id,
    version,
    season: "2026-27",
    date: game.date,
    time: game.time,
    timezone: game.timezone,
    away: game.aa,
    home: game.ha,
    away_team: game.aa,
    home_team: game.ha,
    arena: game.arena,
    neutral: !!game.neutral,
    rating_home: home.rating,
    rating_away: away.rating,
    form_home: home.form,
    form_away: away.form,
    form_margin: 0,
    offense_home: home.ortg,
    offense_away: away.ortg,
    defense_home: home.drtg,
    defense_away: away.drtg,
    pace_home: home.pace,
    pace_away: away.pace,
    four_factors_home: null,
    four_factors_away: null,
    four_factors_status: "NOT VALIDATED",
    rest_home: null,
    rest_away: null,
    rest_status: "NOT VALIDATED",
    travel_home: null,
    travel_away: null,
    travel_status: "NOT VALIDATED",
    b2b_home: false,
    b2b_away: false,
    availability: "NOT APPLIED",
    availability_status: "NOT AVAILABLE",
    impact_applied: false,
    cutoff,
    cutoff_timestamp: cutoff,
    timestamp: cutoff,
    model_version: MODEL_VERSION,
    engine_mark: ENGINE_MARK,
    model_parameters: {
      scale: MODEL_PARAMETERS.scale,
      home_pts: MODEL_PARAMETERS.homePts,
      K: MODEL_PARAMETERS.K,
      cap: MODEL_PARAMETERS.cap,
      p_scale: MODEL_PARAMETERS.pScale,
      league_prior: MODEL_PARAMETERS.leaguePrior,
    },
    model_state: "PREGAME",
    result_used: false,
    n_home: 0,
    n_away: 0,
    league_pts: MODEL_PARAMETERS.leaguePrior,
  };
}

export function predictionFingerprint(p: PredictionOutput) {
  return JSON.stringify({
    m: p.projected_margin,
    raw: p.margin_raw,
    t: p.projected_total,
    h: p.p_home,
    a: p.p_away,
    pick: p.pick,
    c: p.confidence,
    cut: p.cutoff,
    sv: p.snapshot_version,
  });
}
